# -*- coding: utf-8 -*-
from pptx import Presentation
import sys
sys.stdout.reconfigure(encoding='utf-8')

prs = Presentation(r'd:\src\博士汇报.pptx')

# Show slides 1-4 in detail
for i in range(min(5, len(prs.slides))):
    slide = prs.slides[i]
    print(f'=== 第 {i+1} 页 ===')
    for j, shape in enumerate(slide.shapes):
        if hasattr(shape, 'text_frame'):
            tf = shape.text_frame
            for k, para in enumerate(tf.paragraphs):
                text = para.text
                print(f'  S[{j}] P[{k}]: "{text}"')
    print()
