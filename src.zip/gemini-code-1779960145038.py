import matplotlib.pyplot as plt
import numpy as np

# ==========================================
# 1. 数据准备 (严格提取自 2026-05-28 实验日志)
# ==========================================
rounds = np.array([500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000])

# 累积效用 (Cumulative Utility) 原始数据
utility_data = {
    "POETIC": [12343262.2, 25766493.6, 39408660.1, 54397460.8, 69668428.5, 85123669.4, 102095509.6, 119169632.0, 136088410.5, 153228438.5],
    "POETIC-slow": [11210576.1, 24352434.0, 37872352.2, 52320203.9, 68488056.1, 89575571.3, 112982303.7, 137695999.8, 160839024.6, 185211038.2],
    "Oracle (Opt)": [17643566.7, 35003591.6, 53700916.1, 72531575.8, 90047177.5, 121860556.8, 154310677.0, 186756089.9, 218274981.3, 250528740.8],
    "PrivCO": [8139273.2, 16145985.5, 24713937.5, 33355996.8, 41320343.6, 61115362.0, 81305064.4, 101454835.8, 120966359.3, 140814231.0],
    "OPPS-adapted": [7286857.0, 14531021.1, 22437420.3, 30244743.4, 37618857.4, 56622865.3, 76261507.7, 96035481.5, 115113526.7, 134589249.3],
    "Truthful-DP-MAB": [12635539.1, 28398419.4, 44339755.6, 60097658.5, 76125549.3, 88154449.5, 99367968.8, 112263706.6, 127870593.7, 144308094.8],
    "Greedy Selection": [11424890.2, 24075185.9, 35941995.3, 48362572.0, 60349063.4, 76379907.4, 93134370.4, 110460754.0, 126267351.3, 143593140.3],
    "Random Selection": [7536869.2, 15065483.2, 22802937.5, 30890162.7, 38547634.8, 57921190.8, 76751758.0, 94795292.7, 114327861.7, 134289630.6]
}

# 估计误差 (Estimation Error) 数据 (严格限制在有记录的模型)
esterr_data = {
    "POETIC (Ours)": [604.11, 598.24, 591.97, 602.98, 613.19, 809.28, 947.78, 1041.89, 1111.29, 1171.80],
    "Greedy Selection": [623.72, 637.49, 629.43, 633.19, 628.22, 816.96, 950.82, 1061.55, 1128.90, 1191.76]
}

# 将效用值缩小 10^6 倍，适应学术图表显示
for key in utility_data:
    utility_data[key] = np.array(utility_data[key]) / 1e6

# ==========================================
# 2. 样式与视觉配置 (学术顶会规范)
# ==========================================
# 设置字体与字号
plt.rcParams.update({'font.size': 14, 'font.family': 'serif'})

# 定义每个模型的专属视觉属性 (颜色、线型、标记)
styles = {
    "POETIC (Ours)":           {"color": "#003366", "marker": "o", "linestyle": "-",  "linewidth": 2.5, "markersize": 8},
    "POETIC-slow":             {"color": "#0055A4", "marker": "s", "linestyle": "-",  "linewidth": 2.0, "markersize": 7},
    "Non-Private Optimal (Oracle)": {"color": "black",   "marker": "",  "linestyle": "--", "linewidth": 2.5, "markersize": 0},
    "PrivCO":                  {"color": "#CC3333", "marker": "D", "linestyle": "-.", "linewidth": 2.0, "markersize": 7},
    "Truthful-DP-MAB":         {"color": "#9933CC", "marker": "v", "linestyle": ":",  "linewidth": 2.0, "markersize": 8},
    "OPPS-adapted":            {"color": "#339966", "marker": "^", "linestyle": "-.", "linewidth": 2.0, "markersize": 8},
    "Greedy Selection":        {"color": "#009999", "marker": "x", "linestyle": "-",  "linewidth": 2.0, "markersize": 8},
    "Random Selection":        {"color": "#808080", "marker": "p", "linestyle": "-",  "linewidth": 2.0, "markersize": 8}
}

# ==========================================
# 3. 绘制图表
# ==========================================
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

# --- 子图 (a): 累积效用 ---
for model, y_vals in utility_data.items():
    ax1.plot(rounds, y_vals, label=model, 
             color=styles[model]["color"], marker=styles[model]["marker"],
             linestyle=styles[model]["linestyle"], linewidth=styles[model]["linewidth"], 
             markersize=styles[model]["markersize"])

ax1.set_title("(a) Overall Cumulative Utility (Clean Environment)", pad=15)
ax1.set_xlabel("Rounds")
ax1.set_ylabel(r"Cumulative Utility ($\times 10^6$)")
ax1.grid(True, linestyle='--', alpha=0.5)
ax1.legend(loc="upper left", framealpha=0.9, edgecolor='black', fontsize=11)
ax1.set_xlim(0, 5200)

# --- 子图 (b): 估计误差 ---
for model, y_vals in esterr_data.items():
    ax2.plot(rounds, y_vals, label=model, 
             color=styles[model]["color"], marker=styles[model]["marker"],
             linestyle=styles[model]["linestyle"], linewidth=styles[model]["linewidth"], 
             markersize=styles[model]["markersize"])

ax2.set_title("(b) Mean Estimation Error", pad=15)
ax2.set_xlabel("Rounds")
ax2.set_ylabel("Estimation Error")
ax2.grid(True, linestyle='--', alpha=0.5)
ax2.legend(loc="upper left", framealpha=0.9, edgecolor='black', fontsize=11)
ax2.set_xlim(0, 5200)

# 自动调整布局并显示
plt.tight_layout()
plt.savefig("exp1_overall_clean_environment.pdf", format='pdf', dpi=300, bbox_inches='tight')
plt.show()