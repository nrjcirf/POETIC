import os
import sys
import copy
import logging
import random
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

# 确保能正确导入源码
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)
sys.path.insert(0, current_dir)

from src.config import Config
from src.worker import Worker
from src.poe_platform import POEPlatform
from src.data_loader import SpatialDataLoader
from src.metrics import Metrics

# ── 1. ICDE 顶会级全局样式设置 ─────────────────────────────────────
mpl.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 12,
    'axes.titlesize': 13,
    'axes.labelsize': 12,
    'xtick.labelsize': 11,
    'ytick.labelsize': 11,
    'legend.fontsize': 11,
    'figure.dpi': 300,
    'lines.linewidth': 2.5,
    'axes.grid': True,
    'grid.linestyle': ':',
    'grid.alpha': 0.6,
    'axes.spines.top': False,
    'axes.spines.right': False,
})

STYLES = {
    'POETIC':          {'color': '#003366', 'ls': '-',  'marker': 'o', 'hatch': ''},     # 深蓝实线
    r'w/o $\Phi$':     {'color': '#c0392b', 'ls': '--', 'marker': 's', 'hatch': 'xx'},   # 深红虚线
    'w/o StabRep':     {'color': '#d35400', 'ls': '-.', 'marker': '^', 'hatch': '//'},   # 橙色点划线
    'w/o Both':        {'color': '#7f8c8d', 'ls': ':',  'marker': 'v', 'hatch': '..'},   # 灰色点线
}

def _workers_with_hardcore_spoofers(N, config):
    """🔥 核心修正：强行注入 30% 的高阶攻击者，彻底激活消融组件的防御价值"""
    workers = {wid: Worker(wid, config) for wid in range(N)}
    adv_ratio = 0.30
    num_adv = int(N * adv_ratio)
    adv_ids = list(range(num_adv))
    
    # 极端的恶意策略组合
    for wid in adv_ids[:len(adv_ids)//2]:
        workers[wid].current_strategy = 'utility_spoofer' # 蜜罐攻击，专门骗缺乏 Phi 的模型
    for wid in adv_ids[len(adv_ids)//2:]:
        workers[wid].current_strategy = 'oscillatory'     # 摇摆攻击，专门制造方差，打爆缺乏 StabRep 的模型
        
    for wid in range(num_adv, N):
        workers[wid].current_strategy = 'truthful'
    return workers

def run_ablation_simulation():
    config = Config()
    T = 5000       
    N = min(getattr(config, 'DEFAULT_NUM_WORKERS', 100), 200)
    K = getattr(config, 'DEFAULT_NUM_WINNERS', 10)
    worker_ids = list(range(N))
    
    # 采用默认的最优 epsilon=1.0 进行机制消融
    eps = 1.0 
    
    print("🚀 开始运行重构版 Exp ICDE-7: Mechanism Ablation (高强度对抗环境)...")
    
    # 定义四大消融变体 (精确控制底层数学开关)
    models = {
        'POETIC': POEPlatform(copy.deepcopy(config), worker_ids, name="POETIC", 
                              use_stability_reputation=True, use_decoupled_learning=True),
        r'w/o $\Phi$': POEPlatform(copy.deepcopy(config), worker_ids, name="w/o Phi", 
                                   use_stability_reputation=True, use_decoupled_learning=False),
        'w/o StabRep': POEPlatform(copy.deepcopy(config), worker_ids, name="w/o StabRep", 
                                   use_stability_reputation=False, use_decoupled_learning=True),
        'w/o Both': POEPlatform(copy.deepcopy(config), worker_ids, name="w/o Both", 
                                use_stability_reputation=False, use_decoupled_learning=False),
    }

    # 结果容器
    results = {m: {'val': [], 'err': [], 'variance': 0.0} for m in models}
    
    # 使用 NYC 数据集展现高波动性下的表现
    data_loader = SpatialDataLoader(config, dataset_type='NYC')
    
    for model_name, platform in models.items():
        print(f"  ▶ 正在评估变体: {model_name}")
        # 强制锁定 Seed，保证每个变体面对的攻击者在每一轮的发难时机 100% 相同！
        SEED = 2026
        random.seed(SEED)
        np.random.seed(SEED)
        
        workers = _workers_with_hardcore_spoofers(N, config)
        
        val_history = []
        err_history = []
        
        for t in range(T):
            active_ids = list(workers.keys())
            try:
                df_t = data_loader.get_round_data(t)
            except Exception:
                pass
            
            # 让工人根据环境和策略真实生成本轮数据
            for w in workers.values():
                strategy = getattr(w, 'current_strategy', 'truthful')
                if strategy == 'utility_spoofer':
                    w.true_utility = np.random.uniform(160, 190)
                    w.true_cost = np.random.uniform(5, 15)
                elif strategy == 'oscillatory':
                    if (t // 15) % 2 == 0:
                        w.true_utility, w.true_cost = 170.0, 5.0   
                    else:
                        w.true_utility, w.true_cost = 20.0, 130.0  
                else:
                    w.true_utility = np.clip(np.random.normal(120, 40), 10, 200)
                    w.true_cost = np.clip(np.random.normal(60, 20), 5, max(6.0, w.true_utility - 5))
                
                w.bid_history.append(w.true_cost)
                if not hasattr(w, 'utility_history'): w.utility_history = []
                w.utility_history.append(w.true_utility)
            
            # 运行平台
            platform.run_round(t, active_ids, workers, data_loader, dp_epsilon=eps, num_winners=K)
            
            # 记录历史
            if t % 500 == 0 or t == T - 1:
                cur_val = sum(getattr(platform, 'net_social_value_history', []))
                errs = getattr(platform, 'estimation_error_history', [0])
                cur_err = errs[-1] if errs else 0
                val_history.append(cur_val)
                err_history.append(cur_err)
                
        # 计算最终方差 (基于滑动窗口的社会效用震荡程度)
        nsv = getattr(platform, 'net_social_value_history', [])
        # 为了更敏锐地捕捉摇摆攻击带来的震荡，计算每 50 轮收益的方差
        window_size = 50
        if len(nsv) >= window_size:
            rolling_sums = [sum(nsv[i:i+window_size]) for i in range(0, len(nsv), window_size)]
            final_variance = np.var(rolling_sums)
        else:
            final_variance = np.var(nsv) if nsv else 0.0
            
        results[model_name]['val'] = val_history
        results[model_name]['err'] = err_history
        results[model_name]['variance'] = final_variance
        print(f"    ✓ 最终效用: {val_history[-1]/1e6:.1f}M | 方差: {final_variance/1e7:.1f}")

    # 获取轮次 X 轴
    rounds = [t for t in range(T) if t % 500 == 0 or t == T - 1]
    return results, rounds, models.keys()

def plot_ablation_results(results, rounds, methods):
    print("\n🎨 正在生成 1x3 机制消融图表...")
    fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))
    ax_u, ax_e, ax_v = axes[0], axes[1], axes[2]
    
    methods_list = list(methods)
    
    for m in methods_list:
        st = STYLES[m]
        plot_kwargs = {k:v for k,v in st.items() if k != 'hatch'}
        
        # (a) Utility
        u_vals = [v / 1e6 for v in results[m]['val']]
        ax_u.plot(rounds, u_vals, label=m, **plot_kwargs)
        
        # (b) Estimation Error
        ax_e.plot(rounds, results[m]['err'], label=m, **plot_kwargs)
        
    ax_u.set_title("(a) Cumulative Utility (Mechanism Ablation)")
    ax_u.set_ylabel(r"Cumulative Utility ($10^6$)")
    ax_u.set_xlabel("Rounds")
    ax_u.legend(loc='upper left', fontsize=10, edgecolor='black')
    
    ax_e.set_title("(b) Estimation Error (Mechanism Ablation)")
    ax_e.set_ylabel("Mean Estimation Error")
    ax_e.set_xlabel("Rounds")
    
    # ── (c) Learning Variance ──
    var_vals = [results[m]['variance'] / 1e7 for m in methods_list]
    colors = [STYLES[m]['color'] for m in methods_list]
    bars = ax_v.bar(methods_list, var_vals, color=colors, edgecolor='black', linewidth=1.5, alpha=0.85, width=0.6)
    
    for bar, m in zip(bars, methods_list):
        if STYLES[m].get("hatch"):
            bar.set_hatch(STYLES[m]["hatch"])
            
    ax_v.set_title("(c) Learning Variance")
    ax_v.set_ylabel(r"Variance ($10^7$)")
    ax_v.set_xticklabels(methods_list, rotation=15, ha='right')
    
    plt.tight_layout()
    out_dir = r"d:\src\paper"
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "fig7_mechanism_ablation_final.pdf")
    plt.savefig(out_path)
    print(f"✅ 真机版图 7 生成完毕！请查看：{out_path}")

if __name__ == "__main__":
    res, rnds, m_keys = run_ablation_simulation()
    plot_ablation_results(res, rnds, m_keys)