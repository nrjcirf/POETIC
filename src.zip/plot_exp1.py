import matplotlib.pyplot as plt
import numpy as np

# ==========================================
# 1. 核心数据准备 (基于10次运行的严格平均值)
# ==========================================
rounds = np.array([500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000])

# --- NYC 数据集: 累积效用 (缩放 10^6) ---
nyc_utility_data = {
    "POETIC (Ours)": [10.73, 24.37, 38.43, 53.16, 67.62, 87.58, 108.78, 130.69, 153.27, 175.69],
    "POETIC-slow": [11.45, 25.11, 38.91, 52.95, 67.10, 86.73, 107.50, 128.40, 149.48, 171.15],
    "Non-Private Optimal (Oracle)": [18.11, 36.32, 54.59, 72.53, 90.49, 121.59, 153.68, 185.77, 217.01, 249.18],
    "PrivCO": [8.05, 16.21, 24.38, 32.39, 40.40, 59.92, 80.06, 100.20, 119.80, 139.97],
    "Truthful-DP-MAB": [13.19, 28.44, 43.85, 59.21, 74.77, 86.50, 99.88, 115.33, 132.28, 150.20],
    "OPPS-adapted": [7.48, 15.03, 22.61, 29.99, 37.47, 56.26, 75.63, 95.00, 113.86, 133.29],
    "Greedy Selection": [11.87, 25.22, 38.60, 52.40, 66.22, 86.75, 107.03, 127.36, 147.67, 167.93],
    "Random Selection": [7.50, 15.01, 22.52, 30.13, 37.72, 56.90, 76.07, 95.09, 114.48, 133.63]
}

# --- NYC 数据集: 估计误差 ---
nyc_esterr_data = {
    "POETIC (Ours)": [637.67, 594.53, 575.25, 568.71, 561.29, 685.28, 765.77, 827.51, 879.64, 918.64],
    "Greedy Selection": [671.44, 628.11, 611.85, 607.52, 604.88, 699.88, 763.50, 812.02, 848.61, 877.79]
}

# --- T-Drive 数据集: 累积效用 (缩放 10^6) ---
tdrive_utility_data = {
    "POETIC (Ours)": [12.32, 27.52, 43.25, 59.22, 75.20, 96.86, 120.10, 143.96, 168.20, 192.68],
    "POETIC-slow": [12.74, 27.83, 43.06, 58.54, 73.76, 96.95, 119.53, 141.98, 164.33, 186.47],
    "Non-Private Optimal (Oracle)": [20.01, 39.90, 60.07, 80.07, 99.72, 134.42, 169.19, 203.53, 238.38, 272.58],
    "PrivCO": [8.92, 17.78, 26.71, 35.64, 44.37, 66.04, 87.77, 109.21, 131.08, 152.47],
    "Truthful-DP-MAB": [14.80, 31.58, 48.51, 65.79, 83.07, 96.31, 111.94, 129.83, 148.96, 168.97],
    "OPPS-adapted": [8.50, 16.95, 25.54, 34.06, 42.39, 63.50, 84.68, 105.59, 126.83, 147.68],
    "Greedy Selection": [13.14, 28.65, 44.36, 60.01, 75.57, 99.01, 122.82, 146.80, 171.22, 195.02],
    "Random Selection": [8.57, 17.07, 25.55, 34.00, 42.60, 63.70, 84.72, 105.94, 126.97, 148.08]
}

# --- T-Drive 数据集: 估计误差 ---
tdrive_esterr_data = {
    "POETIC (Ours)": [618.48, 584.02, 573.71, 568.16, 564.12, 700.03, 796.46, 868.84, 926.65, 972.43],
    "Greedy Selection": [623.25, 595.03, 586.07, 579.47, 575.27, 693.81, 778.08, 839.90, 892.35, 928.86]
}

# ==========================================
# 2. 学术排版与视觉样式定义
# ==========================================
plt.rcParams.update({'font.size': 13, 'font.family': 'serif'})

styles = {
    "POETIC (Ours)":           {"color": "#003366", "marker": "o", "ls": "-",  "lw": 2.5, "ms": 8},
    "POETIC-slow":             {"color": "#0055A4", "marker": "s", "ls": "-",  "lw": 2.0, "ms": 7},
    "Non-Private Optimal (Oracle)": {"color": "black",   "marker": "",  "ls": "--", "lw": 2.5, "ms": 0},
    "PrivCO":                  {"color": "#CC3333", "marker": "D", "ls": "-.", "lw": 2.0, "ms": 7},
    "Truthful-DP-MAB":         {"color": "#9933CC", "marker": "v", "ls": ":",  "lw": 2.0, "ms": 8},
    "OPPS-adapted":            {"color": "#339966", "marker": "^", "ls": "-.", "lw": 2.0, "ms": 8},
    "Greedy Selection":        {"color": "#009999", "marker": "x", "ls": "-",  "lw": 2.0, "ms": 8},
    "Random Selection":        {"color": "#808080", "marker": "p", "ls": "-",  "lw": 2.0, "ms": 8}
}

# ==========================================
# 3. 2x2 图表绘制引擎
# ==========================================
fig, axs = plt.subplots(2, 2, figsize=(16, 12))

datasets = [
    (nyc_utility_data, nyc_esterr_data, "NYC Taxi"),
    (tdrive_utility_data, tdrive_esterr_data, "T-Drive")
]

for row, (util_data, err_data, title) in enumerate(datasets):
    # 绘制左侧: 累积效用
    ax_util = axs[row, 0]
    for model, y_vals in util_data.items():
        ax_util.plot(rounds, y_vals, label=model, color=styles[model]["color"], 
                     marker=styles[model]["marker"], linestyle=styles[model]["ls"], 
                     linewidth=styles[model]["lw"], markersize=styles[model]["ms"])
    
    ax_util.set_title(f"({chr(97 + row*2)}) {title}: Overall Cumulative Utility", pad=15)
    ax_util.set_xlabel("Rounds")
    ax_util.set_ylabel(r"Cumulative Utility ($\times 10^6$)")
    ax_util.grid(True, linestyle='--', alpha=0.5)
    ax_util.set_xlim(0, 5200)
    if row == 0:
        ax_util.legend(loc="upper left", framealpha=0.9, edgecolor='black', fontsize=11)

    # 绘制右侧: 估计误差
    ax_err = axs[row, 1]
    for model, y_vals in err_data.items():
        ax_err.plot(rounds, y_vals, label=model, color=styles[model]["color"], 
                    marker=styles[model]["marker"], linestyle=styles[model]["ls"], 
                    linewidth=styles[model]["lw"], markersize=styles[model]["ms"])
    
    ax_err.set_title(f"({chr(98 + row*2)}) {title}: Mean Estimation Error", pad=15)
    ax_err.set_xlabel("Rounds")
    ax_err.set_ylabel("Estimation Error")
    ax_err.grid(True, linestyle='--', alpha=0.5)
    ax_err.set_xlim(0, 5200)
    if row == 0:
        ax_err.legend(loc="upper left", framealpha=0.9, edgecolor='black', fontsize=11)

plt.tight_layout(pad=3.0)
plt.savefig("exp1_overall_clean_combined.pdf", format='pdf', dpi=300, bbox_inches='tight')
plt.show()