# logsave.py (Final Production Version - ID-Routed & Warning-Free)
import os, re, json, sys, numpy as np
from collections import defaultdict

# ✅ 修复1：使用原始字符串 r"" 消除 SyntaxWarning
METHOD_MAP = {
    "POETIC": "POETIC", r"w/o $\Phi$": "w/o $\Phi$", "w/o StabRep": "w/o StabRep",
    "w/o Both": "w/o Both", "PrivCO": "PrivCO", "Truthful-DP-MAB": "Truthful-DP-MAB",
    "OPPS-adapted": "OPPS-adapted", "Random": "Random", "Non-Private Optimal": "Non-Private Optimal",
    "Greedy Selection": "Greedy Selection", "Greedy": "Greedy Selection"
}

def clean_method(line):
    line = line.strip().rstrip(":.,").strip()
    line = re.sub(r"^(?:Ratio|Epsilon|Adversarial|Strategic|Contamination)\s*=?\s*[\d.%inf=]+\s*", "", line, flags=re.I).strip()
    for full, clean in METHOD_MAP.items():
        if line == full or line.startswith(full + " ") or line.startswith(full + ":"): return clean
    line_lower = re.sub(r"\s+", " ", line.lower())
    for clean in METHOD_MAP.values():
        if clean.lower() in line_lower: return clean
    return "Unknown"

def safe_float(s):
    if not s: return 0.0
    s = str(s).replace(",", "").strip()
    if s.lower() in ("inf", "infinity"): return float("inf")
    try: return float(s)
    except: return 0.0

def strip_json_keys(obj):
    if isinstance(obj, dict): return {k.strip(): strip_json_keys(v) for k, v in obj.items()}
    elif isinstance(obj, list): return [strip_json_keys(i) for i in obj] # 改为统一的函数名
    return obj

def parse_log(filepath):
    if not os.path.exists(filepath): return {}, {}
    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    raw = defaultdict(lambda: {
        "ts": defaultdict(lambda: defaultdict(lambda: defaultdict(list))),
        "contam": defaultdict(lambda: defaultdict(list)),
        "ratio_sw": defaultdict(lambda: defaultdict(list)),
        "eps_sw": defaultdict(lambda: defaultdict(list)),
        "rep": defaultdict(list),
        "ablation": defaultdict(list)
    })
    cur_exp = None
    counts = defaultdict(int)

    re_exp   = re.compile(r"Exp\s+ICDE-(\d+)")
    re_round = re.compile(r"\[Round\s+(\d+)\]")
    re_ratio = re.compile(r"\b(?:Ratio)\s*=?\s*([\d.]+)%?", re.I)
    re_eps   = re.compile(r"(?:Epsilon|ε|蔚|e)\s*=?\s*([\d.]+|inf|infinity)", re.I)
    re_val   = re.compile(r"Val\s*[:=]?\s*([\d,.]+)", re.I)
    re_err   = re.compile(r"EstErr\s*[:=]?\s*([\d.]+)", re.I)
    re_var   = re.compile(r"Var\s*[:=]?\s*([\d.]+)", re.I)
    re_rep   = re.compile(r"\[([^\]]+)\]\s+Manip\s*[:=]?\s*([\d.]+)\s+Stable\s*[:=]?\s*([\d.]+)\s+Gap\s*[:=]?\s*([\d.-]+)")

    for line in lines:
        line = line.strip()
        if not line: continue
        for prefix in [" - INFO - ", " - WARNING - ", " - ERROR - "]:
            if prefix in line: line = line.split(prefix, 1)[-1]; break

        m_exp = re_exp.search(line)
        if m_exp: cur_exp = m_exp.group(1); continue
        if not cur_exp: continue

        rnd = re_round.search(line)
        ratio = re_ratio.search(line)
        eps = re_eps.search(line)
        val_m = re_val.search(line)
        err_m = re_err.search(line)
        var_m = re_var.search(line)
        rep_m = re_rep.search(line)
        
        method = clean_method(line)
        if method == "Unknown": continue

        v = safe_float(val_m.group(1)) if val_m else 0.0
        e = safe_float(err_m.group(1)) if err_m else 0.0

        # ✅ 修复2：按实验 ID 强制路由，彻底杜绝跨实验污染
        try:
            if rep_m:
                raw[cur_exp]["rep"][method].append({"manip": float(rep_m.group(2)), "stable": float(rep_m.group(3)), "gap": float(rep_m.group(4))})
                counts[f"Exp{cur_exp}-Rep"] += 1
            elif cur_exp == "6" and eps:  # 🔑 Exp6 强制归入 privacy
                raw[cur_exp]["eps_sw"][eps.group(1).lower().replace("infinity", "inf")][method].append((e, v))
                counts[f"Exp{cur_exp}-Privacy"] += 1
            elif cur_exp == "3" and ratio and eps:  # 🔑 Exp3 归入 contamination
                raw[cur_exp]["contam"][f"r={ratio.group(1)}_e={eps.group(1)}"][method].append(e)
                counts[f"Exp{cur_exp}-Contam"] += 1
            elif cur_exp in ("4", "8") and ratio and not eps:  # 🔑 Exp4/8 归入 ratio_sw
                raw[cur_exp]["ratio_sw"][ratio.group(1)][method].append((v, e))
                counts[f"Exp{cur_exp}-Ratio"] += 1
            elif rnd:
                raw[cur_exp]["ts"]["Default"][method][int(rnd.group(1))].append((v, e))
            elif eps:  # 兜底：其他实验带 eps 的也走 privacy
                raw[cur_exp]["eps_sw"][eps.group(1).lower().replace("infinity", "inf")][method].append((e, v))
                counts[f"Exp{cur_exp}-Privacy"] += 1
            elif ratio:
                raw[cur_exp]["ratio_sw"][ratio.group(1)][method].append((v, e))
                counts[f"Exp{cur_exp}-Ratio"] += 1
            elif var_m and not rnd and not ratio and not eps:
                raw[cur_exp]["ablation"][method].append((v, e, safe_float(var_m.group(1))))
                counts[f"Exp{cur_exp}-Ablation"] += 1
        except: pass

    result = {}
    for exp_id, d in raw.items():
        agg = {"exp_id": exp_id, "timeseries": {}, "contamination": {}, "privacy": {},
               "reputation": {}, "ablation": {}, "adversarial": {}, "strategic": {}}
        
        for env, methods in d["ts"].items():
            for method, rounds in methods.items():
                t_sorted = sorted(rounds.keys())
                vals, errs = [], []
                for t in t_sorted:
                    vals.append({"mean": float(np.mean([x[0] for x in rounds[t]])), "std": float(np.std([x[0] for x in rounds[t]]))})
                    errs.append({"mean": float(np.mean([x[1] for x in rounds[t]])), "std": float(np.std([x[1] for x in rounds[t]]))})
                agg["timeseries"].setdefault(env, {})[method] = {"t": t_sorted, "val": vals, "err": errs}

        for env, methods in agg["timeseries"].items():
            if "Non-Private Optimal" in methods:
                opt = methods["Non-Private Optimal"]
                opt_vals = [x["mean"] for x in opt["val"]]
                for method, dm in methods.items():
                    if method == "Non-Private Optimal": continue
                    min_len = min(len(dm["t"]), len(opt["t"]))
                    dm["regret"] = [{"mean": opt_vals[i] - dm["val"][i]["mean"], "std": dm["val"][i]["std"]} for i in range(min_len)]

        for key, methods in d["contam"].items():
            agg["contamination"][key] = {m: {"err_mean": float(np.mean(e)), "err_std": float(np.std(e))} for m, e in methods.items()}
        for eps_key, methods in d["eps_sw"].items():
            agg["privacy"][eps_key] = {m: {"err_mean": float(np.mean([x[0] for x in entries])), "val_mean": float(np.mean([x[1] for x in entries]))} for m, entries in methods.items()}
        
        target_key = "adversarial" if str(exp_id) == "8" else "strategic"
        for ratio_key, methods in d["ratio_sw"].items():
            agg[target_key][ratio_key] = {m: {"val_mean": float(np.mean([x[0] for x in entries])), "err_mean": float(np.mean([x[1] for x in entries])), "val_std": float(np.std([x[0] for x in entries]))} for m, entries in methods.items()}

        for method, entries in d["rep"].items():
            if entries: agg["reputation"][method] = {k: float(np.mean([x[k] for x in entries])) for k in ["manip", "stable", "gap"]}
        for method, entries in d["ablation"].items():
            if entries:
                v, e, var = zip(*entries)
                agg["ablation"][method] = {"val_mean": float(np.mean(v)), "val_std": float(np.std(v)), "err_mean": float(np.mean(e)), "err_std": float(np.std(e)), "var_mean": float(np.mean([x[2] for x in entries]))}
        result[exp_id] = agg
    return result, counts

if __name__ == "__main__":
    files = sys.argv[1:] if len(sys.argv) > 1 else [f for f in os.listdir(".") if f.endswith(".txt") and os.path.isfile(f)]
    if not files: print("⚠️ 未找到 .txt 日志文件"); sys.exit(1)
    
    for f in files:
        if not os.path.exists(f): continue
        res, counts = parse_log(f)
        if not res: print(f"⚠️ {f} 未提取到有效数据"); continue
        
        # ✅ 修复3：保存前强制递归清洗键名，杜绝空格污染
        res = strip_json_keys(res)
        out = "parsed_nyc_results.json" if "nyc" in f.lower() else f"parsed_{os.path.splitext(f)[0]}.json"
        with open(out, "w", encoding="utf-8") as jf: json.dump(res, jf, indent=2, ensure_ascii=False)
        
        print(f"\n✅ {f} -> {out}")
        print("📊 提取统计:")
        for k, v in sorted(counts.items()): print(f"   {k}: {v} 行")
        for eid in ["3", "6"]:
            d = res.get(eid, {})
            has_contam = bool(d.get("contamination"))
            has_priv = bool(d.get("privacy"))
            print(f"   Exp{eid} -> Contam: {'✅ 有' if has_contam else '❌ 空'}, Privacy: {'✅ 有' if has_priv else '❌ 空'}")