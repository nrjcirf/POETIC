import os
import re
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from collections import defaultdict

# ── 1. ICDE 顶会级全局样式设置 ─────────────────────────────────────
mpl.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 11,
    'axes.titlesize': 12,
    'axes.labelsize': 11,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 10,
    'figure.dpi': 300,
    'lines.linewidth': 2.5,
    'axes.grid': True,
    'grid.linestyle': ':',
    'grid.alpha': 0.6,
    'axes.spines.top': False,
    'axes.spines.right': False,
})

# 🔥 严格的全局颜色映射字典 (彻底解决与 Exp 5 冲突的问题)
STYLES = {
    'POETIC':          {'color': '#003366', 'ls': '-',  'marker': 'o', 'hatch': ''},     # 深蓝 (全文统一主模型)
    'w/o StabRep':     {'color': '#d35400', 'ls': '-.', 'marker': '^', 'hatch': '//'},   # 橙色 (必须与 Exp 5 一模一样！)
    r'w/o $\Phi$':     {'color': '#c0392b', 'ls': '--', 'marker': 's', 'hatch': 'xx'},   # 深红 (专属新颜色)
    'w/o Both':        {'color': '#7f8c8d', 'ls': ':',  'marker': 'v', 'hatch': '..'},   # 灰色 (全退化模型)
}

# ── 2. 直接读取粘贴的日志字符串 ─────────────────────────────────────
LOG_TEXT = """
2026-05-11 18:18:54,455 - INFO -     [Round 500] POETIC (Full): Val= 11,571,801.2  EstErr= 572.40
2026-05-11 18:18:56,216 - INFO -     [Round 1000] POETIC (Full): Val= 25,264,080.6  EstErr= 547.03
2026-05-11 18:18:57,993 - INFO -     [Round 1500] POETIC (Full): Val= 39,560,492.1  EstErr= 537.59
2026-05-11 18:18:59,770 - INFO -     [Round 2000] POETIC (Full): Val= 53,425,241.3  EstErr= 524.26
2026-05-11 18:19:01,545 - INFO -     [Round 2500] POETIC (Full): Val= 68,116,368.3  EstErr= 524.66
2026-05-11 18:19:03,420 - INFO -     [Round 3000] POETIC (Full): Val= 88,198,621.3  EstErr= 647.27
2026-05-11 18:19:05,278 - INFO -     [Round 3500] POETIC (Full): Val=109,643,536.0  EstErr= 735.34
2026-05-11 18:19:07,160 - INFO -     [Round 4000] POETIC (Full): Val=131,566,132.1  EstErr= 801.87
2026-05-11 18:19:09,030 - INFO -     [Round 4500] POETIC (Full): Val=154,233,700.3  EstErr= 859.89
2026-05-11 18:19:10,908 - INFO -     [Round 5000] POETIC (Full): Val=177,473,779.8  EstErr= 908.00
2026-05-11 18:19:12,731 - INFO -     [Round 500] POETIC (Full): Val= 11,627,727.7  EstErr= 577.14
2026-05-11 18:19:14,494 - INFO -     [Round 1000] POETIC (Full): Val= 24,720,530.9  EstErr= 544.18
2026-05-11 18:19:16,276 - INFO -     [Round 1500] POETIC (Full): Val= 39,067,694.6  EstErr= 537.55
2026-05-11 18:19:18,067 - INFO -     [Round 2000] POETIC (Full): Val= 53,194,695.6  EstErr= 527.56
2026-05-11 18:19:19,850 - INFO -     [Round 2500] POETIC (Full): Val= 66,655,627.7  EstErr= 514.87
2026-05-11 18:19:21,683 - INFO -     [Round 3000] POETIC (Full): Val= 88,729,704.9  EstErr= 651.71
2026-05-11 18:19:23,539 - INFO -     [Round 3500] POETIC (Full): Val=112,484,317.6  EstErr= 752.79
2026-05-11 18:19:25,387 - INFO -     [Round 4000] POETIC (Full): Val=137,487,865.5  EstErr= 839.15
2026-05-11 18:19:27,256 - INFO -     [Round 4500] POETIC (Full): Val=160,053,040.7  EstErr= 883.27
2026-05-11 18:19:29,095 - INFO -     [Round 5000] POETIC (Full): Val=185,995,314.1  EstErr= 940.76
2026-05-11 18:19:30,910 - INFO -     [Round 500] POETIC (Full): Val= 11,264,424.1  EstErr= 594.18
2026-05-11 18:19:32,671 - INFO -     [Round 1000] POETIC (Full): Val= 25,533,665.0  EstErr= 563.73
2026-05-11 18:19:34,448 - INFO -     [Round 1500] POETIC (Full): Val= 39,695,434.3  EstErr= 545.36
2026-05-11 18:19:36,216 - INFO -     [Round 2000] POETIC (Full): Val= 54,605,511.0  EstErr= 542.89
2026-05-11 18:19:37,967 - INFO -     [Round 2500] POETIC (Full): Val= 69,235,547.7  EstErr= 536.37
2026-05-11 18:19:39,815 - INFO -     [Round 3000] POETIC (Full): Val= 91,967,565.3  EstErr= 667.04
2026-05-11 18:19:41,675 - INFO -     [Round 3500] POETIC (Full): Val=115,833,126.4  EstErr= 763.11
2026-05-11 18:19:43,519 - INFO -     [Round 4000] POETIC (Full): Val=139,439,262.9  EstErr= 832.17
2026-05-11 18:19:45,373 - INFO -     [Round 4500] POETIC (Full): Val=164,086,647.7  EstErr= 893.93
2026-05-11 18:19:47,210 - INFO -     [Round 5000] POETIC (Full): Val=188,160,720.3  EstErr= 937.74
2026-05-11 18:19:49,043 - INFO -     [Round 500] POETIC (Full): Val= 11,854,831.0  EstErr= 594.71
2026-05-11 18:19:50,810 - INFO -     [Round 1000] POETIC (Full): Val= 25,603,993.3  EstErr= 559.29
2026-05-11 18:19:52,587 - INFO -     [Round 1500] POETIC (Full): Val= 40,389,954.2  EstErr= 552.90
2026-05-11 18:19:54,335 - INFO -     [Round 2000] POETIC (Full): Val= 55,084,558.8  EstErr= 547.36
2026-05-11 18:19:56,094 - INFO -     [Round 2500] POETIC (Full): Val= 69,749,178.4  EstErr= 542.08
2026-05-11 18:19:57,973 - INFO -     [Round 3000] POETIC (Full): Val= 91,372,619.9  EstErr= 673.06
2026-05-11 18:19:59,834 - INFO -     [Round 3500] POETIC (Full): Val=113,807,782.8  EstErr= 753.70
2026-05-11 18:20:01,711 - INFO -     [Round 4000] POETIC (Full): Val=137,043,202.9  EstErr= 818.56
2026-05-11 18:20:03,565 - INFO -     [Round 4500] POETIC (Full): Val=160,388,181.0  EstErr= 871.99
2026-05-11 18:20:05,431 - INFO -     [Round 5000] POETIC (Full): Val=183,976,391.7  EstErr= 914.54
2026-05-11 18:20:07,267 - INFO -     [Round 500] POETIC (Full): Val= 11,499,880.8  EstErr= 577.21
2026-05-11 18:20:09,034 - INFO -     [Round 1000] POETIC (Full): Val= 25,535,985.3  EstErr= 557.62
2026-05-11 18:20:10,809 - INFO -     [Round 1500] POETIC (Full): Val= 39,353,528.8  EstErr= 537.41
2026-05-11 18:20:12,590 - INFO -     [Round 2000] POETIC (Full): Val= 53,597,653.4  EstErr= 527.75
2026-05-11 18:20:14,383 - INFO -     [Round 2500] POETIC (Full): Val= 68,007,802.8  EstErr= 523.09
2026-05-11 18:20:16,241 - INFO -     [Round 3000] POETIC (Full): Val= 88,194,120.2  EstErr= 638.06
2026-05-11 18:20:18,110 - INFO -     [Round 3500] POETIC (Full): Val=111,662,193.0  EstErr= 741.18
2026-05-11 18:20:19,970 - INFO -     [Round 4000] POETIC (Full): Val=135,626,590.0  EstErr= 822.37
2026-05-11 18:20:21,819 - INFO -     [Round 4500] POETIC (Full): Val=159,929,114.5  EstErr= 890.21
2026-05-11 18:20:23,700 - INFO -     [Round 5000] POETIC (Full): Val=184,409,374.3  EstErr= 941.69
2026-05-11 18:21:55,280 - INFO -   POETIC (Full)         Val=183,002,627.9  EstErr= 928.69  Var=62530922.8
2026-05-11 18:21:56,875 - INFO -     [Round 500] w/o 桅: Val= 10,056,767.9  EstErr= 630.01
2026-05-11 18:21:58,443 - INFO -     [Round 1000] w/o 桅: Val= 20,804,617.7  EstErr= 601.10
2026-05-11 18:22:00,039 - INFO -     [Round 1500] w/o 桅: Val= 32,487,047.3  EstErr= 607.25
2026-05-11 18:22:01,611 - INFO -     [Round 2000] w/o 桅: Val= 44,127,570.8  EstErr= 608.15
2026-05-11 18:22:03,203 - INFO -     [Round 2500] w/o 桅: Val= 55,317,338.2  EstErr= 605.44
2026-05-11 18:22:04,850 - INFO -     [Round 3000] w/o 桅: Val= 74,861,716.4  EstErr= 690.76
2026-05-11 18:22:06,504 - INFO -     [Round 3500] w/o 桅: Val= 94,953,420.9  EstErr= 756.42
2026-05-11 18:22:08,182 - INFO -     [Round 4000] w/o 桅: Val=114,806,603.6  EstErr= 801.05
2026-05-11 18:22:09,848 - INFO -     [Round 4500] w/o 桅: Val=135,833,045.7  EstErr= 849.47
2026-05-11 18:22:11,519 - INFO -     [Round 5000] w/o 桅: Val=155,522,669.8  EstErr= 875.96
2026-05-11 18:22:13,160 - INFO -     [Round 500] w/o 桅: Val=  9,652,555.9  EstErr= 621.59
2026-05-11 18:22:14,739 - INFO -     [Round 1000] w/o 桅: Val= 19,731,959.5  EstErr= 604.66
2026-05-11 18:22:16,340 - INFO -     [Round 1500] w/o 桅: Val= 29,221,751.5  EstErr= 589.96
2026-05-11 18:22:17,925 - INFO -     [Round 2000] w/o 桅: Val= 39,297,097.6  EstErr= 587.64
2026-05-11 18:22:19,515 - INFO -     [Round 2500] w/o 桅: Val= 49,539,052.5  EstErr= 586.78
2026-05-11 18:22:21,187 - INFO -     [Round 3000] w/o 桅: Val= 69,715,167.7  EstErr= 691.15
2026-05-11 18:22:22,851 - INFO -     [Round 3500] w/o 桅: Val= 90,075,289.8  EstErr= 766.47
2026-05-11 18:22:24,528 - INFO -     [Round 4000] w/o 桅: Val=109,356,072.7  EstErr= 807.87
2026-05-11 18:22:26,194 - INFO -     [Round 4500] w/o 桅: Val=129,011,584.9  EstErr= 843.99
2026-05-11 18:22:27,858 - INFO -     [Round 5000] w/o 桅: Val=149,676,017.2  EstErr= 883.56
2026-05-11 18:22:29,503 - INFO -     [Round 500] w/o 桅: Val=  9,842,097.3  EstErr= 628.28
2026-05-11 18:22:31,092 - INFO -     [Round 1000] w/o 桅: Val= 20,475,661.0  EstErr= 616.04
2026-05-11 18:22:32,689 - INFO -     [Round 1500] w/o 桅: Val= 30,832,095.2  EstErr= 607.81
2026-05-11 18:22:34,276 - INFO -     [Round 2000] w/o 桅: Val= 41,451,458.1  EstErr= 602.50
2026-05-11 18:22:35,871 - INFO -     [Round 2500] w/o 桅: Val= 52,104,426.9  EstErr= 601.36
2026-05-11 18:22:37,556 - INFO -     [Round 3000] w/o 桅: Val= 72,822,061.8  EstErr= 703.80
2026-05-11 18:22:39,224 - INFO -     [Round 3500] w/o 桅: Val= 93,688,375.7  EstErr= 775.89
2026-05-11 18:22:40,888 - INFO -     [Round 4000] w/o 桅: Val=114,678,552.0  EstErr= 830.99
2026-05-11 18:22:42,587 - INFO -     [Round 4500] w/o 桅: Val=135,783,055.1  EstErr= 875.22
2026-05-11 18:22:44,264 - INFO -     [Round 5000] w/o 桅: Val=156,079,961.7  EstErr= 902.19
2026-05-11 18:22:45,912 - INFO -     [Round 500] w/o 桅: Val= 10,559,494.5  EstErr= 658.55
2026-05-11 18:22:47,509 - INFO -     [Round 1000] w/o 桅: Val= 21,980,775.5  EstErr= 629.70
2026-05-11 18:22:49,104 - INFO -     [Round 1500] w/o 桅: Val= 33,379,386.2  EstErr= 622.50
2026-05-11 18:22:50,713 - INFO -     [Round 2000] w/o 桅: Val= 43,674,732.0  EstErr= 607.95
2026-05-11 18:22:52,305 - INFO -     [Round 2500] w/o 桅: Val= 55,327,636.8  EstErr= 608.22
2026-05-11 18:22:53,994 - INFO -     [Round 3000] w/o 桅: Val= 76,220,980.1  EstErr= 710.82
2026-05-11 18:22:55,667 - INFO -     [Round 3500] w/o 桅: Val= 97,127,875.6  EstErr= 781.43
2026-05-11 18:22:57,350 - INFO -     [Round 4000] w/o 桅: Val=117,238,690.3  EstErr= 822.34
2026-05-11 18:22:59,044 - INFO -     [Round 4500] w/o 桅: Val=138,191,776.7  EstErr= 861.99
2026-05-11 18:23:00,727 - INFO -     [Round 5000] w/o 桅: Val=158,716,197.0  EstErr= 890.09
2026-05-11 18:23:02,428 - INFO -     [Round 500] w/o 桅: Val= 10,365,860.0  EstErr= 628.56
2026-05-11 18:23:04,009 - INFO -     [Round 1000] w/o 桅: Val= 20,947,270.1  EstErr= 605.36
2026-05-11 18:23:05,603 - INFO -     [Round 1500] w/o 桅: Val= 31,808,064.9  EstErr= 602.69
2026-05-11 18:23:07,232 - INFO -     [Round 2000] w/o 桅: Val= 42,164,578.3  EstErr= 594.26
2026-05-11 18:23:08,841 - INFO -     [Round 2500] w/o 桅: Val= 53,547,225.7  EstErr= 596.92
2026-05-11 18:23:10,525 - INFO -     [Round 3000] w/o 桅: Val= 73,235,564.1  EstErr= 690.04
2026-05-11 18:23:12,195 - INFO -     [Round 3500] w/o 桅: Val= 92,778,208.1  EstErr= 748.75
2026-05-11 18:23:13,865 - INFO -     [Round 4000] w/o 桅: Val=112,012,737.5  EstErr= 789.16
2026-05-11 18:23:15,558 - INFO -     [Round 4500] w/o 桅: Val=131,981,415.6  EstErr= 828.06
2026-05-11 18:23:17,245 - INFO -     [Round 5000] w/o 桅: Val=152,404,470.5  EstErr= 859.65
2026-05-11 18:24:40,550 - INFO -    w/o 桅                 Val=153,981,420.5  EstErr= 872.58  Var=51538047.8
2026-05-11 18:24:41,976 - INFO -     [Round 500] w/o StabRep: Val= 12,160,694.8  EstErr= 620.69
2026-05-11 18:24:43,413 - INFO -     [Round 1000] w/o StabRep: Val= 25,548,819.7  EstErr= 595.85
2026-05-11 18:24:44,835 - INFO -     [Round 1500] w/o StabRep: Val= 39,148,018.6  EstErr= 577.22
2026-05-11 18:24:46,263 - INFO -     [Round 2000] w/o StabRep: Val= 53,647,150.3  EstErr= 577.53
2026-05-11 18:24:47,707 - INFO -     [Round 2500] w/o StabRep: Val= 68,209,462.2  EstErr= 577.56
2026-05-11 18:24:49,221 - INFO -     [Round 3000] w/o StabRep: Val= 86,183,543.5  EstErr= 667.71
2026-05-11 18:24:50,738 - INFO -     [Round 3500] w/o StabRep: Val=105,955,194.9  EstErr= 730.95
2026-05-11 18:24:52,254 - INFO -     [Round 4000] w/o StabRep: Val=127,378,894.8  EstErr= 789.15
2026-05-11 18:24:53,778 - INFO -     [Round 4500] w/o StabRep: Val=148,411,170.8  EstErr= 831.81
2026-05-11 18:24:55,306 - INFO -     [Round 5000] w/o StabRep: Val=170,729,121.3  EstErr= 876.30
2026-05-11 18:24:56,812 - INFO -     [Round 500] w/o StabRep: Val= 11,581,712.7  EstErr= 607.65
2026-05-11 18:24:58,243 - INFO -     [Round 1000] w/o StabRep: Val= 24,315,769.6  EstErr= 572.93
2026-05-11 18:24:59,682 - INFO -     [Round 1500] w/o StabRep: Val= 37,571,784.2  EstErr= 564.08
2026-05-11 18:25:01,125 - INFO -     [Round 2000] w/o StabRep: Val= 51,783,930.2  EstErr= 566.82
2026-05-11 18:25:02,567 - INFO -     [Round 2500] w/o StabRep: Val= 66,034,877.2  EstErr= 565.17
2026-05-11 18:25:04,105 - INFO -     [Round 3000] w/o StabRep: Val= 84,801,657.4  EstErr= 670.12
2026-05-11 18:25:05,635 - INFO -     [Round 3500] w/o StabRep: Val=105,414,050.8  EstErr= 749.33
2026-05-11 18:25:07,162 - INFO -     [Round 4000] w/o StabRep: Val=126,704,006.5  EstErr= 812.38
2026-05-11 18:25:08,704 - INFO -     [Round 4500] w/o StabRep: Val=148,082,907.4  EstErr= 858.37
2026-05-11 18:25:10,266 - INFO -     [Round 5000] w/o StabRep: Val=169,225,414.9  EstErr= 890.74
2026-05-11 18:25:11,764 - INFO -     [Round 500] w/o StabRep: Val= 11,682,565.7  EstErr= 591.41
2026-05-11 18:25:13,224 - INFO -     [Round 1000] w/o StabRep: Val= 25,257,950.5  EstErr= 578.38
2026-05-11 18:25:14,659 - INFO -     [Round 1500] w/o StabRep: Val= 38,812,263.5  EstErr= 566.02
2026-05-11 18:25:16,094 - INFO -     [Round 2000] w/o StabRep: Val= 53,355,630.6  EstErr= 569.53
2026-05-11 18:25:17,554 - INFO -     [Round 2500] w/o StabRep: Val= 67,248,019.9  EstErr= 566.01
2026-05-11 18:25:19,085 - INFO -     [Round 3000] w/o StabRep: Val= 85,332,556.5  EstErr= 682.61
2026-05-11 18:25:20,611 - INFO -     [Round 3500] w/o StabRep: Val=104,942,457.5  EstErr= 762.40
2026-05-11 18:25:22,156 - INFO -     [Round 4000] w/o StabRep: Val=125,490,033.0  EstErr= 824.59
2026-05-11 18:25:23,674 - INFO -     [Round 4500] w/o StabRep: Val=146,266,556.2  EstErr= 878.59
2026-05-11 18:25:25,200 - INFO -     [Round 5000] w/o StabRep: Val=166,804,685.2  EstErr= 913.16
2026-05-11 18:25:26,703 - INFO -     [Round 500] w/o StabRep: Val= 12,560,575.8  EstErr= 635.36
2026-05-11 18:25:28,148 - INFO -     [Round 1000] w/o StabRep: Val= 26,144,985.4  EstErr= 598.47
2026-05-11 18:25:29,592 - INFO -     [Round 1500] w/o StabRep: Val= 39,763,860.1  EstErr= 583.88
2026-05-11 18:25:31,063 - INFO -     [Round 2000] w/o StabRep: Val= 54,295,383.8  EstErr= 582.80
2026-05-11 18:25:32,491 - INFO -     [Round 2500] w/o StabRep: Val= 68,770,246.6  EstErr= 582.13
2026-05-11 18:25:34,029 - INFO -     [Round 3000] w/o StabRep: Val= 88,730,308.9  EstErr= 716.24
2026-05-11 18:25:35,570 - INFO -     [Round 3500] w/o StabRep: Val=108,459,533.2  EstErr= 787.03
2026-05-11 18:25:37,107 - INFO -     [Round 4000] w/o StabRep: Val=129,780,403.6  EstErr= 857.13
2026-05-11 18:25:38,803 - INFO -     [Round 4500] w/o StabRep: Val=149,917,236.8  EstErr= 889.20
2026-05-11 18:25:40,329 - INFO -     [Round 5000] w/o StabRep: Val=170,818,052.0  EstErr= 918.92
2026-05-11 18:25:41,809 - INFO -     [Round 500] w/o StabRep: Val= 11,676,109.0  EstErr= 587.58
2026-05-11 18:25:43,277 - INFO -     [Round 1000] w/o StabRep: Val= 25,549,265.8  EstErr= 579.02
2026-05-11 18:25:44,731 - INFO -     [Round 1500] w/o StabRep: Val= 40,157,600.1  EstErr= 581.60
2026-05-11 18:25:46,168 - INFO -     [Round 2000] w/o StabRep: Val= 54,099,308.9  EstErr= 576.34
2026-05-11 18:25:47,624 - INFO -     [Round 2500] w/o StabRep: Val= 68,558,625.8  EstErr= 577.15
2026-05-11 18:25:49,164 - INFO -     [Round 3000] w/o StabRep: Val= 86,950,937.8  EstErr= 672.86
2026-05-11 18:25:50,696 - INFO -     [Round 3500] w/o StabRep: Val=107,648,154.0  EstErr= 747.67
2026-05-11 18:25:52,255 - INFO -     [Round 4000] w/o StabRep: Val=128,696,088.3  EstErr= 805.07
2026-05-11 18:25:53,797 - INFO -     [Round 4500] w/o StabRep: Val=149,428,673.4  EstErr= 841.89
2026-05-11 18:25:55,349 - INFO -     [Round 5000] w/o StabRep: Val=170,907,096.4  EstErr= 874.51
2026-05-11 18:27:11,045 - INFO -   w/o StabRep            Val=168,617,852.3  EstErr= 889.08  Var=50464239.8
2026-05-11 18:27:12,265 - INFO -     [Round 500] w/o Both: Val=  9,763,819.8  EstErr= 606.99
2026-05-11 18:27:13,490 - INFO -     [Round 1000] w/o Both: Val= 20,369,309.3  EstErr= 587.63
2026-05-11 18:27:14,720 - INFO -     [Round 1500] w/o Both: Val= 30,890,279.5  EstErr= 577.48
2026-05-11 18:27:15,958 - INFO -     [Round 2000] w/o Both: Val= 42,401,384.3  EstErr= 583.25
2026-05-11 18:27:17,178 - INFO -     [Round 2500] w/o Both: Val= 53,996,940.2  EstErr= 587.32
2026-05-11 18:27:18,475 - INFO -     [Round 3000] w/o Both: Val= 73,260,867.1  EstErr= 674.56
2026-05-11 18:27:19,781 - INFO -     [Round 3500] w/o Both: Val= 92,843,038.3  EstErr= 738.98
2026-05-11 18:27:21,077 - INFO -     [Round 4000] w/o Both: Val=112,454,171.7  EstErr= 785.78
2026-05-11 18:27:22,379 - INFO -     [Round 4500] w/o Both: Val=133,347,950.0  EstErr= 833.01
2026-05-11 18:27:23,696 - INFO -     [Round 5000] w/o Both: Val=153,199,785.8  EstErr= 861.84
2026-05-11 18:27:24,971 - INFO -     [Round 500] w/o Both: Val=  9,836,098.6  EstErr= 633.14
2026-05-11 18:27:26,191 - INFO -     [Round 1000] w/o Both: Val= 19,623,714.2  EstErr= 602.37
2026-05-11 18:27:27,410 - INFO -     [Round 1500] w/o Both: Val= 29,720,075.3  EstErr= 592.90
2026-05-11 18:27:28,651 - INFO -     [Round 2000] w/o Both: Val= 39,760,814.8  EstErr= 590.07
2026-05-11 18:27:29,882 - INFO -     [Round 2500] w/o Both: Val= 48,718,433.8  EstErr= 578.31
2026-05-11 18:27:31,202 - INFO -     [Round 3000] w/o Both: Val= 68,709,825.3  EstErr= 682.48
2026-05-11 18:27:32,522 - INFO -     [Round 3500] w/o Both: Val= 88,823,556.7  EstErr= 753.57
2026-05-11 18:27:33,821 - INFO -     [Round 4000] w/o Both: Val=109,727,170.4  EstErr= 818.76
2026-05-11 18:27:35,118 - INFO -     [Round 4500] w/o Both: Val=130,964,734.0  EstErr= 869.87
2026-05-11 18:27:36,440 - INFO -     [Round 5000] w/o Both: Val=150,902,990.9  EstErr= 896.64
2026-05-11 18:27:37,716 - INFO -     [Round 500] w/o Both: Val=  9,681,442.3  EstErr= 624.43
2026-05-11 18:27:38,946 - INFO -     [Round 1000] w/o Both: Val= 20,516,726.6  EstErr= 618.44
2026-05-11 18:27:40,179 - INFO -     [Round 1500] w/o Both: Val= 30,931,796.4  EstErr= 608.40
2026-05-11 18:27:41,427 - INFO -     [Round 2000] w/o Both: Val= 41,420,253.2  EstErr= 606.42
2026-05-11 18:27:42,650 - INFO -     [Round 2500] w/o Both: Val= 51,885,251.9  EstErr= 602.09
2026-05-11 18:27:43,952 - INFO -     [Round 3000] w/o Both: Val= 72,242,968.1  EstErr= 702.94
2026-05-11 18:27:45,274 - INFO -     [Round 3500] w/o Both: Val= 92,351,605.9  EstErr= 766.23
2026-05-11 18:27:46,581 - INFO -     [Round 4000] w/o Both: Val=113,811,479.9  EstErr= 828.95
2026-05-11 18:27:47,887 - INFO -     [Round 4500] w/o Both: Val=134,642,866.3  EstErr= 869.43
2026-05-11 18:27:49,234 - INFO -     [Round 5000] w/o Both: Val=155,554,306.3  EstErr= 902.28
2026-05-11 18:27:50,511 - INFO -     [Round 500] w/o Both: Val= 10,383,796.2  EstErr= 635.34
2026-05-11 18:27:51,747 - INFO -     [Round 1000] w/o Both: Val= 21,145,627.2  EstErr= 614.16
2026-05-11 18:27:52,990 - INFO -     [Round 1500] w/o Both: Val= 32,140,515.1  EstErr= 604.50
2026-05-11 18:27:54,239 - INFO -     [Round 2000] w/o Both: Val= 43,228,164.0  EstErr= 598.62
2026-05-11 18:27:55,478 - INFO -     [Round 2500] w/o Both: Val= 54,345,719.4  EstErr= 598.37
2026-05-11 18:27:56,800 - INFO -     [Round 3000] w/o Both: Val= 74,170,225.6  EstErr= 692.02
2026-05-11 18:27:58,126 - INFO -     [Round 3500] w/o Both: Val= 94,642,005.2  EstErr= 766.96
2026-05-11 18:27:59,450 - INFO -     [Round 4000] w/o Both: Val=114,401,871.5  EstErr= 812.48
2026-05-11 18:28:00,783 - INFO -     [Round 4500] w/o Both: Val=134,132,736.1  EstErr= 846.71
2026-05-11 18:28:02,120 - INFO -     [Round 5000] w/o Both: Val=153,854,233.5  EstErr= 875.42
2026-05-11 18:28:03,435 - INFO -     [Round 500] w/o Both: Val= 10,212,176.5  EstErr= 628.04
2026-05-11 18:28:04,725 - INFO -     [Round 1000] w/o Both: Val= 21,081,423.5  EstErr= 614.52
2026-05-11 18:28:06,034 - INFO -     [Round 1500] w/o Both: Val= 31,556,698.2  EstErr= 600.52
2026-05-11 18:28:07,290 - INFO -     [Round 2000] w/o Both: Val= 42,420,547.3  EstErr= 596.95
2026-05-11 18:28:08,593 - INFO -     [Round 2500] w/o Both: Val= 53,556,005.1  EstErr= 600.40
2026-05-11 18:28:09,964 - INFO -     [Round 3000] w/o Both: Val= 74,001,894.3  EstErr= 695.26
2026-05-11 18:28:11,303 - INFO -     [Round 3500] w/o Both: Val= 94,257,466.4  EstErr= 754.28
2026-05-11 18:28:12,640 - INFO -     [Round 4000] w/o Both: Val=115,875,600.4  EstErr= 811.12
2026-05-11 18:28:13,975 - INFO -     [Round 4500] w/o Both: Val=136,232,285.0  EstErr= 841.41
2026-05-11 18:28:15,310 - INFO -     [Round 5000] w/o Both: Val=156,796,456.5  EstErr= 869.92
2026-05-11 18:29:21,105 - INFO -   w/o Both              Val=153,570,573.2  EstErr= 871.23  Var=51402427.5
"""

def parse_and_plot():
    print("🎨 正在解析实验 7 日志并生成 1x3 机制消融图表 (已优化颜色映射)...")
    
    trajectory_data = defaultdict(lambda: defaultdict(lambda: {'val': [], 'err': []}))
    final_vars = {}
    
    re_round = re.compile(r'\[Round\s+(\d+)\]\s+(.*?):\s+Val=\s*([\d,.]+)\s+EstErr=\s*([\d.]+)')
    re_final = re.compile(r'-\s+INFO\s+-\s+(.*?)\s+Val=[\d,.]+\s+EstErr=\s*[\d.]+\s+Var=\s*([\d.]+)')
    
    for line in LOG_TEXT.strip().split('\n'):
        # 修复终端乱码并对齐名称
        line = line.replace('w/o 桅', r'w/o $\Phi$')
        line = line.replace('POETIC (Full)', 'POETIC')
        
        match = re_round.search(line)
        if match:
            rnd = int(match.group(1))
            method = match.group(2).strip()
            val = float(match.group(3).replace(',', ''))
            err = float(match.group(4))
            
            trajectory_data[method][rnd]['val'].append(val)
            trajectory_data[method][rnd]['err'].append(err)
            
        var_match = re_final.search(line)
        if var_match and "Round" not in line:
            method = var_match.group(1).strip()
            var_val = float(var_match.group(2))
            final_vars[method] = var_val

    methods_order = ['POETIC', r'w/o $\Phi$', 'w/o StabRep', 'w/o Both']
    rounds = sorted(list(trajectory_data['POETIC'].keys()))
    
    mean_val = {m: [] for m in methods_order}
    mean_err = {m: [] for m in methods_order}
    
    for m in methods_order:
        for r in rounds:
            mean_val[m].append(np.mean(trajectory_data[m][r]['val']) / 1e6) 
            mean_err[m].append(np.mean(trajectory_data[m][r]['err']))

    fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))
    ax_u, ax_e, ax_v = axes[0], axes[1], axes[2]
    
    for m in methods_order:
        st = STYLES[m]
        # (a) & (b) 折线图绘制，丢弃 hatch 参数
        plot_kwargs = {k:v for k,v in st.items() if k != 'hatch'}
        ax_u.plot(rounds, mean_val[m], label=m, **plot_kwargs)
        ax_e.plot(rounds, mean_err[m], label=m, **plot_kwargs)
        
    ax_u.set_title("(a) Cumulative Utility (Mechanism Ablation)")
    ax_u.set_ylabel(r"Cumulative Utility ($10^6$)")
    ax_u.set_xlabel("Rounds")
    ax_u.legend(loc='upper left', fontsize=9)
    
    ax_e.set_title("(b) Estimation Error (Mechanism Ablation)")
    ax_e.set_ylabel("Mean Estimation Error")
    ax_e.set_xlabel("Rounds")
    
    # ── (c) Learning Variance (Bar Chart) 完美对齐并加上纹理 ──
    var_vals = [final_vars[m] / 1e7 for m in methods_order]
    
    # 提取专属颜色
    colors = [STYLES[m]['color'] for m in methods_order]
    
    bars = ax_v.bar(methods_order, var_vals, color=colors, edgecolor='black', linewidth=1.5, alpha=0.85, width=0.6)
    
    # 🔥 核心：为每根柱子打上独特的专属纹理 (Hatch) 
    for bar, m in zip(bars, methods_order):
        if STYLES[m].get("hatch"):
            bar.set_hatch(STYLES[m]["hatch"])
            
    ax_v.set_title("(c) Learning Variance")
    ax_v.set_ylabel(r"Variance ($10^7$)")
    ax_v.set_xticklabels(methods_order, rotation=15, ha='right')
    
    plt.tight_layout()
    
    out_dir = r"d:\src\paper"
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "fig7_mechanism_ablation.pdf")
    plt.savefig(out_path)
    print(f"✅ 图表已生成并保存至：{out_path}")

if __name__ == "__main__":
    parse_and_plot()