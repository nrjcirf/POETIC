import os
import logging
import datetime
import numpy as np
import matplotlib.pyplot as plt
import time

from config import Config
from data_loader import get_dataloader
from visualization import Visualizer
from worker import Worker
from poe_platform import POEPlatform
from baselines import POETICSlow, PrivCO, TruthfulDPMAB
from experiments_icde import _sim

# Setup logging
log_filename = f"logs/efficiency_exp_{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}.txt"
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_filename, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("EfficiencyExp")

def run_efficiency_experiment(config, visualizer, log_path, dataset_type='NYC', varying_param='N'):
    """
    Run efficiency experiments (Runtime & Comm Cost) varying either N (num workers) or k (num winners).
    """
    T_rounds = 50  # We only need a few rounds to get the average simulated runtime/comm cost

    if varying_param == 'N':
        param_values = [1000, 2000, 3000, 4000, 5000]
        logging.info(f"\n=== Efficiency vs N (Dataset: {dataset_type}) ===")
    else: # varying k
        param_values = [10, 20, 30, 40, 50]
        config.DEFAULT_NUM_WORKERS = 2000
        logging.info(f"\n=== Efficiency vs k (Dataset: {dataset_type}, N=2000) ===")

    # Load dataset to get realistic active worker dynamics
    logging.info(f"Loading {dataset_type} dataset context...")
    data_loader = get_dataloader(config, dataset_type=dataset_type)

    results_runtime = {'POETIC': [], 'POETIC-slow': [], 'PrivCO': [], 'Truthful-DP-MAB': []}
    results_comm = {'POETIC': [], 'POETIC-slow': [], 'PrivCO': [], 'Truthful-DP-MAB': []}

    for val in param_values:
        if varying_param == 'N':
            config.DEFAULT_NUM_WORKERS = val
            k = config.DEFAULT_NUM_WINNERS
        else:
            k = val
        
        logging.info(f"  Testing {varying_param} = {val} ...")
        all_worker_ids = [f"W{i}" for i in range(config.DEFAULT_NUM_WORKERS)]
        workers = {wid: Worker(wid, config) for wid in all_worker_ids}

        models = {
            'POETIC': POEPlatform(config, all_worker_ids, name="POETIC"),
            'POETIC-slow': POETICSlow(config, all_worker_ids),
            'PrivCO': PrivCO(config),
            'Truthful-DP-MAB': TruthfulDPMAB(config, all_worker_ids)
        }

        for m_name, model in models.items():
            # Run simulation
            _sim(model, workers, config, data_loader=data_loader, T=T_rounds, num_winners=k)
            
            # Extract theoretical simulated overheads
            rt_history = getattr(model, 'runtime_history', [0])
            cc_history = getattr(model, 'comm_cost_history', [0])
            
            avg_rt = np.mean(rt_history) if rt_history else 0.0
            avg_cc = np.mean(cc_history) if cc_history else 0.0
            
            results_runtime[m_name].append(avg_rt)
            results_comm[m_name].append(avg_cc)
            logging.info(f"    {m_name:15s}: Avg Runtime={avg_rt:.2f} ms, Avg Comm={avg_cc:.2f} MB")

    return param_values, results_runtime, results_comm

def plot_efficiency_results(N_vals, k_vals, res_nyc_N, res_tdrive_N, res_nyc_k, res_tdrive_k, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    
    # Matching ICDE-STRICT GLOBAL SETTINGS
    STYLES = {
        'POETIC':              {'color': '#1f77b4', 'ls': '-',  'marker': 'o', 'lw': 2.5, 'label': 'POETIC'},
        'POETIC-slow':         {'color': '#ff7f0e', 'ls': '--', 'marker': 's', 'lw': 2.0, 'label': 'POETIC-slow'},
        'PrivCO':              {'color': '#2ca02c', 'ls': '-.', 'marker': 'D', 'lw': 2.0, 'label': 'PrivCO'},
        'Truthful-DP-MAB':     {'color': '#d62728', 'ls': ':',  'marker': 'x', 'lw': 2.0, 'label': 'Truthful-DP-MAB'},
    }

    import matplotlib as mpl
    plt.style.use('seaborn-v0_8-white')
    mpl.rcParams['font.family'] = 'serif'
    mpl.rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif']
    mpl.rcParams['axes.labelsize'] = 14
    mpl.rcParams['axes.titlesize'] = 16
    mpl.rcParams['legend.fontsize'] = 11
    mpl.rcParams['xtick.labelsize'] = 12
    mpl.rcParams['ytick.labelsize'] = 12
    mpl.rcParams['grid.alpha'] = 0.6
    mpl.rcParams['grid.linestyle'] = ':'
    mpl.rcParams['axes.grid'] = True

    # 1. Plot Runtime vs N (Two Subplots for Datasets)
    fig, axes = plt.subplots(1, 2, figsize=(13, 5), gridspec_kw={'wspace': 0.22})
    for ax, dataset, res in zip(axes, ['NYC', 'T-Drive'], [res_nyc_N[0], res_tdrive_N[0]]):
        for m_name, vals in res.items():
            st = STYLES[m_name]
            ax.plot(N_vals, vals, color=st['color'], ls=st['ls'], marker=st['marker'], 
                    lw=st['lw'], label=st['label'], markersize=7)
        ax.set_title(f'Runtime vs N ({dataset})')
        ax.set_xlabel('Total Number of Workers (N)')
        ax.set_ylabel('Avg. Runtime per Round (ms)')
        ax.legend(loc='upper left', frameon=True, edgecolor='black', fontsize=10)
    
    plt.savefig(os.path.join(output_dir, 'efficiency_runtime_vs_N.png'), bbox_inches='tight', dpi=300)
    plt.close()

    # 2. Plot Comm Cost vs N (Two Subplots for Datasets)
    fig, axes = plt.subplots(1, 2, figsize=(13, 5), gridspec_kw={'wspace': 0.22})
    for ax, dataset, res in zip(axes, ['NYC', 'T-Drive'], [res_nyc_N[1], res_tdrive_N[1]]):
        for m_name, vals in res.items():
            st = STYLES[m_name]
            ax.plot(N_vals, vals, color=st['color'], ls=st['ls'], marker=st['marker'], 
                    lw=st['lw'], label=st['label'], markersize=7)
        ax.set_title(f'Communication Cost vs N ({dataset})')
        ax.set_xlabel('Total Number of Workers (N)')
        ax.set_ylabel('Avg. Comm. Cost (MB)')
        ax.legend(loc='upper left', frameon=True, edgecolor='black', fontsize=10)
    
    plt.savefig(os.path.join(output_dir, 'efficiency_comm_vs_N.png'), bbox_inches='tight', dpi=300)
    plt.close()

    # 3. Plot Runtime vs k (Two Subplots for Datasets)
    fig, axes = plt.subplots(1, 2, figsize=(13, 5), gridspec_kw={'wspace': 0.22})
    for ax, dataset, res in zip(axes, ['NYC', 'T-Drive'], [res_nyc_k[0], res_tdrive_k[0]]):
        for m_name, vals in res.items():
            st = STYLES[m_name]
            ax.plot(k_vals, vals, color=st['color'], ls=st['ls'], marker=st['marker'], 
                    lw=st['lw'], label=st['label'], markersize=7)
        ax.set_title(f'Runtime vs k ({dataset}, N=2000)')
        ax.set_xlabel('Target Number of Winners (k)')
        ax.set_ylabel('Avg. Runtime per Round (ms)')
        ax.legend(loc='upper left', frameon=True, edgecolor='black', fontsize=10)
    
    plt.savefig(os.path.join(output_dir, 'efficiency_runtime_vs_k.png'), bbox_inches='tight', dpi=300)
    plt.close()

if __name__ == "__main__":
    config = Config()
    vis = Visualizer(config)
    log_path = os.path.join(config.RESULTS_DIR, "efficiency_experiments.txt")
    
    # Fix bug where fonttools logs too much
    logging.getLogger('fontTools').setLevel(logging.WARNING)
    logging.getLogger('matplotlib').setLevel(logging.WARNING)

    logging.info("Starting Efficiency Experiments (Runtime & Communication Cost)...")

    # 1. Varying N on NYC
    N_vals, rt_nyc_N, cc_nyc_N = run_efficiency_experiment(config, vis, log_path, dataset_type='NYC', varying_param='N')
    
    # 2. Varying N on T-Drive
    _, rt_tdrive_N, cc_tdrive_N = run_efficiency_experiment(config, vis, log_path, dataset_type='TDrive', varying_param='N')

    # 3. Varying k on NYC
    k_vals, rt_nyc_k, cc_nyc_k = run_efficiency_experiment(config, vis, log_path, dataset_type='NYC', varying_param='k')

    # 4. Varying k on T-Drive
    _, rt_tdrive_k, cc_tdrive_k = run_efficiency_experiment(config, vis, log_path, dataset_type='TDrive', varying_param='k')

    # Plot all results
    plot_efficiency_results(
        N_vals, k_vals,
        (rt_nyc_N, cc_nyc_N),
        (rt_tdrive_N, cc_tdrive_N),
        (rt_nyc_k, cc_nyc_k),
        (rt_tdrive_k, cc_tdrive_k),
        config.FIGURES_DIR
    )
    
    logger.info(f"Efficiency log saved to: {log_filename}")
    logger.info(f"Done! Plots saved to {config.FIGURES_DIR}")
