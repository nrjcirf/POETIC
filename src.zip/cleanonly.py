# cleanonly.py
"""
Run the clean (r=0%) environment experiment on one dataset and
print / save cumulative-value, regret, and EstErr metrics.

Usage:
    python cleanonly.py              # NYC, num_runs=3
    python cleanonly.py TDrive       # T-Drive, num_runs=3
    python cleanonly.py NYC 1        # NYC, num_runs=1 (quick)
"""
import os
import sys
import random
import numpy as np
import logging
import json
import time

from config import Config
from data_loader import get_dataloader
from visualization import Visualizer
from metrics import Metrics
from experiments_icde import _fw, _sim, _avg, _poetic, _baselines, _regret

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

SEED = 42


def run_clean_full(config, data_loader, num_runs=3, dataset_label='NYC'):
    """
    Clean environment (r=0%): evaluate all models and compute
    cumulative value, regret, and EstErr.
    """
    N, T = config.DEFAULT_NUM_WORKERS, config.TOTAL_ROUNDS

    models = {'POETIC': _poetic(config, N), **_baselines(config, N)}

    logging.info(f"\n{'='*68}")
    logging.info(f"  Clean-env experiment  |  Dataset={dataset_label}  T={T}  N={N}  runs={num_runs}")
    logging.info(f"{'='*68}")

    results = {}
    for name, model in models.items():
        runs = []
        for ri in range(num_runs):
            random.seed(SEED + ri)
            np.random.seed(SEED + ri)
            workers = _fw(N, config)
            # adv=[] → all workers are truthful
            runs.append(_sim(model, workers, config,
                             data_loader=data_loader, T=T))
        results[name] = _avg(runs)
        ee = Metrics.calculate_mean_estimation_error(
            results[name]['estimation_error_history'])
        logging.info(f"  {name:30s}  Val={results[name]['final_cumulative_value']:>13,.1f}"
                     f"  EstErr={ee:>7.2f}")

    # ── Regret (vs Non-Private Optimal) ──────────────────────────────
    regret = _regret(results, opt='Non-Private Optimal')

    # ── Summary table ─────────────────────────────────────────────────
    opt_cv = results.get('Non-Private Optimal', {}).get('final_cumulative_value', 0.0)
    logging.info(f"\n  {'Model':30s}  {'Cum. Value':>15}  {'EstErr':>10}  {'Regret':>15}")
    logging.info(f"  {'-'*30}  {'-'*15}  {'-'*10}  {'-'*15}")
    for name, res in results.items():
        ee = Metrics.calculate_mean_estimation_error(res['estimation_error_history'])
        rg = opt_cv - res['final_cumulative_value'] if name != 'Non-Private Optimal' else 0.0
        logging.info(f"  {name:30s}  {res['final_cumulative_value']:>15,.1f}"
                     f"  {ee:>10.2f}  {rg:>15,.1f}")

    return results, regret


def main():
    dataset_label = sys.argv[1] if len(sys.argv) > 1 else 'NYC'
    num_runs      = int(sys.argv[2]) if len(sys.argv) > 2 else 3

    config    = Config()
    os.makedirs(config.FIGURES_DIR, exist_ok=True)
    os.makedirs(config.LOGS_DIR, exist_ok=True)

    data_loader = get_dataloader(config, dataset_type=dataset_label)
    visualizer  = Visualizer(config)

    results, regret = run_clean_full(config, data_loader,
                                     num_runs=num_runs,
                                     dataset_label=dataset_label)

    # ── Save JSON ─────────────────────────────────────────────────────
    os.makedirs('results', exist_ok=True)
    ts = time.strftime('%Y%m%d_%H%M%S')

    # _regret() returns per-round cumulative regret arrays for every non-optimal model
    # regret dict: {model_name: [per_round_regret_t1, t2, ...]}
    summary = {}
    for name, res in results.items():
        ee  = Metrics.calculate_mean_estimation_error(res['estimation_error_history'])
        rg_curve = regret.get(name, [])          # per-round cumulative regret array
        rg_final = rg_curve[-1] if rg_curve else 0.0

        step = max(1, len(res['cumulative_value']) // 10)
        summary[name] = {
            'final_cumulative_value':  res['final_cumulative_value'],
            'mean_estimation_error':   ee,
            'final_regret':            rg_final,
            # 10-checkpoint curves (every 10% of T)
            'cumulative_value_curve':  res['cumulative_value'][::step][:10],
            'estimation_error_curve':  res['estimation_error_history'][::step][:10],
            'regret_curve':            rg_curve[::step][:10],   # per-round cumulative regret
        }

    json_path = f'results/clean_{dataset_label}_{ts}.json'
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump({'dataset': dataset_label, 'num_runs': num_runs,
                   'T': config.TOTAL_ROUNDS, 'N': config.DEFAULT_NUM_WORKERS,
                   'results': summary}, f, indent=2, ensure_ascii=False)
    logging.info(f"\n  Results saved to: {json_path}")

    from experiments_icde import _lfmt

    # ── Visualize: cumulative value ───────────────────────────────────
    visualizer.plot_line_chart(
        _lfmt({n: r['cumulative_value'] for n, r in results.items()},
              'final_cumulative_value'),
        range(1, config.TOTAL_ROUNDS + 1),
        'final_cumulative_value',
        f'Cumulative Net Social Value — {dataset_label} (r=0%)',
        f'Clean Environment: Overall Performance ({dataset_label})',
        f'exp_clean_{dataset_label}_value.pdf',
        'Round t')

    # ── Visualize: per-round cumulative regret ────────────────────────
    if regret:
        visualizer.plot_line_chart(
            _lfmt(regret, 'regret'),
            range(1, config.TOTAL_ROUNDS + 1),
            'regret',
            f'Cumulative Regret — {dataset_label} (r=0%)',
            f'Clean Environment: Regret ({dataset_label})',
            f'exp_clean_{dataset_label}_regret.pdf',
            'Round t')

    # ── Visualize: EstErr curve ───────────────────────────────────────
    ee_series = {n: r['estimation_error_history']
                 for n, r in results.items()
                 if any(v > 0 for v in r['estimation_error_history'])}
    if ee_series:
        visualizer.plot_line_chart(
            _lfmt(ee_series, 'estimation_error'),
            range(1, config.TOTAL_ROUNDS + 1),
            'estimation_error',
            f'Mean Estimation Error — {dataset_label} (r=0%)',
            f'Clean Environment: EstErr ({dataset_label})',
            f'exp_clean_{dataset_label}_esterr.pdf',
            'Round t')

    logging.info("Done.")



if __name__ == '__main__':
    main()