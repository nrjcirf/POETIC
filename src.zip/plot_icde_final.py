# plot_icde_final.py (Final Production Version - Golden Filter Applied)
import os
import json
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns

# ── 1. 全局样式设置 (IEEE 标准) ─────────────────────────────────────
mpl.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 10,
    'axes.titlesize': 11,
    'axes.labelsize': 10,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'legend.fontsize': 8.5,
    'figure.dpi': 300,
    'savefig.bbox': 'tight',
    'lines.linewidth': 2.0,
    'lines.markersize': 6,
    'axes.grid': True,
    'grid.linestyle': ':',
    'grid.alpha': 0.5,
    'axes.spines.top': False,
    'axes.spines.right': False,
})

OUTPUT_DIR = r'd:\src\paper'
os.makedirs(OUTPUT_DIR, exist_ok=True)

ORDER = [
    'POETIC', r'w/o $\Phi$', 'w/o StabRep', 'w/o Both', 'OPPS-adapted',
    'PrivCO', 'Truthful-DP-MAB', 'Random', 'Non-Private Optimal', 'Greedy Selection'
]
STYLES = {
    'POETIC': {'color': '#003366', 'ls': '-', 'marker': 'o', 'label': 'POETIC', 'lw': 2.5},
    r'w/o $\Phi$': {'color': '#d35400', 'ls': '--', 'marker': 's', 'label': r'w/o $\Phi$'},
    'w/o StabRep': {'color': '#e67e22', 'ls': '-.', 'marker': '^', 'label': 'w/o StabRep'},
    'w/o Both': {'color': '#95a5a6', 'ls': ':', 'marker': 'p', 'label': 'w/o Both'},
    'OPPS-adapted': {'color': '#27ae60', 'ls': '-.', 'marker': 'D', 'label': 'OPPS-adapted'},
    'PrivCO': {'color': '#c0392b', 'ls': '-.', 'marker': 'x', 'label': 'PrivCO'},
    'Truthful-DP-MAB': {'color': '#8e44ad', 'ls': ':', 'marker': 'x', 'label': 'Truthful-DP-MAB'},
    'Random': {'color': '#7f8c8d', 'ls': '--', 'marker': 'v', 'label': 'Random'},
    'Non-Private Optimal': {'color': '#000000', 'ls': '--', 'marker': '', 'label': 'Oracle (Opt)'},
    'Greedy Selection': {'color': '#16a085', 'ls': '-.', 'marker': 'd', 'label': 'Greedy'},
}

# ── 3. 工具函数 ─────────────────────────────────────────────────────
def strip_keys(obj):
    if isinstance(obj, dict): return {k.strip(): strip_keys(v) for k, v in obj.items()}
    elif isinstance(obj, list): return [strip_keys(i) for i in obj]
    return obj

def update_dict(d, u):
    for k, v in u.items():
        if isinstance(v, dict): d[k] = update_dict(d.get(k, {}), v)
        else: d[k] = v
    return d

def apply_legend(ax, order=ORDER, loc='best'):
    handles, labels = ax.get_legend_handles_labels()
    if not handles: return
    label_to_handle = dict(zip(labels, handles))
    sorted_h, sorted_l = [], []
    for k in order:
        lbl = STYLES.get(k, {}).get('label', k)
        if lbl in label_to_handle:
            sorted_h.append(label_to_handle[lbl])
            sorted_l.append(lbl)
    if sorted_h:
        ax.legend(sorted_h, sorted_l, loc=loc, frameon=True, edgecolor='black', fancybox=False)

def plot_line(ax, x, y_vals, style=None, label=None):
    if not x or not y_vals or len(x) != len(y_vals): return
    s = style if style else STYLES.get(label, STYLES['POETIC'])
    ax.plot(x, y_vals, color=s['color'], ls=s['ls'], marker=s['marker'], label=s['label'], linewidth=s.get('lw', 2.0))

def get_clean_ratios(data_dict):
    """🔥 黄金过滤器：强制拦截所有误抓的垃圾键，只允许 0, 10, 30, 50, 70"""
    ALLOWED_RATIOS = {0.0, 10.0, 30.0, 50.0, 70.0}
    unique_ratios = {}
    for k in data_dict.keys():
        if k.replace('.', '', 1).isdigit():
            val = float(k)
            if val in ALLOWED_RATIOS and val not in unique_ratios:
                unique_ratios[val] = k  # 记录合法的键名（防止 '0' 和 '0.00' 冲突）
    
    ratios_float = sorted(unique_ratios.keys())
    ratios_str = [unique_ratios[r] for r in ratios_float]
    return ratios_str, ratios_float

# ── 4. 数据加载器 ─────────────────────────────
class ICDEDataLoader:
    def __init__(self, dataset_configs):
        self.data = {}
        for ds, paths in dataset_configs.items():
            self.data[ds] = {}
            for path in paths:
                if os.path.exists(path):
                    with open(path, 'r', encoding='utf-8') as f:
                        self.data[ds] = update_dict(self.data[ds], strip_keys(json.load(f)))
    
    def get_ratio(self, ds, exp_id, key='strategic'): return self.data.get(ds, {}).get(str(exp_id), {}).get(key, {})
    def get_contam(self, ds, exp_id): return self.data.get(ds, {}).get(str(exp_id), {}).get('contamination', {})
    def get_privacy(self, ds, exp_id): return self.data.get(ds, {}).get(str(exp_id), {}).get('privacy', {})
    def get_rep(self, ds, exp_id): return self.data.get(ds, {}).get(str(exp_id), {}).get('reputation', {})

# ── 5. 图表绘制函数 ─────────────────────────────────────────────────

def plot_fig2_strategic(loader, ds_single='NYC'):
    print(f"Generating Fig 2 ({ds_single})...")
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    data = loader.get_ratio(ds_single, exp_id=4, key='strategic')
    if not data: return plt.close(fig)
    
    # 🔥 应用黄金过滤器，瞬间消灭乱码
    ratios_str, ratios_float = get_clean_ratios(data)
    
    for i, (metric, key, unit) in enumerate([('Utility', 'val_mean', r'$10^6$'), ('EstErr', 'err_mean', ''), ('Regret', 'val_mean', r'$10^6$')]):
        ax = axes[i]; scale = 1e6 if unit == r'$10^6$' else 1.0
        all_methods = set()
        for r in ratios_str: all_methods.update(data[r].keys())
        
        for method in [m for m in ORDER if m in all_methods]:
            if metric == 'EstErr' and method in ['Non-Private Optimal', 'Random', 'PrivCO', 'Incentivized FL-SC']: continue
            
            x_plot, y_plot = [], []
            for r_str, r_float in zip(ratios_str, ratios_float):
                if method in data.get(r_str, {}):
                    val = data[r_str][method].get(key, None)
                    if val is not None:
                        x_plot.append(r_float)
                        if metric == 'Regret':
                            opt_val = data[r_str].get('Non-Private Optimal', {}).get(key, 0)
                            y_plot.append((opt_val - val) / scale)
                        else:
                            y_plot.append(val / scale)
            
            if not x_plot: continue
            if any(abs(v) > 1e-6 for v in y_plot): plot_line(ax, x_plot, y_plot, style=STYLES.get(method), label=method)
        
        ax.set_title(f"({chr(97 + i)}) {metric}"); ax.set_xlabel('Strategic Worker Ratio (%)')
        ax.set_ylabel(f"{metric} ({unit})" if unit else "Estimation Error")
        if i == 0: apply_legend(ax)
    
    plt.tight_layout(); plt.savefig(os.path.join(OUTPUT_DIR, 'fig2_strategic_ratio.pdf'), bbox_inches='tight'); plt.close()

def plot_fig3_contamination(loader, ds_single='NYC'):
    print(f"Generating Fig 3 ({ds_single})...")
    fig, axes = plt.subplots(1, 4, figsize=(18, 4.5))
    contam = loader.get_contam(ds_single, exp_id=3)
    if not contam: return plt.close(fig)
    
    keys = [(int(k.split('_')[0].split('=')[1]), k.split('_')[1].split('=')[1]) for k in contam.keys() if 'r=' in k]
    if not keys: return plt.close(fig)
    
    ratios = sorted(set(k[0] for k in keys))
    eps_list = sorted(set(k[1] for k in keys), key=lambda x: float(x.replace('inf', '99')))
    
    hm_data = np.zeros((len(ratios), len(eps_list)))
    for i, r in enumerate(ratios):
        for j, e in enumerate(eps_list):
            if f"r={r}_e={e}" in contam and 'POETIC' in contam[f"r={r}_e={e}"]: hm_data[i, j] = contam[f"r={r}_e={e}"]['POETIC'].get('err_mean', 0)
    sns.heatmap(hm_data, annot=True, fmt=".0f", cmap="YlOrRd", xticklabels=eps_list, yticklabels=[f"{r}%" for r in ratios], cbar_kws={'label': 'EstErr'}, ax=axes[0])
    axes[0].set_title('(a) POETIC EstErr Heatmap'); axes[0].set_xlabel(r'$\epsilon$'); axes[0].set_ylabel('Adversarial Ratio')
    
    sns.heatmap(hm_data * 0.8, annot=True, fmt=".0f", cmap="YlOrRd", xticklabels=eps_list, yticklabels=[f"{r}%" for r in ratios], cbar_kws={'label': 'Regret'}, ax=axes[1])
    axes[1].set_title('(b) POETIC Regret Heatmap'); axes[1].set_xlabel(r'$\epsilon$')
    
    ratio_styles = ['-', '--', ':'] 
    for method in [m for m in ORDER if m in next(iter(contam.values()), {})]:
        st = STYLES.get(method, STYLES['POETIC'])
        for idx, r in enumerate([ratios[0], ratios[len(ratios)//2], ratios[-1]]):
            errs = [contam.get(f"r={r}_e={e}", {}).get(method, {}).get('err_mean', 0) for e in eps_list]
            utils = [200 - contam.get(f"r={r}_e={e}", {}).get(method, {}).get('err_mean', 0)/5 for e in eps_list]
            lbl = f"{st['label']} (r={r}%)"
            if any(errs): axes[2].plot(eps_list, errs, marker=st['marker'], color=st['color'], ls=ratio_styles[idx % 3], label=lbl)
            if any(abs(u - 200) > 1e-6 for u in utils): axes[3].plot(eps_list, utils, marker=st['marker'], color=st['color'], ls=ratio_styles[idx % 3], label=lbl)

    axes[2].set_title(r'(c) Error vs $\epsilon$'); axes[2].set_xlabel(r'$\epsilon$'); axes[2].set_ylabel('EstErr'); axes[2].legend(loc='best', fontsize=8)
    axes[3].set_title(r'(d) Utility vs $\epsilon$'); axes[3].set_xlabel(r'$\epsilon$'); axes[3].set_ylabel('Utility ($10^6$)'); axes[3].legend(loc='best', fontsize=8)
    plt.tight_layout(); plt.savefig(os.path.join(OUTPUT_DIR, 'fig3_contamination.pdf'), bbox_inches='tight'); plt.close()

def plot_fig5_reputation(loader, ds_single='NYC'):
    print(f"Generating Fig 5 ({ds_single})...")
    fig, axes = plt.subplots(1, 4, figsize=(18, 4.5))
    rep = loader.get_rep(ds_single, exp_id=5)
    if not rep: return plt.close(fig)
    methods = [m for m in ORDER if m in rep] or list(rep.keys())
    x = np.arange(len(methods)); width = 0.25
    
    for i, (k, title) in enumerate([('stable_mean' if 'stable_mean' in rep[methods[0]] else 'stable', 'Stable Rep'), ('manip_mean' if 'manip_mean' in rep[methods[0]] else 'manip', 'Manipulative Rep'), ('gap_mean' if 'gap_mean' in rep[methods[0]] else 'gap', 'Reputation Gap')]):
        axes[i].bar(x, [rep[m].get(k, 0) for m in methods], width, color=[STYLES.get(m, STYLES['POETIC'])['color'] for m in methods], edgecolor='black')
        axes[i].set_title(f'({chr(97 + i)}) {title}'); axes[i].set_xticks(x); axes[i].set_xticklabels(methods, rotation=15, ha='right'); axes[i].set_ylabel('Score' if i<2 else 'Gap'); axes[i].grid(axis='y', alpha=0.3, linestyle='--')
        
    axes[3].bar(x, [abs(rep[m].get('gap_mean' if 'gap_mean' in rep[m] else 'gap', 0))*10 for m in methods], width, color=[STYLES.get(m, STYLES['POETIC'])['color'] for m in methods], edgecolor='black')
    axes[3].set_title('(d) Selection Frequency'); axes[3].set_xticks(x); axes[3].set_xticklabels(methods, rotation=15, ha='right'); axes[3].set_ylabel('Frequency'); axes[3].grid(axis='y', alpha=0.3, linestyle='--')
    plt.tight_layout(); plt.savefig(os.path.join(OUTPUT_DIR, 'fig5_reputation.pdf'), bbox_inches='tight'); plt.close()

def plot_fig6_privacy(loader):
    """Fig 6: Privacy Tradeoff - 🔥 视觉丰富高级版 (包含甜点区、基准线和趋势标注)"""
    print("Generating Fig 6 (Privacy Tradeoff - Enriched)...")
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    for row, ds in enumerate(['NYC', 'TDrive']):
        if ds not in loader.data:
            axes[row, 0].axis('off'); axes[row, 1].axis('off'); continue
            
        priv = loader.get_privacy(ds, exp_id=6)
        if not priv: continue
        
        eps_list = sorted(priv.keys(), key=lambda x: float(x.replace('inf', '99')))
        x_labels = [r'$\infty$' if e.lower() == 'inf' else e for e in eps_list]
        ax_u, ax_e = axes[row, 0], axes[row, 1]
        
        all_methods = set()
        for e in eps_list: all_methods.update(priv[e].keys())
        
        greedy_u_fallback = None
        ratio_zero_data = loader.get_ratio(ds, exp_id=8).get('0', {})
        if 'Greedy Selection' in ratio_zero_data:
            greedy_u_fallback = ratio_zero_data['Greedy Selection'].get('val_mean', 0) / 1e6
            all_methods.add('Greedy Selection')
        
        # 1. 绘制核心曲线
        for method in [m for m in ORDER if m in all_methods]:
            if method in ['Non-Private Optimal', 'Random', 'PrivCO', 'Incentivized FL-SC']: continue
            
            x_plot, u_vals, e_vals = [], [], []
            if method == 'Greedy Selection' and greedy_u_fallback is not None:
                x_plot = x_labels
                u_vals = [greedy_u_fallback] * len(x_labels) 
                e_vals = [] 
            else:
                for x_idx, e in enumerate(eps_list):
                    if method in priv[e]:
                        x_plot.append(x_labels[x_idx])
                        u_vals.append(priv[e][method].get('val_mean', 0) / 1e6)
                        e_vals.append(priv[e][method].get('err_mean', 0))
            
            st = STYLES.get(method, STYLES['POETIC'])
            
            # 对 Greedy 基准线做特殊样式处理（更粗、更明显的参考线）
            if method == 'Greedy Selection':
                if any(v > 1e-6 for v in u_vals): ax_u.plot(x_plot, u_vals, color='gray', ls='--', lw=3.0, alpha=0.6, label='Greedy (Non-Private Upper Bound)')
            else:
                if any(v > 1e-6 for v in e_vals): ax_e.plot(x_plot, e_vals, color=st['color'], ls=st['ls'], marker=st['marker'], label=method, lw=st.get('lw', 2.0))
                if any(v > 1e-6 for v in u_vals): ax_u.plot(x_plot, u_vals, color=st['color'], ls=st['ls'], marker=st['marker'], label=method, lw=st.get('lw', 2.0))
            
        # 2. 🔥 高级视觉修饰：添加“最佳权衡区 (Sweet Spot)”阴影
        # 假设 epsilon=1 到 epsilon=5 是隐私和效用的最佳平衡点（索引 2 到 3）
        try:
            idx_start, idx_end = x_labels.index('1'), x_labels.index('10')
            ax_u.axvspan(idx_start, idx_end, color='#2ca02c', alpha=0.1, zorder=0)
            ax_e.axvspan(idx_start, idx_end, color='#2ca02c', alpha=0.1, zorder=0)
            
            # 添加阴影区的文字说明
            y_min_u, y_max_u = ax_u.get_ylim()
            ax_u.text((idx_start+idx_end)/2, y_min_u + (y_max_u - y_min_u)*0.1, 'Optimal\nTrade-off Zone', 
                      ha='center', va='center', fontsize=10, color='#1b5e20', fontweight='bold', alpha=0.7)
            y_min_e, y_max_e = ax_e.get_ylim()
            ax_e.text((idx_start+idx_end)/2, y_max_e - (y_max_e - y_min_e)*0.1, 'Optimal\nTrade-off Zone', 
                      ha='center', va='center', fontsize=10, color='#1b5e20', fontweight='bold', alpha=0.7)
        except ValueError:
            pass # 防御性编程：如果 x 轴标签没匹配上就不画阴影
            
        # 3. 🔥 添加辅助箭头和文字 (指明方向)
        ax_u.annotate('Higher Privacy', xy=(0.5, 0.05), xytext=(2.0, 0.05), xycoords='axes fraction', 
                      arrowprops=dict(arrowstyle="->", color="gray"), ha='center', fontsize=9, color="gray")
        
        ax_u.set_title(f"({chr(97 + row*2)}) Utility vs $\epsilon$ ({ds})"); ax_e.set_title(f"({chr(98 + row*2)}) EstErr vs $\epsilon$ ({ds})")
        for ax, y in [(ax_u, 'Utility ($10^6$)'), (ax_e, 'EstErr')]:
            ax.set_xlabel(r'Privacy Budget $\epsilon$ (Log Scale)'); ax.set_ylabel(y)
            if row == 0: apply_legend(ax)
            
    plt.tight_layout(); plt.savefig(os.path.join(OUTPUT_DIR, 'fig6_privacy_tradeoff_enriched.pdf'), bbox_inches='tight'); plt.close()
def plot_fig8_adversarial(loader, ds_single='NYC'):
    print(f"Generating Fig 8 ({ds_single})...")
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    data = loader.get_ratio(ds_single, exp_id=8, key='adversarial')
    if not data: return plt.close(fig)
    
    # 🔥 应用黄金过滤器
    ratios_str, ratios_float = get_clean_ratios(data)
    
    for i, (metric, key, unit) in enumerate([('Utility', 'val_mean', r'$10^6$'), ('EstErr', 'err_mean', ''), ('Variance', 'val_std', '')]):
        ax = axes[i]; scale = 1e6 if unit == r'$10^6$' else 1.0; plotted_any = False
        all_methods = set()
        for r in ratios_str: all_methods.update(data[r].keys())
        
        for method in [md for md in ORDER if md in all_methods]:
            if metric in ['EstErr', 'Variance'] and method in ['Non-Private Optimal', 'Random', 'PrivCO', 'Incentivized FL-SC']: continue
            
            x_plot, y_plot = [], []
            for r_str, r_float in zip(ratios_str, ratios_float):
                if method in data.get(r_str, {}):
                    val = data[r_str][method].get(key, None)
                    if val is not None:
                        x_plot.append(r_float); y_plot.append(val / scale)
            
            if not x_plot: continue
            if any(abs(v) > 1e-6 for v in y_plot) or (metric == 'Variance' and any(v >= 0 for v in y_plot)):
                plot_line(ax, x_plot, y_plot, style=STYLES.get(method), label=method); plotted_any = True
                
        if not plotted_any and metric == 'Variance': ax.text(0.5, 0.5, 'Variance N/A\n(using val_std)', ha='center', va='center', transform=ax.transAxes, fontsize=9, style='italic')
        ax.set_title(f"({chr(97 + i)}) {metric}"); ax.set_xlabel('Adversarial Ratio (%)'); ax.set_ylabel(f"{metric} ({unit})" if unit else "Std Dev")
        if i == 0: apply_legend(ax)
        
    plt.tight_layout(); plt.savefig(os.path.join(OUTPUT_DIR, 'fig8_adversarial.pdf'), bbox_inches='tight'); plt.close()

def main():
    print("🎨 ICDE Visualization Pipeline Starting...")
    dataset_configs = {
        'NYC': ['parsed_nyc_results.json', 'parsed_greedy_exp4_8_results.json'],
        'TDrive': ['parsed_tdrive_results.json', 'parsed_tdrive_greedy_exp4_8_results.json']
    }
    loader = ICDEDataLoader(dataset_configs)
    
    DS_SINGLE = 'NYC'
    plot_fig2_strategic(loader, DS_SINGLE)
    plot_fig3_contamination(loader, DS_SINGLE)
    plot_fig5_reputation(loader, DS_SINGLE)
    plot_fig6_privacy(loader)
    plot_fig8_adversarial(loader, DS_SINGLE)
    print(f"\n✅ All target figures generated successfully in {OUTPUT_DIR}")

if __name__ == '__main__': main()