# src/vis_ablation.py
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import os
import pandas as pd


class AblationVisualizer:
    # --- 1. 专用配色方案 ---
    # POETIC-Final (红色), POETIC-Base (蓝色), POETIC-Base + Explore (绿色)
    ABLATION_STYLES = {
        "POETIC-Final": {
            'color': '#d62728', 'linestyle': '-', 'marker': 'o',
            'linewidth': 2.5, 'zorder': 10, 'label': 'POETIC (Final)'
        },
        "POETIC-Base": {
            'color': '#1f77b4', 'linestyle': '--', 'marker': 's',
            'linewidth': 2.0, 'zorder': 8, 'label': 'POETIC (Base)'
        },
        "POETIC-Base + Explore": {
            'color': '#2ca02c', 'linestyle': '-.', 'marker': '^',
            'linewidth': 2.0, 'zorder': 9, 'label': 'POETIC (Base + Explore)'
        },
    }

    # 强制排序
    ORDERED_MODELS = ["POETIC-Final", "POETIC-Base + Explore", "POETIC-Base"]

    def __init__(self, config):
        self.config = config
        self.figures_dir = self.config.FIGURES_DIR
        os.makedirs(self.figures_dir, exist_ok=True)

        # --- 2. 黑色实线外框风格设置 ---
        plt.rcdefaults()
        sns.set_style("whitegrid")
        plt.rcParams.update({
            'font.family': 'serif',
            'font.serif': ['Times New Roman', 'DejaVu Serif'],
            'font.size': 14,
            'axes.labelsize': 18,
            'axes.titlesize': 20,
            'legend.fontsize': 13,
            'xtick.labelsize': 14,
            'ytick.labelsize': 14,
            'figure.dpi': 300,
            'lines.linewidth': 2.0,

            # 关键：黑色边框
            'axes.edgecolor': 'black',
            'axes.linewidth': 1.5,
            'axes.spines.bottom': True,
            'axes.spines.left': True,
            'axes.spines.right': True,
            'axes.spines.top': True,

            'axes.grid': True,
            'grid.linestyle': '--',
            'grid.alpha': 0.6,
            'pdf.fonttype': 42,
            'ps.fonttype': 42
        })

    def _get_style(self, name):
        """获取样式，如果没有定义则返回默认"""
        return self.ABLATION_STYLES.get(name, {'color': 'gray', 'linestyle': ':'})

    def plot_ablation_study(self, agg_results, title, filename):
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 10), sharex=True)

        # 按照指定顺序绘图
        # 如果数据里有我们没定义的模型，放到最后
        present_models = list(agg_results.keys())
        sorted_models = sorted(present_models,
                               key=lambda x: self.ORDERED_MODELS.index(x) if x in self.ORDERED_MODELS else 999)

        # --- 子图 1: Platform Value ---
        max_val = 0
        for name in sorted_models:
            data = agg_results[name].get('cumulative_value_runs', [])
            if not data: continue

            style = self._get_style(name)
            # 绘制均值线
            self._plot_curve(ax1, data, name, style)

            # 计算最大值用于调整坐标轴
            current_max = np.max(np.mean(data, axis=0)) if len(data) > 0 else 0
            max_val = max(max_val, current_max)

        ax1.set_title("(a) Impact on Platform Value")
        ax1.set_ylabel("Mean Cumulative Value")
        ax1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
        if max_val > 0: ax1.set_xlim(left=0)

        # --- 子图 2: Worker Incentives ---
        for name in sorted_models:
            data = agg_results[name].get('worker_profit_history_agg_runs', [])
            if not data: continue

            style = self._get_style(name)
            # 利润曲线通常比较抖动，不需要 marker，可以平滑一下
            plot_style = style.copy()
            plot_style['marker'] = ''

            # 简单平滑处理
            self._plot_curve(ax2, data, name, plot_style, smooth=True)

        ax2.set_title("(b) Impact on Worker Incentives")
        ax2.set_ylabel("Mean Avg Profit (Smoothed)")
        ax2.set_xlabel("Rounds")
        if max_val > 0: ax2.set_xlim(left=0)

        # --- 共享图例 (放在底部) ---
        handles, labels = ax1.get_legend_handles_labels()
        if handles:
            fig.legend(handles, labels, loc='lower center', bbox_to_anchor=(0.5, 0.02),
                       ncol=len(handles), frameon=False)

        plt.subplots_adjust(bottom=0.15, hspace=0.2)

        # 保存
        full_path = os.path.join(self.figures_dir, filename)
        fig.savefig(full_path, bbox_inches='tight', dpi=300)
        print(f"Saved figure to {full_path}")
        plt.close(fig)

    def _plot_curve(self, ax, data_runs, label, style, smooth=False):
        """辅助绘图函数"""
        try:
            # 确保数据对齐
            min_len = min(len(r) for r in data_runs)
            truncated = [np.array(r).flatten()[:min_len] for r in data_runs]

            mean_curve = np.mean(truncated, axis=0)
            x = np.arange(len(mean_curve))

            if smooth:
                # 简单的移动平均平滑
                window = max(1, int(len(mean_curve) * 0.05))
                mean_curve = pd.Series(mean_curve).rolling(window=window, min_periods=1).mean().to_numpy()

            # 稀疏化 marker
            plot_kwargs = {k: v for k, v in style.items() if v is not None and k != 'label'}
            markevery = max(1, len(x) // 10) if style.get('marker') else None

            ax.plot(x, mean_curve, label=style.get('label', label), markevery=markevery, **plot_kwargs)

            # 可选：绘制阴影 (std)
            # std_curve = np.std(truncated, axis=0)
            # ax.fill_between(x, mean_curve - std_curve, mean_curve + std_curve, color=style['color'], alpha=0.15)

        except Exception as e:
            print(f"Error plotting {label}: {e}")