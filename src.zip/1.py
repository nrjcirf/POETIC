# src/main.py
import os
import numpy as np
import time
from tqdm import tqdm
import random
import logging

from src.config import Config
from src.worker import Worker
from platform import Platform
from src.metrics import Metrics
from src.visualization import Visualizer
from src.baselines import BaseBaseline, NonPrivateOptimal, RandomModel, PrivCO, POETICSlow, OPPSAdapted, \
    IncentivizedFLSC, TruthfulDPMAB

# 基础随机种子
BASE_SEED = 42

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def setup_file_logger(log_file_path):
    root_logger = logging.getLogger()
    if root_logger.hasHandlers():
        root_logger.handlers.clear()

    file_handler = logging.FileHandler(log_file_path, mode='w', encoding='utf-8')
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)
    root_logger.setLevel(logging.INFO)


# --- 模型工厂 ---
def all_models_fabric(num_workers, config):
    worker_ids = list(range(num_workers))
    return {
        "POETIC": Platform(config, worker_ids),
        "POETIC-slow": POETICSlow(config, worker_ids),
        "Non-Private Optimal": NonPrivateOptimal(config),
        "Random": RandomModel(config, worker_ids),
        "PrivCO": PrivCO(config),
        "OPPS-adapted": OPPSAdapted(config, worker_ids),
        "Incentivized FL-SC": IncentivizedFLSC(config, worker_ids),
        "Truthful-DP-MAB": TruthfulDPMAB(config, worker_ids),
    }


# --- 单次模拟核心函数 ---
def run_single_simulation(model_instance, workers_dict, config, bidding_strategy='truthful',
                          num_winners_override=None, total_rounds_override=None, dp_epsilon_override=None):
    model_instance.reset()

    k = num_winners_override if num_winners_override is not None else config.DEFAULT_NUM_WINNERS
    T = total_rounds_override if total_rounds_override is not None else config.TOTAL_ROUNDS
    eps = dp_epsilon_override if dp_epsilon_override is not None else config.DEFAULT_EPSILON

    active_ids = list(workers_dict.keys())

    # 运行模拟
    for _ in range(T):
        for wid in active_ids:
            workers_dict[wid].update_state_for_round(None, None)

        winners_ids, payments = model_instance.run_round(
            0, active_ids, workers_dict, None,
            bidding_strategy=bidding_strategy, num_winners=k, dp_epsilon=eps
        )

        if hasattr(model_instance, 'worker_profit_history_agg'):
            avg_p = np.mean(
                [payments.get(wid, 0) - workers_dict[wid].true_cost for wid in winners_ids]) if winners_ids else 0
            model_instance.worker_profit_history_agg.append(avg_p)

    return {
        'net_social_value_history': model_instance.net_social_value_history
    }


# --- 辅助：生成干净的 Worker 集合 ---
def get_fresh_workers(n, config):
    return {wid: Worker(wid, config) for wid in range(n)}


def main():
    config = Config()
    os.makedirs(config.FIGURES_DIR, exist_ok=True)
    os.makedirs(config.LOGS_DIR, exist_ok=True)

    NUM_ACADEMIC_RUNS = 10

    log_file_path = os.path.join(config.LOGS_DIR, f"exp_PRIVACY_GROWTH_{time.strftime('%Y%m%d-%H%M%S')}.txt")
    setup_file_logger(log_file_path)

    logging.info(f"--- Starting Privacy & Growth Experiments (10 Runs) ---")
    visualizer = Visualizer(config)

    # ==========================================
    # 1. 初始化聚合器
    # ==========================================

    # Exp 6.11: Privacy Tradeoff
    privacy_model_names = ["POETIC", "OPPS-adapted", "Truthful-DP-MAB"]
    # 结构: {epsilon: {model: [val1, val2...]}}
    agg_privacy = {eps: {name: [] for name in privacy_model_names} for eps in config.EPSILON_RANGE}
    agg_privacy_optimal = []  # 记录 Optimal 值用于计算 Regret

    # Exp Growth T: Time Horizon
    all_names = list(all_models_fabric(0, config).keys())
    growth_models = [m for m in all_names if "Optimal" not in m]
    agg_time = {name: {t: [] for t in config.TIME_HORIZON_RANGE} for name in growth_models}

    # Exp Growth k: Winners k
    agg_val_k = {name: {k: [] for k in config.K_RANGE} for name in all_names}

    # ==========================================
    # 2. 主循环
    # ==========================================
    for run_idx in tqdm(range(NUM_ACADEMIC_RUNS), desc="Academic Runs"):
        current_seed = BASE_SEED + run_idx
        random.seed(current_seed)
        np.random.seed(current_seed)

        logging.info(f"--- Run {run_idx + 1}/{NUM_ACADEMIC_RUNS} ---")

        # -------------------------------------------------
        # Exp 6.11: Privacy Tradeoff (N = 2000)
        # -------------------------------------------------
        N_PRIVACY = config.DEFAULT_NUM_WORKERS  # 2000
        workers_priv = get_fresh_workers(N_PRIVACY, config)

        # 先跑 Optimal 获取基准
        opt_res = run_single_simulation(NonPrivateOptimal(config), workers_priv, config)
        opt_val = Metrics.calculate_cumulative_value(opt_res['net_social_value_history'])[-1]
        agg_privacy_optimal.append(opt_val)

        for eps in config.EPSILON_RANGE:
            models_priv = {
                "POETIC": Platform(config, list(workers_priv.keys())),
                "OPPS-adapted": OPPSAdapted(config, list(workers_priv.keys())),
                "Truthful-DP-MAB": TruthfulDPMAB(config, list(workers_priv.keys()))
            }
            for name, model in models_priv.items():
                res = run_single_simulation(model, workers_priv, config, dp_epsilon_override=eps)
                val = Metrics.calculate_cumulative_value(res['net_social_value_history'])[-1]
                agg_privacy[eps][name].append(val)

        # -------------------------------------------------
        # 公共设置：Growth 实验使用 N = 500
        # -------------------------------------------------
        N_GROWTH = 500

        # -------------------------------------------------
        # Exp Growth T: Regret vs Time Horizon
        # -------------------------------------------------
        workers_time = get_fresh_workers(N_GROWTH, config)

        for t in config.TIME_HORIZON_RANGE:
            # Optimal for current T
            opt_model_t = NonPrivateOptimal(config)
            opt_res_t = run_single_simulation(opt_model_t, workers_time, config, total_rounds_override=t)
            opt_val_t = Metrics.calculate_cumulative_value(opt_res_t['net_social_value_history'])[-1]

            models_t = all_models_fabric(N_GROWTH, config)
            for name, model in models_t.items():
                if "Optimal" in name: continue

                res = run_single_simulation(model, workers_time, config, total_rounds_override=t)
                val = Metrics.calculate_cumulative_value(res['net_social_value_history'])[-1]

                # Regret / sqrt(T)
                regret = opt_val_t - val
                norm_regret = regret / np.sqrt(t) if t > 0 else 0
                agg_time[name][t].append(norm_regret)

        # -------------------------------------------------
        # Exp Growth k: Value vs Winners k
        # -------------------------------------------------
        workers_vk = get_fresh_workers(N_GROWTH, config)

        for k in config.K_RANGE:
            models_k = all_models_fabric(N_GROWTH, config)
            for name, model in models_k.items():
                model.reset()
                res = run_single_simulation(model, workers_vk, config, num_winners_override=k)
                final_val = Metrics.calculate_cumulative_value(res['net_social_value_history'])[-1]
                agg_val_k[name][k].append(final_val)

    # ==========================================
    # 3. 汇总与可视化
    # ==========================================
    logging.info("--- Generating Visualizations ---")

    # --- Plot 6.11: Privacy ---
    mean_opt_priv = np.mean(agg_privacy_optimal)
    # 转换结构: {epsilon: {model: {'final_cumulative_value': mean}}}
    mean_privacy_data = {}
    for eps, models_data in agg_privacy.items():
        mean_privacy_data[eps] = {}
        for name, vals in models_data.items():
            mean_privacy_data[eps][name] = {'final_cumulative_value': np.mean(vals)}

    visualizer.plot_privacy_tradeoff_curves(
        mean_privacy_data, mean_opt_priv,
        "Privacy Trade-off", "exp_6.11_privacy_tradeoff_AVG.pdf"
    )

    # --- Plot Growth T: Regret vs T ---
    mean_time_regret = {}
    for name, t_data in agg_time.items():
        mean_time_regret[name] = {}
        for t, val_list in t_data.items():
            mean_time_regret[name][t] = {'normalized_regret': np.mean(val_list)}

    visualizer.plot_line_chart(
        mean_time_regret, config.TIME_HORIZON_RANGE, 'normalized_regret',
        "Normalized Regret ($R_T / \sqrt{T}$)", "Regret Growth vs. Time Horizon",
        "exp_new_regret_vs_t_AVG.pdf", "Time Horizon ($T$)"
    )

    # --- Plot Growth k: Value vs k ---
    k_filtered = config.K_RANGE
    mean_val_k = {}
    for name, k_data in agg_val_k.items():
        mean_val_k[name] = {}
        for k, val_list in k_data.items():
            mean_val_k[name][k] = {
                'final_cumulative_value': np.mean(val_list),
                'std_final_cumulative_value': np.std(val_list)
            }

    visualizer.plot_bar_chart_grouped(
        mean_val_k, k_filtered, 'final_cumulative_value',
        "Final Cumulative Value", "Performance vs. Number of Winners",
        "exp_new_value_vs_k_AVG.pdf", "Number of Winners ($k$)"
    )

    logging.info("--- Done. ---")


if __name__ == '__main__':
    main()