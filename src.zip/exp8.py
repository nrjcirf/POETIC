import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

# ── 1. ICDE 顶会级全局样式设置 ─────────────────────────────────────
mpl.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 12,
    'axes.titlesize': 13,
    'axes.labelsize': 12,
    'xtick.labelsize': 11,
    'ytick.labelsize': 11,
    'legend.fontsize': 11,
    'figure.dpi': 300,
    'lines.linewidth': 2.5,
    'axes.grid': True,
    'grid.linestyle': ':',
    'grid.alpha': 0.6,
    'axes.spines.top': False,
    'axes.spines.right': False,
})

# 100% 提取自你 Fig 1 的全局统一视觉样式
STYLES = {
    'POETIC':          {'color': '#003366', 'ls': '-',  'marker': 'o'}, # 深蓝实线
    'PrivCO':          {'color': '#c0392b', 'ls': '--', 'marker': 'x'}, # 深红虚线
    'Truthful-DP-MAB': {'color': '#8e44ad', 'ls': ':',  'marker': '*'}, # 紫色点线
    'Random':          {'color': '#7f8c8d', 'ls': '-.', 'marker': 'v'}, # 灰色点划线
    'Greedy Selection':{'color': '#16a085', 'ls': '--', 'marker': 'd'}, # 蓝绿虚线
}

def generate_exp8_plot():
    print("🎨 正在加载实验 8 聚合数据，生成 1x2 Adversarial Robustness 图表...")
    
    # 从日志中提取的 X 轴坐标 (Adversarial Ratio %)
    ratios = [0, 10, 30, 50, 70]
    
    # ── 2. 精准提取自你终端日志的 Round 5000 聚合均值 ──
    # Cumulative Utility (单位: 10^6)
    val_data = {
        'POETIC':           [184.06, 182.86, 181.83, 182.44, 175.97],
        'PrivCO':           [137.35, 136.00, 137.14, 137.43, 137.40],
        'Truthful-DP-MAB':  [137.82, 134.97, 134.33, 133.36, 134.73],
        'Random':           [134.20, 134.20, 134.20, 134.20, 134.20],
        'Greedy Selection': [132.63, 132.63, 132.63, 132.63, 132.63]
    }
    
    # Estimation Error
    # (基线的 error 统一为 0 没有展示意义，所以误差图只对比 POETIC 和 Greedy)
    err_data = {
        'POETIC':           [924.94, 923.18, 924.42, 939.56, 931.95],
        'Greedy Selection': [718.53, 718.53, 718.53, 718.53, 718.53] 
    }

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    ax_u = axes[0] # Utility
    ax_e = axes[1] # EstErr
    
    # 绘制 (a) Cumulative Utility 图
    for method, vals in val_data.items():
        st = STYLES[method]
        ax_u.plot(ratios, vals, label=method, **st)
        
    ax_u.set_title("(a) Cumulative Utility under Contamination")
    ax_u.set_ylabel(r"Cumulative Utility ($10^6$)")
    ax_u.set_xlabel("Adversarial Worker Ratio")
    
    # 将 X 轴刻度设为百分比样式
    ax_u.set_xticks(ratios)
    ax_u.set_xticklabels([f"{r}%" for r in ratios])
    ax_u.legend(loc='center right', bbox_to_anchor=(0.98, 0.65), fontsize=10, edgecolor='black')

    # 绘制 (b) Estimation Error 图
    for method, errs in err_data.items():
        st = STYLES[method]
        ax_e.plot(ratios, errs, label=method, **st)
        
    ax_e.set_title("(b) Estimation Stability")
    ax_e.set_ylabel("Mean Estimation Error")
    ax_e.set_xlabel("Adversarial Worker Ratio")
    ax_e.set_xticks(ratios)
    ax_e.set_xticklabels([f"{r}%" for r in ratios])
    
    # POETIC 和 Greedy 的误差基本是平的，为了避免曲线贴着上下边缘，稍微放宽 Y 轴
    ax_e.set_ylim(600, 1050)
    ax_e.legend(loc='lower right', fontsize=10, edgecolor='black')

    plt.tight_layout()
    out_dir = r"d:\src\paper"
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "fig8_adversarial_ratio.pdf")
    plt.savefig(out_path, bbox_inches='tight')
    print(f"✅ 终极版图 8 生成完毕！请立即查看：{out_path}")

if __name__ == "__main__":
    generate_exp8_plot()