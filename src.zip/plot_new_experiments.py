# plot_new_experiments.py
import json
import os
import glob
import matplotlib.pyplot as plt
import numpy as np

# Set professional font settings
plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 11,
    'axes.labelsize': 12,
    'axes.titlesize': 12,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 9,
    'grid.alpha': 0.3,
    'grid.linestyle': '--'
})

def get_latest_results_file():
    files = glob.glob('results/new_icde_results_*.json')
    if not files:
        raise FileNotFoundError("No experiment results found in results/ directory.")
    return max(files, key=os.path.getmtime)

def plot_decoupling_effectiveness(data):
    """
    Generate Fig 6 with two subplots:
      (a) Manipulation Intensity vs Coupling Dependency (D_t)
      (b) Manipulation Intensity vs Estimation Drift
    """
    if "decoupling_effectiveness" not in data:
        print("Warning: decoupling_effectiveness data not found in results. Skipping Fig 6.")
        return

    dec_data = data["decoupling_effectiveness"]
    ratios = dec_data["ratios"]
    metrics = dec_data["metrics"]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))

    models = ["POETIC", "POETIC w/o Φ", "OPPS-adapted", "Greedy Selection", "PrivCO", "Truthful-DP-MAB"]
    markers = ['o', 's', '^', 'd', 'x', 'v']
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b']

    # Subplot (a): Manipulation Intensity vs Coupling Dependency
    for model, marker, color in zip(models, markers, colors):
        # We might have models in metrics that don't match exactly or aren't there
        # Let's map POETIC w/o \Phi to POETIC w/o Phi or look up keys flexibly
        key = None
        for k in metrics.keys():
            if model == k or (model == "POETIC w/o Φ" and ("Phi" in k or "Φ" in k)):
                key = k
                break
        if not key:
            continue

        y_deps = metrics[key]["coupling_dependency"]
        ax1.plot(ratios, y_deps, label=model, marker=marker, color=color, linewidth=1.8, markersize=6)

    ax1.set_xlabel('Manipulation Intensity ($r$)', fontsize=11)
    ax1.set_ylabel(r'Coupling Dependency ($\mathcal{D}_t$)', fontsize=11)
    ax1.set_title('(a) Influence on $\mathcal{D}_t$')
    ax1.grid(True)
    ax1.legend(loc='best', frameon=True)

    # Subplot (b): Manipulation Intensity vs Estimation Drift
    for model, marker, color in zip(models, markers, colors):
        key = None
        for k in metrics.keys():
            if model == k or (model == "POETIC w/o Φ" and ("Phi" in k or "Φ" in k)):
                key = k
                break
        if not key:
            continue

        y_drifts = metrics[key]["estimation_drift"]
        ax2.plot(ratios, y_drifts, label=model, marker=marker, color=color, linewidth=1.8, markersize=6)

    ax2.set_xlabel('Manipulation Intensity ($r$)', fontsize=11)
    ax2.set_ylabel('Estimation Drift (Mean Estimation Error)', fontsize=11)
    ax2.set_title('(b) Influence on Estimation Drift')
    ax2.grid(True)
    ax2.legend(loc='best', frameon=True)

    plt.tight_layout()
    os.makedirs('paper', exist_ok=True)
    plt.savefig('paper/fig_decoupling_effectiveness.pdf', format='pdf', dpi=300)
    plt.savefig('paper/fig_decoupling_effectiveness.png', format='png', dpi=300)
    print("Generated decoupling effectiveness plots in paper/fig_decoupling_effectiveness.{pdf,png}")
    plt.close()

def plot_sensitivity(data):
    fig, axs = plt.subplots(2, 2, figsize=(10, 7))
    axs = axs.flatten()
    
    # 1. Learning Rate alpha
    alpha_data = data["sensitivity_analysis"]["alpha"]["sweep"]
    alphas = sorted([float(k) for k in alpha_data.keys()])
    vals = [alpha_data[str(a)]["cumulative_value_mean"] / 1e6 for a in alphas]
    errs = [alpha_data[str(a)]["estimation_error_mean"] for a in alphas]
    
    ax = axs[0]
    ax2 = ax.twinx()
    p1, = ax.plot(alphas, vals, color='#1f77b4', marker='o', label='Social Welfare')
    p2, = ax2.plot(alphas, errs, color='#d62728', marker='s', linestyle='--', label='Est. Error')
    ax.set_xlabel('Learning Rate ($\\alpha$)')
    ax.set_ylabel('Social Welfare ($10^6$)')
    ax2.set_ylabel('Estimation Error')
    ax.grid(True)
    ax.legend(handles=[p1, p2], loc='upper right')
    ax.set_title('(a) Sensitivity to $\\alpha$')
    
    # 2. Stability Penalty lambda
    lam_data = data["sensitivity_analysis"]["lambda"]["sweep"]
    lams = sorted([float(k) for k in lam_data.keys()])
    vals = [lam_data[str(l)]["cumulative_value_mean"] / 1e6 for l in lams]
    errs = [lam_data[str(l)]["estimation_error_mean"] for l in lams]
    
    ax = axs[1]
    ax2 = ax.twinx()
    p1, = ax.plot(lams, vals, color='#1f77b4', marker='o', label='Social Welfare')
    p2, = ax2.plot(lams, errs, color='#d62728', marker='s', linestyle='--', label='Est. Error')
    ax.set_xlabel('Stability Penalty Weight ($\\lambda$)')
    ax.set_ylabel('Social Welfare ($10^6$)')
    ax2.set_ylabel('Estimation Error')
    ax.grid(True)
    ax.legend(handles=[p1, p2], loc='upper right')
    ax.set_title('(b) Sensitivity to $\\lambda$')
    
    # 3. Subgroup size g
    g_data = data["sensitivity_analysis"]["g"]["sweep"]
    gs = sorted([int(k) for k in g_data.keys()])
    vals = [g_data[str(g)]["cumulative_value_mean"] / 1e6 for g in gs]
    runtimes = [g_data[str(g)]["avg_runtime_ms"] for g in gs]
    
    ax = axs[2]
    ax2 = ax.twinx()
    p1, = ax.plot(gs, vals, color='#1f77b4', marker='o', label='Social Welfare')
    p2, = ax2.plot(gs, runtimes, color='#2ca02c', marker='^', linestyle='--', label='Latency (ms)')
    ax.set_xlabel('Subgroup Size ($g$)')
    ax.set_ylabel('Social Welfare ($10^6$)')
    ax2.set_ylabel('Avg Latency (ms)')
    ax.grid(True)
    ax.legend(handles=[p1, p2], loc='lower right')
    ax.set_title('(c) Sensitivity to $g$')
    
    # 4. Reputation bonus beta
    beta_data = data["sensitivity_analysis"]["beta"]["sweep"]
    betas = sorted([float(k) for k in beta_data.keys()])
    vals = [beta_data[str(b)]["cumulative_value_mean"] / 1e6 for b in betas]
    errs = [beta_data[str(b)]["estimation_error_mean"] for b in betas]
    
    ax = axs[3]
    ax2 = ax.twinx()
    p1, = ax.plot(betas, vals, color='#1f77b4', marker='o', label='Social Welfare')
    p2, = ax2.plot(betas, errs, color='#d62728', marker='s', linestyle='--', label='Est. Error')
    ax.set_xlabel('Reputation Bonus Factor ($\\beta$)')
    ax.set_ylabel('Social Welfare ($10^6$)')
    ax2.set_ylabel('Estimation Error')
    ax.grid(True)
    ax.legend(handles=[p1, p2], loc='upper right')
    ax.set_title('(d) Sensitivity to $\\beta$')
    
    plt.tight_layout()
    plt.savefig('paper/fig_sensitivity_analysis.pdf', format='pdf', dpi=300)
    plt.savefig('paper/fig_sensitivity_analysis.png', format='png', dpi=300)
    print("Generated sensitivity analysis plots in paper/fig_sensitivity_analysis.{pdf,png}")
    plt.close()

def main():
    filepath = get_latest_results_file()
    print(f"Reading results from: {filepath}")
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    plot_decoupling_effectiveness(data)
    plot_sensitivity(data)

if __name__ == '__main__':
    main()
