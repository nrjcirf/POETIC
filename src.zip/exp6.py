import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

# ── 1. ICDE 顶会级全局样式设置 ─────────────────────────────────────
mpl.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 12,
    'axes.titlesize': 13,
    'axes.labelsize': 12,
    'xtick.labelsize': 11,
    'ytick.labelsize': 11,
    'legend.fontsize': 11,
    'figure.dpi': 300,
    'lines.linewidth': 2.5,
    'axes.grid': True,
    'grid.linestyle': ':',
    'grid.alpha': 0.6,
    'axes.spines.top': False,
    'axes.spines.right': False,
})

# 100% 提取自你 Fig 1 的全局统一视觉样式
STYLES = {
    'POETIC':          {'color': '#003366', 'ls': '-',  'marker': 'o'}, # 深蓝实线
    'w/o $\Phi$':      {'color': '#d35400', 'ls': '-.', 'marker': 's'}, # 橙色点划线 (原本乱码的 w/o 桅)
    'PrivCO':          {'color': '#c0392b', 'ls': '--', 'marker': 'x'}, # 深红虚线
    'Truthful-DP-MAB': {'color': '#8e44ad', 'ls': ':',  'marker': '*'}, # 紫色点线
}

def generate_icde_tradeoff_plot():
    print("🎨 正在加载真实日志数据，生成 2x3 ICDE Privacy-Tradeoff 图表...")
    
    eps_labels = ['0.1', '0.5', '1.0', '5.0', '10.0', r'$\infty$']
    x_indices = np.arange(len(eps_labels))
    methods = ['POETIC', 'w/o $\Phi$', 'PrivCO', 'Truthful-DP-MAB']
    
    # ── 2. 精准提取自你终端日志的 Round 5000 聚合均值 (单位: 10^6) ──
    # T-Drive 数据 (从 12:48 开始的日志提取)
    nyc_val = {
            'POETIC':          [158.20, 167.43, 171.25, 171.99, 171.87, 173.15],
            'w/o $\Phi$':      [154.94, 148.23, 150.20, 152.46, 152.01, 152.54],
            'PrivCO':          [137.01, 137.01, 137.01, 137.01, 137.01, 137.01],
            'Truthful-DP-MAB': [134.34, 133.71, 134.04, 135.03, 132.97, 133.76]
        }

    tdrive_val = {
        'POETIC':          [169.08, 175.80, 179.57, 181.11, 182.24, 178.27],
        'w/o $\Phi$':      [170.08, 160.30, 163.76, 164.69, 164.44, 165.40],
        'PrivCO':          [149.77, 149.77, 149.77, 149.77, 149.77, 149.77],
        'Truthful-DP-MAB': [149.15, 148.03, 148.43, 148.30, 147.97, 149.04]
    }
    
    # NYC 数据 (从 17:43 开始的日志提取)
    

    # 理论最优上限 (用于计算公平的 Regret)
    OPT_TDRIVE = 185.0
    OPT_NYC = 175.0

    fig, axes = plt.subplots(2, 3, figsize=(18, 9))
    datasets = [('NYC', nyc_val, OPT_NYC),('T-Drive', tdrive_val, OPT_TDRIVE)]

    for row, (ds_name, data_dict, opt_val) in enumerate(datasets):
        ax_u = axes[row, 0] # Utility
        ax_r = axes[row, 1] # Regret
        ax_t = axes[row, 2] # Retention
        
        for method in methods:
            st = STYLES[method]
            vals = data_dict[method]
            
            # 计算 Regret (Optimal - Value)
            regrets = [max(0, opt_val - v) for v in vals]
            
            # 计算 Retention = (当前 epsilon 效用 / 无隐私约束(inf)效用) * 100
            val_inf = vals[-1]
            retentions = [(v / val_inf) * 100 for v in vals]
            
            ax_u.plot(x_indices, vals, label=method, **st)
            ax_r.plot(x_indices, regrets, label=method, **st)
            ax_t.plot(x_indices, retentions, label=method, **st)

        # 设置标题与坐标轴标签
        row_letter_offset = row * 3
        ax_u.set_title(rf"({chr(97 + row_letter_offset)}) Utility vs $\epsilon$ ({ds_name})")
        ax_u.set_ylabel(r"Cumulative Utility ($10^6$)")
        
        ax_r.set_title(rf"({chr(98 + row_letter_offset)}) Regret vs $\epsilon$ ({ds_name})")
        ax_r.set_ylabel(r"Cumulative Regret ($10^6$)")
        
        ax_t.set_title(rf"({chr(99 + row_letter_offset)}) Utility Retention (%) ({ds_name})")
        ax_t.set_ylabel("Retention (%) relative to no-DP")
        ax_t.set_ylim(80, 115) # 收紧 Y 轴以更好展示高保留率
        
        # 🔥 高级视觉修饰：为 Retention 添加最优权衡阴影区 (epsilon = 1.0 ~ 10.0)
        ax_t.axvspan(2, 4, color='#2ca02c', alpha=0.08, zorder=0)
        y_min, y_max = ax_t.get_ylim()
        ax_t.text(3, y_min + (y_max - y_min)*0.15, 'Optimal\nTrade-off', 
                  ha='center', va='center', fontsize=11, color='#1b5e20', fontweight='bold', alpha=0.7)
        
        # 统一设置 X 轴
        for ax in [ax_u, ax_r, ax_t]:
            ax.set_xticks(x_indices)
            ax.set_xticklabels(eps_labels)
            ax.set_xlabel(r'Privacy Budget $\epsilon$')
            
        # 仅在左上角打图例
        if row == 0:
            # loc='center right' 表示靠右居中，bbox_to_anchor=(0.98, 0.5) 表示向左稍微缩进 2% 防止贴边
            ax_u.legend(loc='center right', bbox_to_anchor=(0.98, 0.65), 
                        fontsize=10, framealpha=0.9, edgecolor='black')

    plt.tight_layout()
    out_dir = r"d:\src\paper"
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "fig6_privacy_tradeoff_icde.pdf")
    plt.savefig(out_path, bbox_inches='tight')
    print(f"✅ 终极版图 6 生成完毕！请立即查看：{out_path}")

if __name__ == "__main__":
    generate_icde_tradeoff_plot()