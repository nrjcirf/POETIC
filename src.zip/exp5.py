import os
import sys
import copy
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from tqdm import tqdm

# 确保能正确导入你的源码
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)
sys.path.insert(0, current_dir)

try:
    from src.config import Config
    from src.worker import Worker
    from src.poe_platform import POEPlatform
except ModuleNotFoundError:
    from config import Config
    from worker import Worker
    from poe_platform import POEPlatform

# ── 1. 全局样式设置 ─────────────────────────────────────
mpl.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 11,
    'axes.titlesize': 12,
    'axes.labelsize': 11,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 9,
    'figure.dpi': 300,
    'lines.linewidth': 2.0,
    'axes.grid': True,
    'grid.linestyle': ':',
    'grid.alpha': 0.6,
    'axes.spines.top': False,
    'axes.spines.right': False,
})

def get_platform_variants(config, worker_ids):
    variants = {}
    cfg_full = copy.deepcopy(config)
    variants["POETIC"] = POEPlatform(cfg_full, worker_ids, name="POETIC", use_stability_reputation=True, use_decoupled_learning=True)
    
    cfg_nostab = copy.deepcopy(config)
    variants["w/o StabRep"] = POEPlatform(cfg_nostab, worker_ids, name="w/o StabRep", use_stability_reputation=False, use_decoupled_learning=True)
    
    cfg_ema = copy.deepcopy(config)
    variants["EMA-Only"] = POEPlatform(cfg_ema, worker_ids, name="EMA-Only", use_stability_reputation=False, use_decoupled_learning=False)
    
    cfg_instant = copy.deepcopy(config)
    if hasattr(cfg_instant, 'ETA_R'): cfg_instant.ETA_R = 1.0
    elif hasattr(cfg_instant, 'REPUTATION_LEARNING_RATE'): cfg_instant.REPUTATION_LEARNING_RATE = 1.0
    variants["Instant"] = POEPlatform(cfg_instant, worker_ids, name="Instant", use_stability_reputation=True, use_decoupled_learning=True)
    
    return variants

def run_real_simulation():
    config = Config()
    T = 1000  
    N = 100   
    K = 10    
    worker_ids = list(range(N))
    
    results = {
        name: {"stable_rep": [], "manip_rep": [], "gap": [], "selections": 0} 
        for name in ["POETIC", "w/o StabRep", "EMA-Only", "Instant"]
    }
    
    print("🚀 正在运行真实架构的独立实验 5...")
    
    for variant_name, platform in get_platform_variants(config, worker_ids).items():
        print(f"  ▶ 运行真实平台: {variant_name}")
        
        # 🔥 核心修复：破除“初始乐观权重陷阱”
        # 将平台的初始权重从虚高的 2000 重置为真实水平 (100)，直接观察稳态下的博弈打压效果
        for wid in platform.worker_weights:
            platform.worker_weights[wid] = 100.0
            
        workers = {wid: Worker(wid, config) for wid in worker_ids}
        stable_id, manip_id = 0, 1
        
        for t in tqdm(range(T), leave=False):
            active_ids = list(workers.keys())
            
            for wid, w in workers.items():
                if wid == stable_id:
                    # 完美老实人：稳定高质量，正常报价
                    w.true_utility, w.true_cost = 100.0, 40.0
                    w.bid_history.append(40.0)
                    if not hasattr(w, 'utility_history'): w.utility_history = []
                    w.utility_history.append(100.0)
                elif wid == manip_id:
                    # 🔥 引入顶级黑客策略：蜜罐陷阱 (Honey Pot Attack)
                    if (t // 15) % 2 == 0:
                        # 伪装期：极高的质量，极低的价格 (5.0) 疯狂诱惑系统
                        w.true_utility, cost = 150.0, 5.0 
                    else:
                        # 收割期：极低的质量，极高的价格 (120.0) 疯狂割韭菜
                        w.true_utility, cost = 20.0, 120.0 
                    
                    w.true_cost = cost
                    w.bid_history.append(cost)
                    if not hasattr(w, 'utility_history'): w.utility_history = []
                    w.utility_history.append(w.true_utility)
                    
                    if len(w.bid_history) > 30: w.bid_history.pop(0)
                    if len(w.utility_history) > 30: w.utility_history.pop(0)
                else:
                    # 普通工人：表现平庸
                    w.true_utility = np.random.uniform(60, 80)
                    w.true_cost = np.random.uniform(50, 60)
                    w.bid_history.append(w.true_cost)

            # 调用真实的运行函数
            winners, _ = platform.run_round(
                round_id=t, active_workers_ids=active_ids, 
                workers_dict=workers, data_loader=None, 
                dp_epsilon=np.inf, num_winners=K
            )
            
            # 记录数据
            s_rep = platform.worker_reputations.get(stable_id, 0.5)
            m_rep = platform.worker_reputations.get(manip_id, 0.5)
            
            results[variant_name]["stable_rep"].append(s_rep)
            results[variant_name]["manip_rep"].append(m_rep)
            results[variant_name]["gap"].append(s_rep - m_rep)
            
            if manip_id in winners: results[variant_name]["selections"] += 1

    return results, T

def plot_results(results, T):
    print("🎨 正在绘制真实的对比图表 (已优化 Y 轴与柱状图样式)...")
    fig, axes = plt.subplots(1, 4, figsize=(20, 4.5))
    
    # 🔥 核心对齐区 1：全局颜色与纹理设定
    # 请确保 POETIC_COLOR 和 HATCH_STYLE 与你的图 7 完全一致！
    POETIC_COLOR = "#003366"  
    POETIC_HATCH = ""         # 如果图 7 中 POETIC 的柱子有斜线，请改为 "//" 或 "xx"
    
    styles = {
        "POETIC": {"color": POETIC_COLOR, "ls": "-", "lw": 2.5, "hatch": POETIC_HATCH},
        "w/o StabRep": {"color": "#d35400", "ls": "--", "lw": 2.0, "hatch": ""},
        "EMA-Only": {"color": "#2ca02c", "ls": "-.", "lw": 2.0, "hatch": ""},
        "Instant": {"color": "#9467bd", "ls": ":", "lw": 1.5, "alpha": 0.7, "hatch": ""}
    }
    
    rounds = np.arange(T)
    
    # --- (a) Stable Worker Reputation ---
    axes[0].set_title("(a) Stable Worker Reputation")
    axes[0].set_ylabel("Reputation Score")
    for m, data in results.items(): 
        axes[0].plot(rounds, data["stable_rep"], label=m, 
                     color=styles[m]["color"], ls=styles[m]["ls"], 
                     lw=styles[m]["lw"], alpha=styles[m].get("alpha", 1.0))
    
    # 🔥 核心对齐区 2：强制设定老实人声誉的 Y 轴展示区间为 0.4 到 1.5
    axes[0].set_ylim(0.4, 1.5)  
    axes[0].legend(loc="lower right")
    
    # --- (b) Manipulative Worker Reputation ---
    axes[1].set_title("(b) Manipulative Worker Reputation")
    for m, data in results.items(): 
        axes[1].plot(rounds, data["manip_rep"], label=m, 
                     color=styles[m]["color"], ls=styles[m]["ls"], 
                     lw=styles[m]["lw"], alpha=styles[m].get("alpha", 1.0))
    axes[1].set_ylim(0, 1.5) # 保持与图 a 的视觉平衡
    
    # --- (c) Selection Frequency ---
    axes[2].set_title("(c) Selection Frequency (Manipulator)")
    axes[2].set_ylabel("Times Selected")
    methods = list(results.keys())
    
    # 🔥 核心对齐区 3：柱状图样式深度对齐（加入边框粗细与透明度控制）
    bars = axes[2].bar(methods, [results[m]["selections"] for m in methods], 
                       color=[styles[m]["color"] for m in methods], 
                       edgecolor='black', 
                       linewidth=1.5,  # 确保边框粗细与图 7 一致
                       alpha=0.9)      # 确保透明度色彩饱和度与图 7 一致
    
    # 动态为柱子打上纹理（Hatch）
    for bar, m in zip(bars, methods):
        if styles[m]["hatch"]:
            bar.set_hatch(styles[m]["hatch"])
    
    # --- (d) Reputation Gap ---
    axes[3].set_title("(d) Reputation Gap")
    axes[3].set_ylabel("Gap (Stable - Manipulative)")
    for m, data in results.items(): 
        axes[3].plot(rounds, data["gap"], label=m, 
                     color=styles[m]["color"], ls=styles[m]["ls"], 
                     lw=styles[m]["lw"], alpha=styles[m].get("alpha", 1.0))
    axes[3].axhline(0, color='black', lw=1.5, alpha=0.3)
    
    for ax in [axes[0], axes[1], axes[3]]: 
        ax.set_xlabel("Rounds")
    
    plt.tight_layout()
    out_path = os.path.join(r"d:\src\paper", "fig5_reputation_real.pdf")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    plt.savefig(out_path, bbox_inches='tight')
    print(f"✅ 图表优化完毕！请查看: {out_path}")

if __name__ == "__main__":
    res, total_rounds = run_real_simulation()
    plot_results(res, total_rounds)