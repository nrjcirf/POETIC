# run_icde_experiments.py
"""
独立运行脚本：仅执行 ICDE 2026 新增的 7 个实验。
用法（从 d:\\ 或项目父目录运行）：

    python -m src.run_icde_experiments

或者在 d:\\ 下：

    python run_icde_experiments.py   (需要 sys.path 配置，见下方)

支持命令行参数来选择运行哪些实验：
    --exp all          运行全部 7 个（默认）
    --exp 1,3,7        只运行第 1、3、7 个
    --quick            快速模式（T=200, N=200）
"""
import os
import sys
import argparse
import logging
import time
import numpy as np
import random

# 兼容两种运行方式
# 方式 1: python -m src.run_icde_experiments (从项目父目录)
# 方式 2: python run_icde_experiments.py     (从 d:\src 直接运行)
if __package__ is None:
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from src.config import Config
    from src.visualization import Visualizer
    from src.experiments_icde import (
        run_overall_utility_experiment,
        run_regret_analysis_experiment,
        run_contamination_robustness_experiment,
        run_strategic_worker_experiment,
        run_reputation_robustness_experiment,
        run_privacy_tradeoff_experiment,
        run_mechanism_ablation_experiment,
        run_adversarial_worker_experiment,
    )
else:
    from .config import Config
    from .visualization import Visualizer
    from .experiments_icde import (
        run_overall_utility_experiment,
        run_regret_analysis_experiment,
        run_contamination_robustness_experiment,
        run_strategic_worker_experiment,
        run_reputation_robustness_experiment,
        run_privacy_tradeoff_experiment,
        run_mechanism_ablation_experiment,
        run_adversarial_worker_experiment,
    )

SEED = 42
random.seed(SEED)
np.random.seed(SEED)

EXP_REGISTRY = {
    1: ("Overall Utility Performance",   run_overall_utility_experiment),
    2: ("Regret Analysis",               run_regret_analysis_experiment),
    3: ("Contamination Robustness",      run_contamination_robustness_experiment),
    4: ("Strategic Worker",              run_strategic_worker_experiment),
    5: ("Reputation Robustness",         run_reputation_robustness_experiment),
    6: ("Privacy–Learning Tradeoff",    run_privacy_tradeoff_experiment),
    7: ("Mechanism Ablation",            run_mechanism_ablation_experiment),
    8: ("Adversarial Worker Ratio",      run_adversarial_worker_experiment),
}


def parse_args():
    parser = argparse.ArgumentParser(description="ICDE 2026 Experiment Runner")
    parser.add_argument("--exp", type=str, default="all",
                        help="Experiments to run: 'all' or comma-separated ids, e.g. '1,3,7'")
    parser.add_argument("--quick", action="store_true",
                        help="Quick mode: T=200, N=200 for rapid validation")
    parser.add_argument("--runs", type=int, default=1,
                        help="Number of independent runs to average (default=1, paper=5)")
    return parser.parse_args()


def apply_quick_mode(config):
    """Reduce scale for fast smoke-testing."""
    config.TOTAL_ROUNDS = 200
    config.DEFAULT_NUM_WORKERS = 200
    config.N_RANGE = [50, 100, 200]
    config.EFFICIENCY_N_RANGE = [50, 100, 200]
    config.TIME_HORIZON_RANGE = [50, 100, 200]
    config.EPSILON_RANGE = [0.5, 1.0, 5.0]
    logging.info("⚡ Quick mode active: T=200, N=200")
    return config


def main():
    args = parse_args()

    # ── Setup ──────────────────────────────────────────────────────────
    config = Config()
    os.makedirs(config.FIGURES_DIR, exist_ok=True)
    os.makedirs(config.LOGS_DIR, exist_ok=True)

    if args.quick:
        config = apply_quick_mode(config)

    timestamp = time.strftime('%Y%m%d-%H%M%S')
    log_path = os.path.join(config.LOGS_DIR, f"icde_experiments_{timestamp}.txt")

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(log_path, mode='w', encoding='utf-8'),
        ]
    )
    # Suppress matplotlib font-subsetting spam (fonttools outputs hundreds of lines)
    for noisy_lib in ('fontTools', 'matplotlib', 'PIL'):
        logging.getLogger(noisy_lib).setLevel(logging.WARNING)

    logging.info(f"ICDE Experiment Runner — log: {log_path}")
    logging.info(f"Config: T={config.TOTAL_ROUNDS}, N={config.DEFAULT_NUM_WORKERS}, "
                 f"k={config.DEFAULT_NUM_WINNERS}, runs={args.runs}")

    if args.runs > 1:
        logging.info(f"📊 Multi-run mode: each experiment will run {args.runs} times and average results.")

    visualizer = Visualizer(config)

    # ── Select experiments ─────────────────────────────────────────────
    if args.exp == "all":
        selected = list(EXP_REGISTRY.keys())
    else:
        try:
            selected = [int(x.strip()) for x in args.exp.split(",")]
        except ValueError:
            logging.error("--exp 参数格式错误，示例: --exp 1,3,7")
            sys.exit(1)

    # ── Run ────────────────────────────────────────────────────────────
    from src.data_loader import get_dataloader
    DATASET_TYPE = 'NYC'  # 切换数据集: 'TDrive' 或 'NYC'
    
    logging.info(f"Loading {DATASET_TYPE} dataset context...")
    data_loader = get_dataloader(config, dataset_type=DATASET_TYPE)

    logging.info(f"\n运行实验: {selected}\n")
    t0 = time.time()

    for exp_id in selected:
        if exp_id not in EXP_REGISTRY:
            logging.warning(f"未知实验编号 {exp_id}，跳过")
            continue
        name, fn = EXP_REGISTRY[exp_id]
        logging.info(f"\n{'='*60}")
        logging.info(f"  Exp ICDE-{exp_id}: {name}")
        logging.info(f"{'='*60}")
        t_exp = time.time()
        try:
            fn(config, visualizer, log_path, data_loader=data_loader, num_runs=args.runs)
        except Exception as e:
            logging.error(f"Exp ICDE-{exp_id} 运行失败: {e}", exc_info=True)
        logging.info(f"  ✓ 完成，耗时 {time.time() - t_exp:.1f}s")

    logging.info(f"\n全部实验完成，总耗时 {time.time() - t0:.1f}s")
    logging.info(f"图表输出目录: {os.path.abspath(config.FIGURES_DIR)}")
    logging.info(f"日志文件: {os.path.abspath(log_path)}")


if __name__ == '__main__':
    main()
