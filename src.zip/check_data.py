import os
import json

def strip_keys(obj):
    if isinstance(obj, dict): return {k.strip(): strip_keys(v) for k, v in obj.items()}
    elif isinstance(obj, list): return [strip_keys(i) for i in obj]
    return obj

def load_json(filepath):
    if not os.path.exists(filepath):
        print(f"❌ 找不到文件: {filepath}")
        return {}
    with open(filepath, 'r', encoding='utf-8') as f:
        return strip_keys(json.load(f))

def diagnose():
    print("="*60)
    print("🔍 ICDE 数据可视化深度诊断工具")
    print("="*60)

    # 1. 加载文件
    nyc_data = load_json('parsed_nyc_results.json')
    greedy_data = load_json('parsed_greedy_exp4_8_results.json')
    
    # 模拟合并逻辑
    def update_dict(d, u):
        for k, v in u.items():
            if isinstance(v, dict): d[k] = update_dict(d.get(k, {}), v)
            else: d[k] = v
        return d
    
    if greedy_data:
        nyc_data = update_dict(nyc_data, greedy_data)
        print("✅ 已模拟合并 Greedy 数据")

    # ==========================================
    # 诊断 1：检查图 8 (Adversarial) 的 X/Y 数组
    # ==========================================
    print("\n" + "="*60)
    print("🚨 诊断 1: 图 8 (Adversarial Ratio) 的数据提取阵列")
    
    exp8_data = nyc_data.get('8', {}).get('adversarial', {})
    if not exp8_data:
        print("❌ 找不到 Exp 8 的数据！")
    else:
        print(f"▶ 原始捕获的 Ratio 键列表: {list(exp8_data.keys())}")
        
        valid_keys = [k for k in exp8_data.keys() if k.replace('.', '', 1).isdigit()]
        ratios_str = sorted(valid_keys, key=float)
        
        print(f"▶ 过滤并排序后的 Ratio 键 (X轴基准): {ratios_str}")
        print("-" * 40)
        
        target_methods = ['POETIC', 'Truthful-DP-MAB', 'Greedy Selection']
        for method in target_methods:
            x_plot = []
            y_plot = []
            for r_str in ratios_str:
                if method in exp8_data.get(r_str, {}):
                    val = exp8_data[r_str][method].get('val_mean')
                    if val is not None:
                        x_plot.append(float(r_str))
                        y_plot.append(val)
            print(f"[{method}]")
            print(f"  X 轴: {x_plot}")
            print(f"  Y 轴 (val_mean): {y_plot}")
            # 检查是否有锯齿/断崖
            if len(y_plot) > 1 and max(y_plot) > 0 and min(y_plot) == 0:
                print("  ⚠️ 警告: Y轴存在 0 值，这是导致折线掉底/穿插的元凶！")

    # ==========================================
    # 诊断 2：检查图 6 (Privacy) 的 Greedy 数据
    # ==========================================
    print("\n" + "="*60)
    print("🚨 诊断 2: 图 6 (Privacy Tradeoff) 中的 Greedy 查找逻辑")
    
    exp6_data = nyc_data.get('6', {}).get('privacy', {})
    if not exp6_data:
        print("❌ 找不到 Exp 6 的数据！")
    else:
        eps_list = sorted(exp6_data.keys(), key=lambda x: float(x.replace('inf', '99')))
        print(f"▶ Epsilon (X轴) 列表: {eps_list}")
        
        greedy_in_exp6 = False
        for e in eps_list:
            if 'Greedy Selection' in exp6_data[e]:
                greedy_in_exp6 = True
                break
                
        print(f"▶ Greedy 是否在 Exp 6 原生日志中? {'是' if greedy_in_exp6 else '否'}")
        
        if not greedy_in_exp6:
            # 去 Exp 8 找 Ratio=0 的备用数据
            ratio_zero_data = nyc_data.get('8', {}).get('adversarial', {}).get('0', {})
            has_fallback = 'Greedy Selection' in ratio_zero_data
            print(f"▶ 能否在 Exp 8 (Ratio=0) 中找到 Greedy 备用数据? {'是' if has_fallback else '否'}")
            if has_fallback:
                val = ratio_zero_data['Greedy Selection'].get('val_mean')
                print(f"  └─ 提取到的备用 Utility 值为: {val}")

    print("="*60)

if __name__ == '__main__':
    diagnose()