import os
import re
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from collections import defaultdict

# ── 1. ICDE 顶会级全局样式设置 ─────────────────────────────────────
mpl.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 12,
    'axes.titlesize': 13,
    'axes.labelsize': 12,
    'xtick.labelsize': 11,
    'ytick.labelsize': 11,
    'legend.fontsize': 11,
    'figure.dpi': 300,
    'lines.linewidth': 2.5,
    'axes.grid': True,
    'grid.linestyle': ':',
    'grid.alpha': 0.6,
    'axes.spines.top': False,
    'axes.spines.right': False,
})

# 100% 沿用你全局统一的视觉样式，加入 POETIC-slow
STYLES = {
    'POETIC':          {'color': '#003366', 'ls': '-',  'marker': 'o'}, # 深蓝实线 (主模型)
    'POETIC-slow':     {'color': '#d35400', 'ls': '--', 'marker': 's'}, # 橙色虚线 (消融/对比版)
    'PrivCO':          {'color': '#c0392b', 'ls': '-.', 'marker': 'x'}, # 深红点划线
    
}

def parse_efficiency_log(filepath):
    """自动解析 Efficiency 实验日志提取所需指标"""
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        
    data = defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: {'Runtime': [], 'Comm': []})))
    current_var = None
    current_ds = None
    current_x = None

    for line in lines:
        # 匹配大标题 (例如: === Efficiency vs N (Dataset: NYC) ===)
        header_match = re.search(r'===\s*Efficiency vs (.*?)\s*\(Dataset:\s*(.*?)\)\s*===', line)
        if header_match:
            current_var = header_match.group(1).strip()
            current_ds = header_match.group(2).strip().split(',')[0]
            continue
            
        # 匹配横坐标 (例如: Testing N = 1000 ...)
        test_match = re.search(r'Testing [Nk]\s*=\s*(\d+)', line)
        if test_match:
            current_x = int(test_match.group(1))
            continue
            
        # 匹配各方法的性能指标 (例如: POETIC : Avg Runtime=123.45 ms, Avg Comm=0.12 MB)
        metric_match = re.search(r'^\s*[\d-]+\s+[\d:,]+\s+-\s+INFO\s+-\s+([A-Za-z0-9\-\s]+?)\s*:\s*Avg Runtime=([\d.]+)\s*ms,\s*Avg Comm=([\d.]+)\s*MB', line)
        
        if metric_match and current_var and current_ds and current_x is not None:
            method = metric_match.group(1).strip()
            runtime = float(metric_match.group(2))
            comm = float(metric_match.group(3))
            
            if 'x' not in data[current_ds][current_var][method]:
                data[current_ds][current_var][method]['x'] = []
            
            # 防止同回合重复日志插入
            if len(data[current_ds][current_var][method]['x']) == 0 or data[current_ds][current_var][method]['x'][-1] != current_x:
                data[current_ds][current_var][method]['x'].append(current_x)
                data[current_ds][current_var][method]['Runtime'].append(runtime)
                data[current_ds][current_var][method]['Comm'].append(comm)
                
    return data

def plot_efficiency(data):
    """绘制 2x3 布局的效率分析大图"""
    print("🎨 正在生成 2x3 Efficiency 图表...")
    
    fig, axes = plt.subplots(2, 3, figsize=(16, 9))
    datasets = ['NYC', 'TDrive']
    methods_order = ['POETIC', 'POETIC-slow', 'PrivCO']
    
    for row, ds in enumerate(datasets):
        if ds not in data:
            continue
            
        # ── (a)/(d) Runtime vs N ──
        ax_rn = axes[row, 0]
        for method in methods_order:
            if method in data[ds].get('N', {}):
                d = data[ds]['N'][method]
                ax_rn.plot(d['x'], d['Runtime'], label=method, **STYLES[method])
        
        row_offset = row * 3
        ax_rn.set_title(rf"({chr(97 + row_offset)}) Runtime vs $N$ ({ds})")
        ax_rn.set_ylabel("Runtime (ms)")
        ax_rn.set_xlabel("Number of Workers ($N$)")
        
        # ── (b)/(e) Runtime vs k ──
        ax_rk = axes[row, 1]
        for method in methods_order:
            if method in data[ds].get('k', {}):
                d = data[ds]['k'][method]
                ax_rk.plot(d['x'], d['Runtime'], label=method, **STYLES[method])
        ax_rk.set_title(rf"({chr(98 + row_offset)}) Runtime vs $k$ ({ds})")
        ax_rk.set_ylabel("Runtime (ms)")
        ax_rk.set_xlabel("Number of Winners ($k$)")
        
        # ── (c)/(f) Comm Cost vs N ──
        ax_cn = axes[row, 2]
        for method in methods_order:
            if method in data[ds].get('N', {}):
                d = data[ds]['N'][method]
                ax_cn.plot(d['x'], d['Comm'], label=method, **STYLES[method])
        ax_cn.set_title(rf"({chr(99 + row_offset)}) Comm Cost vs $N$ ({ds})")
        ax_cn.set_ylabel("Communication Cost (MB)")
        ax_cn.set_xlabel("Number of Workers ($N$)")
        
        # 仅在左上角子图打一次图例即可
        if row == 0:
            ax_rn.legend(loc='upper left', fontsize=10, edgecolor='black', framealpha=0.9)

    plt.tight_layout()
    
    out_dir = r"d:\src\paper"
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "fig_efficiency_icde.pdf")
    plt.savefig(out_path, bbox_inches='tight')
    print(f"✅ 图表已保存至: {out_path}")

if __name__ == "__main__":
    # 请确保将日志文件路径替换为正确的路径
    log_file_path = "efficiency_exp_20260512-102633.txt"
    parsed_data = parse_efficiency_log(log_file_path)
    plot_efficiency(parsed_data)