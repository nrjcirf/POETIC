# src/simulator.py
import random
import numpy as np


class Simulator:
    def __init__(self, config, data_loader, worker_ids):
        self.config = config
        self.data_loader = data_loader
        # 为每个追踪的工作者模拟固定的、异构的属性
        self.base_quality = {wid: random.uniform(*config.BASE_QUALITY_RANGE) for wid in worker_ids}
        self.unit_cost_factor = {wid: random.uniform(*config.UNIT_COST_FACTOR_RANGE) for wid in worker_ids}
        self.online_status = {wid: 1.0 for wid in worker_ids}

    def get_true_utility(self, worker_id, task_data_row):
        if random.random() < self.config.NON_STATIONARY_SWITCH_PROB:
            self.online_status[worker_id] = 0.3 if self.online_status[worker_id] == 1.0 else 1.0

        worker_performance = self.base_quality[worker_id] * self.online_status[worker_id]

        grid_cell_id = task_data_row['grid_cell_id']
        timestamp = task_data_row['timestamp']
        speed = task_data_row['speed']

        importance, density = self.data_loader.get_context_info(grid_cell_id, timestamp)

        info_novelty = 1 / (1 + density)
        if speed < 5:
            data_richness = 1.0
        elif speed > 60:
            data_richness = 0.8
        else:
            data_richness = 0.5

        task_value = (importance * 0.5) + info_novelty + data_richness
        return worker_performance * task_value

    def get_true_cost(self, worker_id, task_data_row):
        grid_cell_id = task_data_row['grid_cell_id']
        timestamp = task_data_row['timestamp']
        importance, _ = self.data_loader.get_context_info(grid_cell_id, timestamp)

        task_difficulty = random.uniform(*self.config.TASK_DIFFICULTY_RANGE) + importance
        return self.unit_cost_factor[worker_id] * task_difficulty