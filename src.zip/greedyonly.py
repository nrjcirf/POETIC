# run_greedy_only_exp4_8.py
"""
独立运行脚本：仅执行 Exp 4 (Strategic) 和 Exp 8 (Adversarial) 的 Greedy Selection。
仿真循环 100% 对齐 main.py 的 run_single_simulation，已移除导致全 0 的跳过逻辑。
"""
import os, sys, logging, time
import numpy as np
import random

# 🔧 智能适配路径
_script_dir = os.path.dirname(os.path.abspath(__file__))
if os.path.exists(os.path.join(_script_dir, 'config.py')):
    if _script_dir not in sys.path: sys.path.insert(0, _script_dir)
    _PKG = ''
else:
    _parent = os.path.dirname(_script_dir)
    if _parent not in sys.path: sys.path.insert(0, _parent)
    _PKG = 'src.'

try:
    exec(f"from {_PKG}config import Config")
    exec(f"from {_PKG}data_loader import get_dataloader")
    exec(f"from {_PKG}poe_platform import POEPlatform")
    exec(f"from {_PKG}worker import Worker")
except ImportError as e:
    print(f"❌ 模块导入失败: {e}"); sys.exit(1)

def setup_logging(log_file="greedy_exp4_8_results.txt"):
    os.makedirs(os.path.dirname(log_file) or ".", exist_ok=True)
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s',
                        handlers=[logging.StreamHandler(sys.stdout), logging.FileHandler(log_file, mode='w', encoding='utf-8')])

def run_single_simulation_greedy(model, workers_dict, config, data_loader=None, total_rounds=None):
    """✅ 完全复刻 main.py 的 run_single_simulation 核心逻辑"""
    if hasattr(model, 'reset'): model.reset()
    for w in workers_dict.values():
        if hasattr(w, 'reset'): w.reset()

    T = total_rounds or config.TOTAL_ROUNDS
    num_winners = getattr(config, 'DEFAULT_NUM_WINNERS', 20)

    for i in range(T):
        # 1. 获取环境上下文 (对齐 main.py)
        current_context = None
        if data_loader and hasattr(data_loader, 'context_maps') and data_loader.context_maps:
            keys = list(data_loader.context_maps.keys())
            if keys:
                random_key = random.choice(keys)
                grid_id, hour = random_key[0], random_key[1]
                current_context = {
                    'density': data_loader.context_maps.get((grid_id, hour, 'density'), 1.0),
                    'importance': data_loader.context_maps.get((grid_id, hour, 'importance'), 1.0)
                }

        # 2. 更新 Worker 状态并筛选活跃列表 (✅ 原逻辑是 > 0，非 > 0.5；且不跳过轮次)
        active_workers_ids = []
        for wid, worker in workers_dict.items():
            worker.update_state_for_round(current_context, data_loader, i)
            if worker.online_status > 0:
                active_workers_ids.append(wid)

        # 3. 运行单轮 (交由 model.run_round 内部处理数量不足的情况，绝不主动 continue)
        try:
            model.run_round(
                round_id=i, active_workers_ids=active_workers_ids, workers_dict=workers_dict,
                data_loader=data_loader, bidding_strategy='truthful', dp_epsilon=None, num_winners=num_winners
            )
        except Exception as e:
            if i == 0: logging.warning(f"⚠️ Round 0 异常: {e}")
            continue

    # 4. 聚合结果
    nsv = getattr(model, 'net_social_value_history', []) or [0.0]
    ee  = getattr(model, 'estimation_error_history', []) or [0.0]
    return float(np.cumsum(nsv)[-1]), float(np.mean(ee))

def run_greedy_sweep(exp_id, ratios, N, T, config, dataloader, num_runs=5):
    exp_name = "Strategic Worker Ratio Sweep" if exp_id == 4 else "Adversarial Worker Ratio Sweep"
    logging.info(f"\n{'='*60}\n Exp ICDE-{exp_id}: {exp_name} (Greedy Selection Only)\n{'='*60}")

    for r in ratios:
        run_vals, run_errs = [], []
        for run_idx in range(num_runs):
            t_start = time.time()
            seed = run_idx * 100 + exp_id
            random.seed(seed); np.random.seed(seed)

            # 配置 Worker
            workers = {}
            strat_count = int(N * r / 100) if exp_id==4 else 0
            adv_count = int(N * r / 100) if exp_id==8 else 0
            for i in range(N):
                w = Worker(i, config)
                if i < strat_count: w.worker_type, w.strategy = 'strategic', 'consistent_overbid'
                elif i < strat_count + adv_count: w.worker_type, w.strategy = 'adversarial', 'consistent_overbid'
                else: w.worker_type = 'truthful'
                workers[i] = w

            model = POEPlatform(config, list(range(N)), name='Greedy Selection',
                                use_reputation=False, use_exploration=False,
                                use_decoupled_learning=False, use_stability_reputation=False)

            val, err = run_single_simulation_greedy(model, workers, config, dataloader, T)
            run_vals.append(val)
            run_errs.append(err)
            logging.info(f"  [Run {run_idx+1}/{num_runs}] Ratio={r}% | Val={val:,.1f} | EstErr={err:.2f} | Time={time.time()-t_start:.1f}s")

        if not run_vals: continue
        avg_val, avg_err = np.mean(run_vals), np.mean(run_errs)
        # 🎯 严格匹配 logsave.py 正则
        logging.info(f"Ratio={r}% Greedy Selection: Val={avg_val:,.1f} EstErr={avg_err:.2f}")
        logging.info(f"  ✅ Exp{exp_id} Ratio={r}% Averaged -> Val={avg_val:,.1f}, EstErr={avg_err:.2f}")

def main():
    setup_logging("greedy_exp4_8_results.txt")
    config = Config()
    config.TOTAL_ROUNDS = 5000
    config.DEFAULT_NUM_WORKERS = 2000
    logging.info(f"📊 Greedy-Only Runner | T={config.TOTAL_ROUNDS}, N={config.DEFAULT_NUM_WORKERS}")
    dataloader = get_dataloader(config, dataset_type='NYC')
    ratios = [0, 10, 30, 50, 70]
    t0 = time.time()
    run_greedy_sweep(4, ratios, config.DEFAULT_NUM_WORKERS, config.TOTAL_ROUNDS, config, dataloader, num_runs=5)
    run_greedy_sweep(8, ratios, config.DEFAULT_NUM_WORKERS, config.TOTAL_ROUNDS, config, dataloader, num_runs=5)
    logging.info(f"\n🏁 全部完成，总耗时: {time.time()-t0:.1f}s")
    logging.info(f"📂 日志已保存至: greedy_exp4_8_results.txt")
    logging.info(f"🔄 下一步: python logsave.py")

if __name__ == '__main__':
    main()