# src/main_sensitivity_clean.py
import os
import numpy as np
import random
import logging
import time
import pandas as pd
import matplotlib.pyplot as plt

from src.config import Config
from src.worker import Worker
from platform import Platform
from src.metrics import Metrics
from src.main import setup_file_logger

# ==========================================
# 0. 全局配置
# ==========================================
NUM_RUNS = 5  # 保持 5 次运行取平均，保证曲线平滑
SEED = 42

# 参数范围
RANGE_LR = [0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.7, 0.9]
RANGE_EPS = [0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5]
RANGE_FACTOR = [1.1, 1.5, 2.0, 3.0, 4.0, 5.0, 8.0, 10.0]
RANGE_REP_LR = [0.01, 0.05, 0.1, 0.2, 0.3, 0.5, 0.7]
RANGE_REP_BETA = [0.0, 0.1, 0.3, 0.5, 0.8, 1.0, 1.5, 2.0, 3.0]


# ==========================================
# 1. 高性能 Worker 补丁
# ==========================================
def patched_worker_update_state_fast(self, task_context, data_loader, current_round_id):
    my_offset = (self.id * 9973 + SEED) % 401 - 200
    DRIFT_START = 2000
    DRIFT_WINDOW = 500
    my_drift_start = DRIFT_START + my_offset

    if current_round_id < my_drift_start:
        alpha = 0.0
    elif current_round_id > my_drift_start + DRIFT_WINDOW:
        alpha = 1.0
    else:
        alpha = (current_round_id - my_drift_start) / DRIFT_WINDOW

    q_old, c_old = self.base_quality, self.unit_cost_factor
    if q_old > 0.8:
        q_new, c_new = 0.1, c_old * 5.0
    else:
        q_new, c_new = 1.2, c_old * 0.8

    eff_q = (1 - alpha) * q_old + alpha * q_new
    eff_c = (1 - alpha) * c_old + alpha * c_new

    if random.random() < 0.1: self.online_status = 0.0 if self.online_status == 1.0 else 1.0
    perf = eff_q * self.online_status

    if task_context is not None:
        density = task_context.get('density', 1.0)
        dens_factor = np.log1p(density)
        base_val = getattr(self.config, 'DATASET_BASE_VAL', 1000.0)
        base_cost = getattr(self.config, 'DATASET_BASE_COST', 200.0)

        noise = random.uniform(0.9, 1.1)
        self.true_utility = perf * base_val * (1 + dens_factor * 0.2) * noise
        self.true_cost = eff_c * base_cost * (1 + dens_factor * 0.1) * noise

        if self.true_utility < self.true_cost:
            self.true_utility = self.true_cost * 1.1
    else:
        self.true_utility = perf * 100.0
        self.true_cost = eff_c * 20.0


Worker.update_state_for_round = patched_worker_update_state_fast


# ==========================================
# 2. 仿真运行器
# ==========================================
def run_simulation(model, workers, config, data_loader):
    if hasattr(model, 'reset'):
        model.reset()
        if hasattr(model, 'worker_weights'):
            model.worker_weights = {wid: 1.0 for wid in workers.keys()}

    for w in workers.values(): w.reset()

    rounds = config.TOTAL_ROUNDS
    model.net_social_value_history = []
    model.worker_profit_history_agg = []

    keys = list(data_loader.context_maps.keys()) if data_loader and data_loader.context_maps else []

    for i in range(rounds):
        ctx = None
        if keys:
            rk = random.choice(keys)
            grid, hour = rk[0], rk[1] if len(rk) < 3 else (rk[0], rk[1])
            d = data_loader.context_maps.get((grid, hour, 'density'), 1.0)
            imp = data_loader.context_maps.get((grid, hour, 'importance'), 1.0)
            ctx = {'density': d, 'importance': imp}

        active = []
        for wid, w in workers.items():
            w.update_state_for_round(ctx, data_loader, i)
            if w.online_status > 0: active.append(wid)

        winners, payments = model.run_round(i, active, workers, data_loader)

        if winners:
            p = np.mean([payments.get(w, 0) - workers[w].true_cost for w in winners])
        else:
            p = 0
        model.worker_profit_history_agg.append(p)

    final_val = Metrics.calculate_cumulative_value(model.net_social_value_history)[-1]
    avg_prof = np.mean(model.worker_profit_history_agg)
    return final_val, avg_prof


def get_fresh_workers(n, config):
    return {wid: Worker(wid, config) for wid in range(n)}


# ==========================================
# 3. 绘图函数 (Clean Version: No Error Bars)
# ==========================================
def plot_sensitivity_clean(results_data, metric_key, y_label, title, filename):
    """
    仅绘制平均值连线，不绘制误差棒，使图表更清晰，符合趋势分析的需求。
    """
    params = list(results_data.keys())
    num_params = len(params)

    cols = min(3, num_params)
    rows = (num_params + cols - 1) // cols

    fig, axes = plt.subplots(rows, cols, figsize=(5 * cols, 4 * rows))
    if num_params > 1:
        axes = np.array(axes).flatten()
    else:
        axes = [axes]

    for i, param_name in enumerate(params):
        ax = axes[i]
        data = results_data[param_name]

        # [修改] 使用 plot 而不是 errorbar，只画均值点和连线
        ax.plot(data['x'], data['y'],
                marker='o', linestyle='-', color='#d62728',
                linewidth=2, markersize=6, label='POETIC')

        ax.set_xlabel(param_name, fontsize=12)
        ax.set_ylabel(y_label, fontsize=12)
        ax.set_title(f"Impact of {param_name}", fontsize=14)
        ax.grid(True, linestyle=':', alpha=0.6)

        if 'Value' in y_label:
            ax.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))

    if num_params > 1:
        for j in range(i + 1, len(axes)):
            fig.delaxes(axes[j])

    plt.suptitle(title, fontsize=16, y=1.02)
    plt.tight_layout()
    plt.savefig(filename, bbox_inches='tight')
    plt.close()
    logging.info(f"Saved clean plot to {filename}")


# ==========================================
# 4. 主程序
# ==========================================
def main_clean():
    config = Config()

    os.makedirs(config.FIGURES_DIR, exist_ok=True)
    os.makedirs(config.LOGS_DIR, exist_ok=True)
    setup_file_logger(os.path.join(config.LOGS_DIR, f"sens_clean_{time.strftime('%H%M')}.txt"))

    DATASETS = {
        'TDrive': {'val': 1200.0, 'cost': 300.0, 'w_cap': 1500.0, 'sens': 1000.0},
        'NYC': {'val': 200.0, 'cost': 50.0, 'w_cap': 300.0, 'sens': 300.0}
    }

    for dataset_name, params in DATASETS.items():
        logging.info(f"\n{'=' * 40}\nRunning Clean Sensitivity on {dataset_name}\n{'=' * 40}")

        config.DATASET_BASE_VAL = params['val']
        config.DATASET_BASE_COST = params['cost']
        config.WEIGHT_CAP = params['w_cap']
        config.LAPLACE_SENSITIVITY = params['sens']

        from src.data_loader import get_dataloader
        data_loader = get_dataloader(config, dataset_type=dataset_name)
        workers = get_fresh_workers(config.DEFAULT_NUM_WORKERS, config)

        default_state = {
            "LEARNING_RATE": config.LEARNING_RATE,
            "EXPLORATION_EPSILON": config.EXPLORATION_EPSILON,
            "ELITE_POOL_FACTOR": config.ELITE_POOL_FACTOR,
            "REPUTATION_LEARNING_RATE": config.REPUTATION_LEARNING_RATE,
            "REPUTATION_BONUS_FACTOR": config.REPUTATION_BONUS_FACTOR
        }

        # Value Sensitive Params
        VAL_PARAMS = [
            ("Learning Rate", "LEARNING_RATE", RANGE_LR),
            ("Epsilon", "EXPLORATION_EPSILON", RANGE_EPS),
            ("Elite Factor", "ELITE_POOL_FACTOR", RANGE_FACTOR)
        ]

        viz_val_data = {}
        for label, attr, rng in VAL_PARAMS:
            logging.info(f"Analyzing {label} (Value)...")
            x, y = [], []
            for val in rng:
                setattr(config, attr, val)
                temp = []
                for r in range(NUM_RUNS):
                    random.seed(SEED + r);
                    np.random.seed(SEED + r)
                    poetic = Platform(config, list(workers.keys()))
                    poetic.worker_weights = {w: config.WEIGHT_CAP for w in workers}
                    v, _ = run_simulation(poetic, workers, config, data_loader)
                    temp.append(v)
                x.append(val);
                y.append(np.mean(temp))
            viz_val_data[label] = {'x': x, 'y': y}
            setattr(config, attr, default_state[attr])

        # Profit Sensitive Params
        PROF_PARAMS = [
            ("Reputation LR", "REPUTATION_LEARNING_RATE", RANGE_REP_LR),
            ("Reputation Beta", "REPUTATION_BONUS_FACTOR", RANGE_REP_BETA)
        ]

        viz_prof_data = {}
        for label, attr, rng in PROF_PARAMS:
            logging.info(f"Analyzing {label} (Profit)...")
            x, y = [], []
            for val in rng:
                setattr(config, attr, val)
                temp = []
                for r in range(NUM_RUNS):
                    random.seed(SEED + r);
                    np.random.seed(SEED + r)
                    poetic = Platform(config, list(workers.keys()))
                    poetic.worker_weights = {w: config.WEIGHT_CAP for w in workers}
                    _, p = run_simulation(poetic, workers, config, data_loader)
                    temp.append(p)
                x.append(val);
                y.append(np.mean(temp))
            viz_prof_data[label] = {'x': x, 'y': y}
            setattr(config, attr, default_state[attr])

        # Plotting (Clean)
        plot_sensitivity_clean(
            viz_val_data, 'Final Cumulative Value', "Mean Final Value",
            f"Sensitivity Analysis: Platform Value ({dataset_name})",
            os.path.join(config.FIGURES_DIR, f"exp_sens_val_{dataset_name}.pdf")
        )

        plot_sensitivity_clean(
            viz_prof_data, 'Avg Worker Profit', "Mean Avg Profit",
            f"Sensitivity Analysis: Worker Profit ({dataset_name})",
            os.path.join(config.FIGURES_DIR, f"exp_sens_prof_{dataset_name}.pdf")
        )

    logging.info("Clean Sensitivity Analysis Completed.")


if __name__ == '__main__':
    main_clean()