# -*- coding: utf-8 -*-
"""
修改博士汇报PPT：润色语言 + 精简文字
"""
from pptx import Presentation
from pptx.util import Pt
import copy
import sys
sys.stdout.reconfigure(encoding='utf-8')

prs = Presentation(r'd:\src\博士汇报.pptx')
slides = prs.slides


def set_text_preserve_format(text_frame, new_paragraphs):
    """
    Replace text in a text_frame while preserving first run's formatting.
    new_paragraphs: list of strings, each becomes a paragraph.
    """
    # Save first paragraph/run formatting as template
    if text_frame.paragraphs and text_frame.paragraphs[0].runs:
        template_run = text_frame.paragraphs[0].runs[0]
        template_font_size = template_run.font.size
        template_font_bold = template_run.font.bold
        template_font_name = template_run.font.name
        try:
            template_font_color = template_run.font.color.rgb if template_run.font.color and template_run.font.color.rgb else None
        except:
            template_font_color = None
    else:
        template_font_size = None
        template_font_bold = None
        template_font_name = None
        template_font_color = None

    # Save paragraph-level formatting
    template_para = text_frame.paragraphs[0]
    template_alignment = template_para.alignment
    template_space_before = template_para.space_before
    template_space_after = template_para.space_after
    template_line_spacing = template_para.line_spacing

    # Clear all paragraphs
    for i in range(len(text_frame.paragraphs) - 1, 0, -1):
        p = text_frame.paragraphs[i]._p
        p.getparent().remove(p)

    # Set first paragraph
    first_para = text_frame.paragraphs[0]
    # Clear runs in first paragraph
    for r in first_para.runs:
        r._r.getparent().remove(r._r)

    for idx, text in enumerate(new_paragraphs):
        if idx == 0:
            para = first_para
        else:
            from pptx.oxml.ns import qn
            # Clone the first paragraph element
            new_p = copy.deepcopy(first_para._p)
            # Remove runs from clone
            for r in new_p.findall(qn('a:r')):
                new_p.remove(r)
            text_frame._txBody.append(new_p)
            para = text_frame.paragraphs[idx]

        # Set alignment
        para.alignment = template_alignment
        para.space_before = template_space_before
        para.space_after = template_space_after
        para.line_spacing = template_line_spacing

        run = para.add_run()
        run.text = text
        if template_font_size:
            run.font.size = template_font_size
        if template_font_bold is not None:
            run.font.bold = template_font_bold
        if template_font_name:
            run.font.name = template_font_name
        if template_font_color:
            run.font.color.rgb = template_font_color


# ===== 第2页 - 个人简介 =====
slide2 = slides[1]
for shape in slide2.shapes:
    if hasattr(shape, 'text_frame'):
        text = shape.text_frame.text
        if '\u6559\u80b2\u7ecf\u5386' in text:  # 教育经历
            set_text_preserve_format(shape.text_frame, [
                '\u6559\u80b2\u7ecf\u5386\uff1a',  # 教育经历：
                '\u7855\u58eb\uff1a\u6cb3\u5317\u5927\u5b66 \u00b7 \u7f51\u7edc\u7a7a\u95f4\u5b89\u5168',  # 硕士：河北大学 · 网络空间安全
                '\u672c\u79d1\uff1a\u6e58\u6f6d\u5927\u5b66 \u00b7 \u6570\u636e\u79d1\u5b66\u4e0e\u5927\u6570\u636e\u6280\u672f',  # 本科：湘潭大学 · 数据科学与大数据技术
            ])
            print('Done: Slide 2 - Education')

        if '\u7855\u58eb\u671f\u95f4\u4e3b\u8981\u7814\u7a76\u65b9\u5411' in text:  # 硕士期间主要研究方向
            set_text_preserve_format(shape.text_frame, [
                '\u7814\u7a76\u65b9\u5411\uff1a',  # 研究方向：
                '\u2022 \u7a7a\u95f4\u4f17\u5305\u4e2d\u7684\u65f6\u7a7a\u6570\u636e\u6316\u6398\u4e0e\u9690\u79c1\u4fdd\u62a4',  # • 空间众包中的时空数据挖掘与隐私保护
                '\u2022 \u9884\u6d4b\u9a71\u52a8\u7684\u4efb\u52a1\u8c03\u5ea6\u4e0e\u6fc0\u52b1\u673a\u5236\u8bbe\u8ba1',  # • 预测驱动的任务调度与激励机制设计
            ])
            print('Done: Slide 2 - Research Direction')


# ===== 第3页 - 研究脉络 =====
slide3 = slides[2]
for shape in slide3.shapes:
    if hasattr(shape, 'text_frame'):
        text = shape.text_frame.text
        if '\u7855\u58eb\u7814\u7a76\u4e3b\u7ebf' in text:  # 硕士研究主线
            set_text_preserve_format(shape.text_frame, [
                '\u7855\u58eb\u4e3b\u7ebf\uff1a\u7a7a\u95f4\u4f17\u5305\u201c\u9884\u6d4b-\u8c03\u5ea6-\u6fc0\u52b1\u201d\u534f\u540c\u4f18\u5316',  # 硕士主线：空间众包"预测-调度-激励"协同优化
                '',
                '\u95ee\u9898\u9a71\u52a8\uff1a\u52a8\u6001\u73af\u5883 + \u9690\u79c1\u7ea6\u675f + \u6fc0\u52b1\u517c\u5bb9',  # 问题驱动：动态环境 + 隐私约束 + 激励兼容
                '\u6280\u672f\u8def\u7ebf\uff1aSTGNN + FL + DP + \u5728\u7ebf\u673a\u5236\u8bbe\u8ba1',  # 技术路线：STGNN + FL + DP + 在线机制设计
                '\u5e94\u7528\u4ef7\u503c\uff1a\u57ce\u5e02\u7ea7\u7fa4\u667a\u611f\u77e5\u7cfb\u7edf\u7684\u6548\u7387\u4e0e\u516c\u5e73\u6027',  # 应用价值：城市级群智感知系统的效率与公平性
                '',
                '\u6838\u5fc3\u601d\u8def\uff1a\u4ece\u6570\u636e\u611f\u77e5\u5230\u884c\u4e3a\u6fc0\u52b1\u7684\u5b8c\u6574\u95ed\u73af',  # 核心思路：从数据感知到行为激励的完整闭环
            ])
            print('Done: Slide 3 - Research Thread')


# ===== 第4页 - 研究成果 =====
slide4 = slides[3]
for shape in slide4.shapes:
    if hasattr(shape, 'text_frame'):
        text = shape.text_frame.text
        if '\u653b\u8bfb\u7855\u58eb' in text:  # 攻读硕士
            set_text_preserve_format(shape.text_frame, [
                '\u7855\u58eb\u671f\u95f4\u4ee5\u6838\u5fc3\u4f5c\u8005\u5b8c\u6210\u4e24\u7bc7\u8bba\u6587\uff08\u5bfc\u5e08\u4e00\u4f5c\uff0c\u672c\u4eba\u901a\u8baf\uff09',  # 硕士期间以核心作者完成两篇论文（导师一作，本人通讯）
                '',
                '\u2460 STDFL: A Spatio-Temporal Aware Dynamic Federated Learning Framework for Spatial Crowdsourcing',
                '   IEEE TMC, 2026. CCF A\u7c7b\uff0c\u5df2\u5f55\u7528',  # CCF A类，已录用
                '',
                '\u2461 POETIC: Stable Online Utility Learning under Strategic and Privacy-Preserving Spatial Crowdsourcing',
                '   \u5df2\u5b8c\u6210\u4fee\u6539\uff0c\u76ee\u6807\u6295\u7a3f ICDE 2027\uff08CCF A\u7c7b\u4f1a\u8bae\uff09',  # 已完成修改，目标投稿 ICDE 2027（CCF A类会议）
                '',
                '\u2462 IACR: LLM-Driven Multi-Agent Reinforcement Learning',
                '   \u7814\u7a76\u8fdb\u884c\u4e2d\uff0c\u9884\u8ba12026\u5e74\u4e0b\u534a\u5e74\u5b8c\u6210',  # 研究进行中，预计2026年下半年完成
            ])
            print('Done: Slide 4 - Research Results')


# ===== 第5页 - STDFL问题 =====
slide5 = slides[4]
for shape in slide5.shapes:
    if hasattr(shape, 'text_frame'):
        text = shape.text_frame.text
        if '\u5728\u6781\u7aef' in text:  # 在极端
            set_text_preserve_format(shape.text_frame, [
                '\u6838\u5fc3\u95ee\u9898\uff1a\u6781\u7aefNon-IID\u4e0e\u9690\u79c1\u7ea6\u675f\u4e0b\uff0c\u5982\u4f55\u5b9e\u73b0\u9884\u6d4b\u4e0e\u8c03\u5ea6\u7684\u534f\u540c\u4f18\u5316\uff1f',  # 核心问题：极端Non-IID与隐私约束下，如何实现预测与调度的协同优化？
            ])
            print('Done: Slide 5 - Core Question')

        if '\u6570\u636e\u5b64\u5c9b' in text:  # 数据孤岛
            set_text_preserve_format(shape.text_frame, [
                '\u6570\u636e\u5f02\u8d28\u6027\uff1a\u533a\u57df\u95f4\u6f6e\u6c50\u6548\u5e94\u5dee\u5f02\u663e\u8457\uff0c\u76f4\u63a5\u5957\u7528FL\u5bfc\u81f4\u6a21\u578b\u6f02\u79fb',  # 数据异质性：区域间潮汐效应差异显著，直接套用FL导致模型漂移
            ])
            print('Done: Slide 5 - Pain Point 1')

        if '\u4f20\u7edf\u65b9\u6cd5\u5b58\u5728' in text:  # 传统方法存在
            set_text_preserve_format(shape.text_frame, [
                '\u9884\u6d4b-\u8c03\u5ea6\u8131\u8282\uff1a\u4f4e\u8bef\u5dee \u2260 \u9ad8\u5206\u914d\u6548\u7387',  # 预测-调度脱节：低误差 ≠ 高分配效率
            ])
            print('Done: Slide 5 - Pain Point 2')


# ===== 第6页 - STDFL方法 =====
slide6 = slides[5]
for shape in slide6.shapes:
    if hasattr(shape, 'text_frame'):
        text = shape.text_frame.text
        if '\u5206\u5c42\u65f6\u7a7a\u5efa\u6a21' in text:  # 分层时空建模
            set_text_preserve_format(shape.text_frame, [
                '\u5206\u5c42\u65f6\u7a7a\u5efa\u6a21\uff1a\u5ba2\u6237\u7aef\u8f7b\u91cfGNN + \u670d\u52a1\u7aefTransformer',  # 分层时空建模：客户端轻量GNN + 服务端Transformer
                '\u52a8\u6001\u805a\u5408\uff08ST-BPA\uff09\uff1a\u7a7a\u95f4\u76f8\u4f3c\u6027 + \u65f6\u95f4\u65b0\u9c9c\u5ea6\u81ea\u9002\u5e94\u52a0\u6743',  # 动态聚合（ST-BPA）：空间相似性 + 时间新鲜度自适应加权
                '\u9884\u6d4b\u9a71\u52a8\u8c03\u5ea6\uff08PDS\uff09\uff1a\u9884\u6d4b\u4fe1\u53f7\u2192\u52a0\u6743\u4e8c\u5206\u56fe\u5339\u914d\uff0c\u96f6RL\u8bad\u7ec3\u5f00\u9500',  # 预测驱动调度（PDS）：预测信号→加权二分图匹配，零RL训练开销
            ])
            print('Done: Slide 6 - STDFL Method')


# ===== 第8页 - POETIC问题 =====
slide8 = slides[7]
for shape in slide8.shapes:
    if hasattr(shape, 'text_frame'):
        text = shape.text_frame.text
        if '\u5f53\u7cfb\u7edf\u5f15\u5165DP' in text:  # 当系统引入DP
            set_text_preserve_format(shape.text_frame, [
                'DP\u566a\u58f0\u4e0e\u6076\u610f\u62a5\u4ef7\u7b56\u7565\u8026\u5408\uff0c\u6c61\u67d3MAB\u5b66\u4e60\u5f15\u64ce\uff0c\u5bfc\u81f4\u5de5\u4eba\u8d28\u91cf\u8bef\u5224',  # DP噪声与恶意报价策略耦合，污染MAB学习引擎，导致工人质量误判
            ])
            print('Done: Slide 8 - Problem 1')

        if '\u50bb\u767d\u751c' in text:  # 傻白甜
            set_text_preserve_format(shape.text_frame, [
                '\u5de5\u4eba\u5177\u6709\u524d\u77bb\u6027\u7b56\u7565\u884c\u4e3a\uff0c\u4f1a\u901a\u8fc7\u957f\u671f\u62a5\u4ef7\u64cd\u7eb5\u8fdb\u884c\u5957\u5229',  # 工人具有前瞻性策略行为，会通过长期报价操纵进行套利
            ])
            print('Done: Slide 8 - Problem 2')


# ===== 第9页 - POETIC方法 =====
slide9 = slides[8]
for shape in slide9.shapes:
    if hasattr(shape, 'text_frame'):
        text = shape.text_frame.text
        if '\u53cc\u670d\u52a1\u5668\u89e3\u8026\u67b6\u6784' in text:  # 双服务器解耦架构
            set_text_preserve_format(shape.text_frame, [
                '\u53cc\u670d\u52a1\u5668\u89e3\u8026\uff1a\u8bc4\u4f30\u4e0e\u652f\u4ed8\u7269\u7406\u9694\u79bb\uff0c\u5207\u65ad\u6076\u610f\u62a5\u4ef7\u6c61\u67d3\u5b66\u4e60\u4fe1\u53f7\u7684\u8def\u5f84',  # 双服务器解耦：评估与支付物理隔离，切断恶意报价污染学习信号的路径
                '',
                'StabRep\u673a\u5236\uff1a\u4e8c\u9636\u8bef\u5dee\u8ddf\u8e2a\u68c0\u6d4b\u9707\u8361\u578b\u653b\u51fb\uff0c\u65b9\u5dee\u60e9\u7f5a\u9a71\u52a8\u4fe1\u8a89\u5feb\u901f\u5f52\u96f6',  # StabRep机制：二阶误差跟踪检测震荡型攻击，方差惩罚驱动信誉快速归零
            ])
            print('Done: Slide 9 - POETIC Method')


# ===== 第11页 - IACR =====
slide11 = slides[10]
for shape in slide11.shapes:
    if hasattr(shape, 'text_frame'):
        text = shape.text_frame.text
        if 'LLM' in text and '\u5b8f\u89c2' in text:  # LLM + 宏观
            set_text_preserve_format(shape.text_frame, [
                'LLM\u4f5c\u4e3a\u5b8f\u89c2\u7b56\u7565\u6559\u7ec3\uff0c\u4e3a\u5fae\u89c2\u6267\u884c\u667a\u80fd\u4f53\u63d0\u4f9b\u8bed\u4e49\u6307\u5bfc\u4e0e\u534f\u8c03',  # LLM作为宏观策略教练，为微观执行智能体提供语义指导与协调
            ])
            print('Done: Slide 11 - IACR')


# ===== 第12页 - 博士研究设想 =====
slide12 = slides[11]
for shape in slide12.shapes:
    if hasattr(shape, 'text_frame'):
        text = shape.text_frame.text
        if '\u5927\u6a21\u578b\u589e\u5f3a' in text:  # 大模型增强
            set_text_preserve_format(shape.text_frame, [
                '\u65b9\u5411\u4e00\uff1a\u5927\u6a21\u578b\u589e\u5f3a\u7684\u65f6\u7a7a\u6316\u6398\u4e0e\u53ef\u89e3\u91ca\u7fa4\u667a\u51b3\u7b56',  # 方向一：大模型增强的时空挖掘与可解释群智决策
                '\u878d\u5408LLM\u8bed\u4e49\u63a8\u7406\u4e0eSTGNN\uff0c\u751f\u6210\u53ef\u89e3\u91ca\u7684\u8c03\u5ea6\u51b3\u7b56\u94fe',  # 融合LLM语义推理与STGNN，生成可解释的调度决策链
                '',
                '\u65b9\u5411\u4e8c\uff1a\u8054\u90a6\u6a21\u4eff\u5b66\u4e60\u4e0e\u5206\u5e03\u5f0f\u534f\u540c\u63a7\u5236',  # 方向二：联邦模仿学习与分布式协同控制
                '\u9690\u5f0f\u514b\u9686\u4e13\u5bb6\u7b56\u7565\uff0c\u89e3\u51b3MARL\u51b7\u542f\u52a8\u4e0e\u6536\u655b\u4e0d\u7a33\u5b9a\u95ee\u9898',  # 隐式克隆专家策略，解决MARL冷启动与收敛不稳定问题
                '',
                '\u65b9\u5411\u4e09\uff1a\u975e\u5e73\u7a33\u73af\u5883\u4e0b\u7684\u9690\u79c1\u5b89\u5168\u6cbb\u7406\u4e0e\u535a\u5f08\u6fc0\u52b1',  # 方向三：非平稳环境下的隐私安全治理与博弈激励
                '\u81ea\u9002\u5e94DP + SMPC\uff0c\u6784\u5efa\u6297\u6295\u6bd2/\u6297\u535a\u5f08\u7684\u957f\u6548\u9690\u79c1\u4fdd\u62a4\u95ed\u73af',  # 自适应DP + SMPC，构建抗投毒/抗博弈的长效隐私保护闭环
            ])
            print('Done: Slide 12 - PhD Plan')


# ===== 保存 =====
output_path = r'd:\src\博士汇报_润色版.pptx'
prs.save(output_path)
print(f'\nAll done! Saved to: {output_path}')
