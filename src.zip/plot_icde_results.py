import matplotlib.pyplot as plt
import numpy as np

# ==========================================
# 1. 核心数据准备 (精确提取自实验日志)
# ==========================================
# X 轴: 操纵强度 (Manipulation Intensity r)
r_values = np.array([0.0, 0.1, 0.2, 0.3, 0.4, 0.5])

# --- 左图数据: 依赖度/失真度 (Dep) ---
dep_data = {
    "POETIC (Ours)":   [0.0015, 0.0015, 0.0015, 0.0015, 0.0015, 0.0015],
    "POETIC w/o $\Phi$": [0.1063, 0.1100, 0.1338, 0.1644, 0.1728, 0.1827],
    "PrivCO":          [0.2890, 0.3548, 0.4186, 0.4659, 0.5119, 0.5516],
    "Truthful-DP-MAB": [0.0483, 0.1042, 0.1088, 0.1179, 0.1060, 0.1096]
}

# --- 右图数据: 估计漂移 (Drift) ---
drift_data = {
    "POETIC (Ours)":   [109.38, 109.23, 109.15, 108.81, 108.74, 108.31],
    "POETIC w/o $\Phi$": [125.63, 170.63, 198.68, 207.90, 213.44, 214.65],
    "PrivCO":          [0.00,   0.00,   0.00,   0.00,   0.00,   0.00],
    "Truthful-DP-MAB": [118.97, 934.67, 1060.36, 1104.56, 1131.80, 1141.03]
}

# ==========================================
# 2. 学术排版与视觉样式定义
# ==========================================
plt.rcParams.update({'font.size': 14, 'font.family': 'serif'})

# 全局样式映射表，保持与之前图表的颜色和标记一致
styles = {
    "POETIC (Ours)":   {"c": "#003366", "marker": "o", "ls": "-",  "lw": 2.8, "ms": 9, "zorder": 5},
    "POETIC w/o $\Phi$": {"c": "#D95319", "marker": "s", "ls": "--", "lw": 2.5, "ms": 8, "zorder": 4},
    "PrivCO":          {"c": "#CC3333", "marker": "D", "ls": "-.", "lw": 2.2, "ms": 8, "zorder": 3},
    "Truthful-DP-MAB": {"c": "#9933CC", "marker": "v", "ls": ":",  "lw": 2.2, "ms": 8, "zorder": 3}
}

# ==========================================
# 3. 核心绘图引擎 (1 x 2 架构)
# ==========================================
fig, axs = plt.subplots(1, 2, figsize=(14, 6))
fig.subplots_adjust(wspace=0.25)

# --- 绘制左图: Dependency (Dep) ---
ax1 = axs[0]
for model, vals in dep_data.items():
    st = styles[model]
    ax1.plot(r_values, vals, label=model, color=st['c'], marker=st['marker'], 
             linestyle=st['ls'], linewidth=st['lw'], markersize=st['ms'], zorder=st['zorder'])

ax1.set_title("(a) Feedback Dependency vs. Attacker Ratio", pad=15, fontweight='bold', fontsize=15)
ax1.set_xlabel("Manipulation Intensity ($r$)")
ax1.set_ylabel("Dependency Score (Dep)", labelpad=8)
ax1.set_xticks(r_values)
ax1.grid(True, linestyle='--', alpha=0.5, zorder=0)
# 将图例放置在左上角，确保不会遮挡不断上升的曲线
ax1.legend(loc="upper left", framealpha=0.9, edgecolor='black', fontsize=12)


# --- 绘制右图: Estimation Drift (Drift) ---
ax2 = axs[1]
for model, vals in drift_data.items():
    st = styles[model]
    ax2.plot(r_values, vals, label=model, color=st['c'], marker=st['marker'], 
             linestyle=st['ls'], linewidth=st['lw'], markersize=st['ms'], zorder=st['zorder'])

ax2.set_title("(b) Estimation Drift vs. Attacker Ratio", pad=15, fontweight='bold', fontsize=15)
ax2.set_xlabel("Manipulation Intensity ($r$)")
ax2.set_ylabel("Estimation Drift", labelpad=8)
ax2.set_xticks(r_values)
ax2.grid(True, linestyle='--', alpha=0.5, zorder=0)
# 由于 Truthful-DP-MAB 在右图中急剧上升，图例最安全的放置位置是中左侧或下侧
ax2.legend(loc="center right", framealpha=0.9, edgecolor='black', fontsize=12)

# 统一保存为极高分辨率 PDF
plt.savefig("exp_c_decoupling_effectiveness.pdf", format='pdf', dpi=400, bbox_inches='tight')
plt.show()