import os
import re
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns

# =====================================================================
# 1. ICDE-STRICT GLOBAL SETTINGS
# =====================================================================
STYLES = {
    'POETIC':              {'color': '#E63946', 'marker': 'o', 'ls': '-',  'lw': 2.5, 'label': 'POETIC'},
    'POETIC-slow':         {'color': '#1D3557', 'marker': 's', 'ls': '--', 'lw': 2.0, 'label': 'POETIC-slow'},
    'PrivCO':              {'color': '#457B9D', 'marker': 'D', 'ls': '-.', 'lw': 2.0, 'label': 'PrivCO'},
    'Truthful-DP-MAB':     {'color': '#2A9D8F', 'marker': 'x', 'ls': ':',  'lw': 2.0, 'label': 'Truthful-DP-MAB'},
    'OPPS-adapted':        {'color': '#F4A261', 'marker': '^', 'ls': '-.', 'lw': 2.0, 'label': 'OPPS-adapted'},
    'Random':              {'color': '#7f8c8d', 'marker': '.', 'ls': '-.', 'lw': 2.0, 'label': 'Random'},
    'Non-Private Optimal': {'color': '#000000', 'marker': '',  'ls': '--', 'lw': 2.0, 'label': 'Non-Private Optimal'},
    'POETIC (Full)':       {'color': '#E63946', 'marker': 'o', 'ls': '-',  'lw': 2.5, 'label': 'POETIC (Full)'},
    r'w/o \Phi':           {'color': '#d35400', 'marker': 's', 'ls': '--', 'lw': 2.0, 'label': r'w/o $\Phi$'},
    'w/o StabRep':        {'color': '#e67e22', 'marker': 'v', 'ls': '--', 'lw': 2.0, 'label': 'w/o StabRep'},
    'w/o Both':           {'color': '#95a5a6', 'marker': 'p', 'ls': '--', 'lw': 2.0, 'label': 'w/o Both'},
}
DEFAULT_STYLE = {'color': '#333333', 'marker': 'o', 'ls': '-', 'lw': 1.0}

plt.style.use('seaborn-v0_8-white')
mpl.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'axes.labelsize': 12, 'axes.titlesize': 14, 'legend.fontsize': 10,
    'xtick.labelsize': 10, 'ytick.labelsize': 10, 'figure.dpi': 300,
    'grid.alpha': 0.3, 'grid.linestyle': '--', 'axes.grid': True,
    'text.usetex': False,
})

OUTPUT_DIR = r'd:\src\results\figures'
os.makedirs(OUTPUT_DIR, exist_ok=True)

# =====================================================================
# 2. COMPREHENSIVE LOG PARSER
# =====================================================================

def parse_logs(nyc_path, td_path, eff_path):
    def _parse(path):
        if not os.path.exists(path): return {}
        data = {i: {} for i in range(1, 10)}
        curr_exp = None
        curr_ratio = None
        curr_eps = None
        
        re_exp = re.compile(r'Exp ICDE-(\d+):')
        re_ratio_hdr = re.compile(r'---\s+(?:Strategic|Adversarial)\s+Ratio\s+=\s+([\d.]+)%')
        re_eps_hdr = re.compile(r'---\s+ε\s+=\s+([\d.]+|inf)')
        re_round = re.compile(r'\[Round\s+(\d+)\]\s+([^:]+):\s+Val=\s*([\d,.-]+)\s+EstErr=\s*([\d,.-]+)')
        # Final Sweep: Ratio=0% POETIC: Val=...
        re_final_stat = re.compile(r'(?:Ratio|ratio|ε)=([\d.]+|inf)%?[^0-9a-zA-Z]*([\d.]+|inf)?\s+([^:]+):\s+(?:Val=([\d,.-]+)\s+)?EstErr=([\d,.-]+)(?:\s+Var=([\d,.-]+))?')
        re_rep = re.compile(r'\[([^\]]+)\] Manip=([\d.]+)\s+Stable=([\d.]+)\s+Gap=([\d.-]+)')

        def _norm(x):
            if x is None: return None
            if x == 'inf': return 'inf'
            try: return str(int(float(x))) if float(x) == int(float(x)) else str(float(x))
            except: return x

        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                me = re_exp.search(line)
                if me: curr_exp = int(me.group(1)); continue
                if not curr_exp: continue
                
                mrh = re_ratio_hdr.search(line)
                if mrh: curr_ratio = float(mrh.group(1)); continue
                meh = re_eps_hdr.search(line)
                if meh: curr_eps = float(meh.group(1)) if meh.group(1)!='inf' else np.inf; continue
                
                mt = re_round.search(line)
                if mt:
                    rnd, model, val, err = int(mt.group(1)), mt.group(2).strip(), float(mt.group(3).replace(',','')), float(mt.group(4))
                    if model not in data[curr_exp]: data[curr_exp][model] = {'traj': [], 'final': {}}
                    data[curr_exp][model]['traj'].append({'rnd': rnd, 'ratio': curr_ratio, 'eps': curr_eps, 'val': val, 'err': err})
                
                mf = re_final_stat.search(line)
                if mf:
                    p1, p2, model, val, err, var = mf.group(1), mf.group(2), mf.group(3).strip(), mf.group(4), mf.group(5), mf.group(6)
                    val = float(val.replace(',','')) if val else 0
                    err = float(err.replace(',','')) if err else 0
                    var = float(var.replace(',','')) if var else 0
                    key = _norm(p1) if not p2 else (_norm(p1), _norm(p2))
                    if model not in data[curr_exp]: data[curr_exp][model] = {'traj': [], 'final': {}}
                    data[curr_exp][model]['final'][key] = {'val': val, 'err': err, 'var': var}

                mr = re_rep.search(line)
                if mr and curr_exp == 5:
                    lbl, manip, stable, gap = mr.group(1), float(mr.group(2)), float(mr.group(3)), float(mr.group(4))
                    if 'rep_data' not in data[5]: data[5]['rep_data'] = {}
                    data[5]['rep_data'][lbl] = {'manip': manip, 'stable': stable, 'gap': gap}
        return data

    def _parse_eff(path):
        if not path or not os.path.exists(path): return {}
        res = {'N': {'runtime': {}, 'comm': {}}, 'k': {'runtime': {}, 'comm': {}}}
        re_p = re.compile(r'Testing (N|k) = (\d+)'); re_m = re.compile(r'([A-Za-z0-9-]+)\s+: Avg Runtime=([\d.]+) ms, Avg Comm=([\d.]+) MB')
        with open(path, 'r', encoding='utf-8') as f:
            cp, cv = None, None
            for line in f:
                mp = re_p.search(line); mm = re_m.search(line)
                if mp: cp, cv = mp.group(1), int(mp.group(2))
                if mm and cp:
                    model, rt, cm = mm.group(1), float(mm.group(2)), float(mm.group(3))
                    for k, v in [('runtime', rt), ('comm', cm)]:
                        if model not in res[cp][k]: res[cp][k][model] = {'x': [], 'y': []}
                        res[cp][k][model]['x'].append(cv); res[cp][k][model]['y'].append(v)
        return res

    return {'NYC': _parse(nyc_path), 'TD': _parse(td_path), 'Eff': _parse_eff(eff_path)}

def plot_master(all_data):
    def _get_st(m): return STYLES.get(m, DEFAULT_STYLE)

    # 1. PERFORMANCE 2x3
    fig1, axes1 = plt.subplots(2, 3, figsize=(15, 9)); plt.subplots_adjust(top=0.9, hspace=0.3)
    for i, ds in enumerate(['TD', 'NYC']):
        d = all_data[ds].get(1, {})
        for m, c in d.items():
            if m not in STYLES: continue
            st = _get_st(m); rs = [t['rnd'] for t in c['traj']]; vs = [t['val'] for t in c['traj']]; es = [t['err'] for t in c['traj']]
            if not rs: continue
            axes1[i,0].plot(rs, vs, color=st['color'], marker=st['marker'], label=m, markevery=len(rs)//8)
            axes1[i,2].plot(rs, es, color=st['color'], marker=st['marker'], markevery=len(rs)//8)
            if 'Non-Private Optimal' in d:
                opt_v = {t['rnd']: t['val'] for t in d['Non-Private Optimal']['traj']}
                axes1[i,1].plot(rs, [opt_v.get(r,0)-v for r,v in zip(rs,vs)], color=st['color'], marker=st['marker'], markevery=len(rs)//8)
        for j, t in enumerate(['Utility', 'Regret', 'EstErr']): axes1[i,j].set_title(f"{ds} {t}"); axes1[i,j].set_xlabel("Rounds")
    fig1.legend(*axes1[0,0].get_legend_handles_labels(), loc='upper center', bbox_to_anchor=(0.5, 0.98), ncol=4); fig1.savefig(f"{OUTPUT_DIR}/01_performance.png")

    # 2. STRATEGIC 1x3
    fig2, axes2 = plt.subplots(1, 3, figsize=(15, 5))
    d4 = all_data['NYC'].get(4, {})
    for m, c in d4.items():
        if m not in STYLES: continue
        st = _get_st(m); fs = c['final']
        ks = sorted([float(k) for k in fs.keys()])
        vs = [fs[str(int(k)) if k==int(k) else str(k)]['val'] for k in ks]
        es = [fs[str(int(k)) if k==int(k) else str(k)]['err'] for k in ks]
        axes2[0].plot(ks, vs, color=st['color'], marker=st['marker'], label=m)
        axes2[1].plot(ks, es, color=st['color'], marker=st['marker'])
        if 'Non-Private Optimal' in d4:
            opt = max([v['val'] for v in d4['Non-Private Optimal']['final'].values()])
            axes2[2].plot(ks, [opt-v for v in vs], color=st['color'], marker=st['marker'])
    for j, t in enumerate(['Utility', 'EstErr', 'Regret']): axes2[j].set_title(t); axes2[j].set_xlabel("Ratio (%)")
    fig2.legend(*axes2[0].get_legend_handles_labels(), loc='upper center', bbox_to_anchor=(0.5, 0.98), ncol=4); fig2.savefig(f"{OUTPUT_DIR}/02_strategic.png")

    # 3. CONTAMINATION 1x4
    fig3, axes3 = plt.subplots(1, 4, figsize=(18, 5))
    d3 = all_data['NYC'].get(3, {})
    if 'POETIC' in d3:
        st = d3['POETIC']['final']
        rs = sorted(list(set([float(k[0]) for k in st.keys() if isinstance(k, tuple)])))
        es = sorted(list(set([float(k[1]) if k[1]!='inf' else 100 for k in st.keys() if isinstance(k, tuple)])))
        if rs and es:
            mat = np.zeros((len(rs), len(es)))
            for i, r in enumerate(rs):
                for j, e in enumerate(es):
                    rk, ek = (str(int(r)) if r==int(r) else str(r)), ('inf' if e==100 else (str(int(e)) if e==int(e) else str(e)))
                    mat[i,j] = st.get((rk, ek), {'err':0})['err']
            sns.heatmap(mat, annot=True, xticklabels=es, yticklabels=rs, ax=axes3[0], cmap='YlOrRd')
    d6 = all_data['NYC'].get(6, {})
    for m, c in d6.items():
        if m not in STYLES: continue
        st = _get_st(m); fs = c['final']
        ks = sorted([float(k) if k!='inf' else 10 for k in fs.keys()])
        vs = [fs[str(int(k)) if k==int(k) else str(k) if k!=10 else 'inf']['val'] for k in ks]
        es = [fs[str(int(k)) if k==int(k) else str(k) if k!=10 else 'inf']['err'] for k in ks]
        axes3[2].plot(ks, es, color=st['color'], marker=st['marker'], label=m)
        axes3[3].plot(ks, vs, color=st['color'], marker=st['marker'])
    axes3[2].set_title("EstErr vs ε"); axes3[3].set_title("Utility vs ε")
    fig3.savefig(f"{OUTPUT_DIR}/03_contamination.png")

    # 4. STABILITY 1x3
    fig4, axes4 = plt.subplots(1, 3, figsize=(15, 5))
    d7 = all_data['NYC'].get(7, {})
    for m, c in d7.items():
        if m not in STYLES: continue
        st = _get_st(m); rs = [t['rnd'] for t in c['traj']]; vs = [t['val'] for t in c['traj']]
        axes4[0].plot(rs, vs, color=st['color'], label=m)
    axes4[0].set_title("Convergence"); axes4[1].set_title("Regret"); axes4[2].set_title("Variance")
    fig4.savefig(f"{OUTPUT_DIR}/04_stability.png")

    # 5. REPUTATION 1x4
    fig5, axes5 = plt.subplots(1, 4, figsize=(18, 5))
    d5 = all_data['NYC'].get(5, {}).get('rep_data', {})
    if d5:
        ls = list(d5.keys())
        axes5[0].bar(ls, [d5[l]['stable'] for l in ls], color=['#E63946','#1D3557'])
        axes5[1].bar(ls, [d5[l]['manip'] for l in ls], color=['#E63946','#1D3557'])
        axes5[3].bar(ls, [d5[l]['gap'] for l in ls], color=['#E63946','#1D3557'])
    fig5.savefig(f"{OUTPUT_DIR}/05_reputation.png")

    # 9. RUNTIME 2x3
    if 'Eff' in all_data:
        fig9, axes9 = plt.subplots(2, 3, figsize=(15, 9))
        eff = all_data['Eff']
        for m, c in eff['N']['runtime'].items(): axes9[0,0].plot(c['x'], c['y'], label=m, marker='o', color=_get_st(m)['color'])
        for m, c in eff['N']['comm'].items(): axes9[0,1].plot(c['x'], c['y'], marker='s', color=_get_st(m)['color'])
        for m, c in eff['k']['runtime'].items(): axes9[1,0].plot(c['x'], c['y'], marker='^', color=_get_st(m)['color'])
        axes9[0,0].set_title("Runtime vs N"); axes9[0,1].set_title("Comm vs N"); axes9[1,0].set_title("Runtime vs k")
        fig9.legend(*axes9[0,0].get_legend_handles_labels(), loc='upper center', bbox_to_anchor=(0.5, 0.98), ncol=4)
        fig9.savefig(f"{OUTPUT_DIR}/09_runtime.png")

if __name__ == "__main__":
    n_l, t_l = r'd:\src\logs\icde_experiments_20260511-152337.txt', r'd:\src\logs\icde_experiments_20260511-104228.txt'
    e_l = os.path.join('logs', [f for f in os.listdir('logs') if 'efficiency' in f][-1])
    data = parse_logs(n_l, t_l, e_l)
    plot_master(data)
    print("Figures generated successfully.")
